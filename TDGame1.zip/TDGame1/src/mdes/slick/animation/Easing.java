/*
 * Easing.java
 *
 * Created on January 22, 2008, 7:33 PM
 */

package mdes.slick.animation;

import org.newdawn.slick.util.FastTrig;

/**
 * <p>Easing类包含了一组由Robert Penner提供的通用运动缓动函数。这个类本质上是从Penner的ActionScript工具包移植过来的，
 * 并添加了一些额外的调整。</p>
 * <p>示例：<pre>
 *    //无缓动
 *    Easing e1 = Easing.LINEAR;
 *
 *    //backOut缓动，超调量是Easing.Back.DEFAULT_OVERSHOOT
 *    Easing e2 = Easing.BACK_OUT;
 *
 *    //backOut缓动，超调量是1.85f
 *    Easing.Back e3 = new Easing.BackOut(1.85f);
 * </pre></p>
 * <a href="http://www.robertpenner.com/easing/">Robert Penner's Easing Functions</a>
 * @author davedes
 */
public interface Easing {

    /**
     * 缓动的基本函数。
     *
     * @param t 时间（帧数或秒/毫秒）
     * @param b 起始值
     * @param c 变化值
     * @param d 持续时间
     * @return 缓动后的值
     */
    public float ease(float t, float b, float c, float d);

    /**
     * 简单的线性缓动 - 无缓动效果。
     */
    public static final Easing LINEAR = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return c * t / d + b;
        }
    };

    ///////////// 二次方缓动：t^2 ///////////////////

    /**
     * 二次方缓动入 - 从零速度开始加速。
     */
    public static final Easing QUAD_IN = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return c * (t /= d) * t + b;
        }
    };

    /**
     * 二次方缓动出 - 减速至零速度。
     */
    public static final Easing QUAD_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return -c * (t /= d) * (t - 2) + b;
        }
    };

    /**
     * 二次方缓动入/出 - 直到中途加速，然后减速
     */
    public static final Easing QUAD_IN_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            if ((t /= d / 2) < 1) return c / 2 * t * t + b;
            return -c / 2 * ((--t) * (t - 2) - 1) + b;
        }
    };


    ///////////// 三次方缓动：t^3 ///////////////////////

    /**
     * 三次方缓动入 - 从零速度开始加速。
     */
    public static final Easing CUBIC_IN = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return c * (t /= d) * t * t + b;
        }
    };

    /**
     * 三次方缓动出 - 减速至零速度
     */
    public static final Easing CUBIC_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return c * ((t = t / d - 1) * t * t + 1) + b;
        }
    };

    /**
     * 三次方缓动入/出 - 直到中途加速，然后减速.
     */
    public static final Easing CUBIC_IN_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            if ((t /= d / 2) < 1) return c / 2 * t * t * t + b;
            return c / 2 * ((t -= 2) * t * t + 2) + b;
        }
    };

    ///////////// 四次方缓动：t^4 /////////////////////

    /**
     * 四次方缓动入 - 从零速度开始加速。
     */
    public static final Easing QUARTIC_IN = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return c * (t /= d) * t * t * t + b;
        }
    };

    /**
     * 四次方缓动出 - 减速至零速度
     */
    public static final Easing QUARTIC_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return -c * ((t = t / d - 1) * t * t * t - 1) + b;
        }
    };

    /**
     * 四次方缓动入/出 - 直到中途加速，然后减速
     */
    public static final Easing QUARTIC_IN_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            if ((t /= d / 2) < 1) return c / 2 * t * t * t * t + b;
            return -c / 2 * ((t -= 2) * t * t * t - 2) + b;
        }
    };

    ///////////// 五次方缓动：t^5  ////////////////////

    /**
     * 五次方缓动入 - 从零速度开始加速。
     */

    public static final Easing QUINTIC_IN = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return c * (t /= d) * t * t * t * t + b;
        }
    };

    /**
     * 五次方缓动出 - 减速至零速度
     */
    public static final Easing QUINTIC_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return c * ((t = t / d - 1) * t * t * t * t + 1) + b;
        }
    };

    /**
     * 五次方缓动入/出 - 直到中途加速，然后减速
     */
    public static final Easing QUINTIC_IN_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            if ((t /= d / 2) < 1) return c / 2 * t * t * t * t * t + b;
            return c / 2 * ((t -= 2) * t * t * t * t + 2) + b;
        }
    };


    ///////////// 正弦缓动：sin(t) ///////////////

    /**
     * 正弦缓动入 - 从零速度开始加速。
     */

    public static final Easing SINE_IN = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return -c * (float) FastTrig.cos(t / d * (Math.PI / 2)) + c + b;
        }
    };

    /**
     * 正弦缓动出 - 减速至零速度
     */
    public static final Easing SINE_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return c * (float) FastTrig.sin(t / d * (Math.PI / 2)) + b;
        }
    };

    /**
     * 正弦缓动入出 - 直到中途加速，然后减速
     */
    public static final Easing SINE_IN_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return -c / 2 * ((float) FastTrig.cos(Math.PI * t / d) - 1) + b;
        }
    };

    ///////////// 指数缓动：2^t //////////////////

    /**
     * 指数缓动入 - 从零速度开始加速。
     */

    public static final Easing EXPO_IN = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return (t == 0) ? b : c * (float) Math.pow(2, 10 * (t / d - 1)) + b;
        }
    };

    /**
     * 指数缓动出 - 减速至零速度
     */
    public static final Easing EXPO_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return (t == d) ? b + c : c * (-(float) Math.pow(2, -10 * t / d) + 1) + b;
        }
    };

    /**
     * 指数缓动入出 - 直到中途加速，然后减速
     */
    public static final Easing EXPO_IN_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            if (t == 0) return b;
            if (t == d) return b + c;
            if ((t /= d / 2) < 1) return c / 2 * (float) Math.pow(2, 10 * (t - 1)) + b;
            return c / 2 * (-(float) Math.pow(2, -10 * --t) + 2) + b;
        }
    };


    /////////// 循环缓动：sqrt(1-t^2) //////////////

    /**
     * 循环缓动入 - 从零速度开始加速。
     */
    public static final Easing CIRC_IN = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return -c * ((float) Math.sqrt(1 - (t /= d) * t) - 1) + b;
        }
    };

    /**
     * 循环缓动出 - 减速至零速度
     */
    public static final Easing CIRC_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return c * (float) Math.sqrt(1 - (t = t / d - 1) * t) + b;
        }
    };

    /**
     * 循环缓动入/出 - 直到中途加速，然后减速
     */
    public static final Easing CIRC_IN_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            if ((t /= d / 2) < 1) return -c / 2 * ((float) Math.sqrt(1 - t * t) - 1) + b;
            return c / 2 * ((float) Math.sqrt(1 - (t -= 2) * t) + 1) + b;
        }
    };

    /////////// 弹性松弛：指数衰减的正弦波 //////////////

    /**
     * 弹性缓和的基类
     */
    public static abstract class Elastic implements Easing {
        private float amplitude;
        private float period;

        /**
         * 创建具有指定设置的新弹性缓动。
         *
         * @param amplitude 弹性函数的振幅
         * @param period    弹性函数的周期
         */
        public Elastic(float amplitude, float period) {
            this.amplitude = amplitude;
            this.period = period;
        }

        /**
         * 使用默认设置（-1f, 0f）创建一个新的弹性缓动
         */
        public Elastic() {
            this(-1f, 0f);
        }

        /**
         * 返回周期
         *
         * @return 缓动的周期
         */
        public float getPeriod() {
            return period;
        }

        /**
         * 将周期设置为给定值。
         *
         * @param period 新的周期
         */
        public void setPeriod(float period) {
            this.period = period;
        }

        /**
         * 返回振幅
         *
         * @return 缓动的振幅
         */
        public float getAmplitude() {
            return amplitude;
        }

        /**
         * 将振幅设置为给定值。
         *
         * @param amplitude 新的振幅
         */
        public void setAmplitude(float amplitude) {
            this.amplitude = amplitude;
        }
    }

    /**
     * 使用默认值的缓动入实例
     */
    public static final Easing.Elastic ELASTIC_IN = new Easing.ElasticIn();

    /**
     * 用于ElasticIn函数的弹性缓动.
     */
    public static class ElasticIn extends Elastic {
        public ElasticIn(float amplitude, float period) {
            super(amplitude, period);
        }

        public ElasticIn() {
            super();
        }

        public float ease(float t, float b, float c, float d) {
            float a = getAmplitude();
            float p = getPeriod();
            if (t == 0) return b;
            if ((t /= d) == 1) return b + c;
            if (p == 0) p = d * .3f;
            float s = 0;
            if (a < Math.abs(c)) {
                a = c;
                s = p / 4;
            } else s = p / (float) (2 * Math.PI) * (float) Math.asin(c / a);
            return -(a * (float) Math.pow(2, 10 * (t -= 1)) * (float) Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
        }
    }

    /**
     * 使用默认值的弹性缓动出实例
     */
    public static final Easing.Elastic ELASTIC_OUT = new Easing.ElasticOut();

    /**
     * 用于ElasticOut函数的弹性缓动
     */
    public static class ElasticOut extends Elastic {
        public ElasticOut(float amplitude, float period) {
            super(amplitude, period);
        }

        public ElasticOut() {
            super();
        }

        public float ease(float t, float b, float c, float d) {
            float a = getAmplitude();
            float p = getPeriod();
            if (t == 0) return b;
            if ((t /= d) == 1) return b + c;
            if (p == 0) p = d * .3f;
            float s = 0;
            if (a < Math.abs(c)) {
                a = c;
                s = p / 4;
            } else s = p / (float) (2 * Math.PI) * (float) Math.asin(c / a);
            return a * (float) Math.pow(2, -10 * t) * (float) FastTrig.sin((t * d - s) * (2 * Math.PI) / p) + c + b;
        }
    }

    /**
     * 使用默认值的 ElasticInOut 实例。
     */
    public static final Easing.Elastic ELASTIC_IN_OUT = new Easing.ElasticInOut();

    /**
     * 用于 ElasticInOut 函数的弹性缓动。
     */
    public static class ElasticInOut extends Elastic {
        public ElasticInOut(float amplitude, float period) {
            super(amplitude, period);
        }

        public ElasticInOut() {
            super();
        }

        public float ease(float t, float b, float c, float d) {
            float a = getAmplitude();
            float p = getPeriod();
            if (t == 0) return b;
            if ((t /= d / 2) == 2) return b + c;
            if (p == 0) p = d * (.3f * 1.5f);
            float s = 0;
            if (a < Math.abs(c)) {
                a = c;
                s = p / 4f;
            } else s = p / (float) (2 * Math.PI) * (float) Math.asin(c / a);
            if (t < 1)
                return -.5f * (a * (float) Math.pow(2, 10 * (t -= 1)) * (float) FastTrig.sin((t * d - s) * (2 * Math.PI) / p)) + b;
            return a * (float) Math.pow(2, -10 * (t -= 1)) * (float) FastTrig.sin((t * d - s) * (2 * Math.PI) / p) * .5f + c + b;
        }
    }

////////////// 回退缓动：超调的三次缓动：(s+1)*t^3 - s*t^2  //////////////

    /**
     * 回退缓动的基础类。
     */
    public static abstract class Back implements Easing {
        /**
         * 默认的超调是 10%（1.70158）。
         */
        public static final float DEFAULT_OVERSHOOT = 1.70158f;

        private float overshoot;

        /**
         * 创建一个使用默认超调（1.70158）的 Back 实例。
         */
        public Back() {
            this(DEFAULT_OVERSHOOT);
        }

        /**
         * 创建一个使用指定超调的 Back 实例。
         *
         * @param overshoot 超调量 -- 数值越大，超调越明显
         *                  超调为 0 时，结果是无超调的三次缓动
         */
        public Back(float overshoot) {
            this.overshoot = overshoot;
        }

        /**
         * 设置超调量。
         *
         * @param overshoot 新的超调量
         */
        public void setOvershoot(float overshoot) {
            this.overshoot = overshoot;
        }

        /**
         * 返回此缓动的超调量。
         *
         * @return 此缓动的超调量
         */
        public float getOvershoot() {
            return overshoot;
        }
    }

    /**
     * 使用默认超调的 BackIn 实例。
     */
    public static final Easing.Back BACK_IN = new Easing.BackIn();

    /**
     * 回退缓动进入 - 稍微回退，然后反转方向并移动到目标。
     */
    public static class BackIn extends Back {
        public BackIn() {
            super();
        }

        public BackIn(float overshoot) {
            super(overshoot);
        }

        public float ease(float t, float b, float c, float d) {
            float s = getOvershoot();
            return c * (t /= d) * t * ((s + 1) * t - s) + b;
        }
    }

    ;

    /**
     * 使用默认超调的 BackOut 实例。
     */
    public static final Easing.Back BACK_OUT = new Easing.BackOut();

    /**
     * 回退缓动离开 - 向目标移动，稍微超调，然后反转并返回目标。
     */
    public static class BackOut extends Back {
        public BackOut() {
            super();
        }

        public BackOut(float overshoot) {
            super(overshoot);
        }

        public float ease(float t, float b, float c, float d) {
            float s = getOvershoot();
            return c * ((t = t / d - 1) * t * ((s + 1) * t + s) + 1) + b;
        }
    }

    /**
     * 使用默认超调的 BackInOut 实例。
     */
    public static final Easing.Back BACK_IN_OUT = new Easing.BackInOut();

    /**
     * 回退缓动进入/离开 - 稍微回退，然后反转方向并移动到目标，
     * 然后稍微超调，反转，最后返回目标。
     */
    public static class BackInOut extends Back {
        public BackInOut() {
            super();
        }

        public BackInOut(float overshoot) {
            super(overshoot);
        }

        public float ease(float t, float b, float c, float d) {
            float s = getOvershoot();
            if ((t /= d / 2) < 1) return c / 2 * (t * t * (((s *= (1.525)) + 1) * t - s)) + b;
            return c / 2 * ((t -= 2) * t * (((s *= (1.525)) + 1) * t + s) + 2) + b;
        }
    }

////////////// 弹跳缓动：指数衰减的抛物线弹跳  //////////////

    /**
     * 弹跳缓动进入。
     */
    public static final Easing BOUNCE_IN = new Easing() {
        public float ease(float t, float b, float c, float d) {
            return c - Easing.BOUNCE_OUT.ease(d - t, 0, c, d) + b;
        }
    };

    /**
     * 弹跳缓动离开。
     */
    public static final Easing BOUNCE_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            if ((t /= d) < (1 / 2.75f)) {
                return c * (7.5625f * t * t) + b;
            } else if (t < (2 / 2.75f)) {
                return c * (7.5625f * (t -= (1.5f / 2.75f)) * t + .75f) + b;
            } else if (t < (2.5f / 2.75f)) {
                return c * (7.5625f * (t -= (2.25f / 2.75f)) * t + .9375f) + b;
            } else {
                return c * (7.5625f * (t -= (2.625f / 2.75f)) * t + .984375f) + b;
            }
        }
    };

    /**
     * 弹跳缓动进入/离开。
     */
    public static final Easing BOUNCE_IN_OUT = new Easing() {
        public float ease(float t, float b, float c, float d) {
            if (t < d / 2) return Easing.BOUNCE_IN.ease(t * 2, 0, c, d) * .5f + b;
            return Easing.BOUNCE_OUT.ease(t * 2 - d, 0, c, d) * .5f + c * .5f + b;
        }
    };
}