/*
 * SizeEntity.java
 *
 *
 */

package mdes.slick.animation.entity;

/**
 * 一个接口，定义了一个可以调整大小和动画化的实体。
 * @author davedes
 */
public interface SizeEntity {
    /**
     * 使用给定的宽度和高度（以像素为单位）调整此实体的大小。
     * @param width 新的宽度
     * @param height 新的高度
     */
    public void setSize(float width, float height);

    /**
     * 返回此实体的宽度（以像素为单位）。
     * @return 宽度
     */
    public float getWidth();

    /**
     * 返回此实体的高度（以像素为单位）。
     * @return 高度
     */
    public float getHeight();
}