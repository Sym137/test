/*
 * AlphaEntity.java
 *
 *
 */

package mdes.slick.animation.entity;

/**
 * 一个接口，定义了一个可以半透明和动画化的实体。
 * @author davedes
 */
public interface AlphaEntity {
    /**
     * 返回此实体的alpha值作为百分比。
     * @return alpha值，介于0和1之间
     */
    public float getAlpha();

    /**
     * 将此实体的alpha设置为给定的百分比。
     * @param alpha 新的alpha值，介于0和1之间
     */
    public void setAlpha(float alpha);
}
