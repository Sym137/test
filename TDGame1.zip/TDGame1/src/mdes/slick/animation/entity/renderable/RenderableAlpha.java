/*
 * RenderableAlpha.java
 *
 *
 */

package mdes.slick.animation.entity.renderable;

import mdes.slick.animation.entity.AlphaEntity;
import org.newdawn.slick.Renderable;

/**
 * 一个支持alpha变化和动画的Slick可渲染对象。这个类为了方便而提供，连同AnimationAlpha和ImageAlpha。使用RenderableAlpha意味着AlphaFx可以应用于大多数情况下的任何alpha可渲染对象，通常是Image或Animation。
 *
 * @author davedes
 */
public interface RenderableAlpha extends Renderable, AlphaEntity {
}