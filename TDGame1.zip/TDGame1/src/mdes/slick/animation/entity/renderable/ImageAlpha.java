/*
 * ImageAlpha.java
 *
 *
 */

package mdes.slick.animation.entity.renderable;

import org.newdawn.slick.Color;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

/**
 * 一个辅助类，用于从图像创建一个RenderableAlpha。
 * @author davedes
 */
public class ImageAlpha implements RenderableAlpha {

    /** 用于绘制的过滤器（用于alpha）。 */
    protected Color filter = new Color(1f, 1f, 1f, 1f);

    /** 用于渲染的图像。 */
    protected Image image;

    /**
     * 从指定的图像引用创建一个ImageAlpha（创建一个常规的Image）。
     * @param str 图像的引用
     */
    public ImageAlpha(String str) throws SlickException {
        this(new Image(str));
    }

    /**
     * 从指定的Image创建一个ImageAlpha。
     * @param image 此实体的图像
     */
    public ImageAlpha(Image image) {
        this.image = image;
    }

    /**
     * 返回此实体的alpha值作为百分比。
     * @return alpha值，介于0和1之间
     */
    public float getAlpha() {
        return filter!=null ? filter.a : 0f;
    }

    /**
     * 将此实体的alpha设置为给定的百分比。
     * @param alpha 新的alpha值，介于0和1之间
     */
    public void setAlpha(float alpha) {
        if (filter!=null)
            filter.a = alpha;
    }

    /**
     * 返回用于渲染图像的过滤器。
     * @return 处理alpha的颜色过滤器
     */
    public Color getFilter() {
        return filter;
    }

    /**
     * 在指定位置和缩放比例下渲染图像。
     * @param x x位置
     * @param y y位置
     * @param width 宽度
     * @param height 高度
     */
    public void draw(float x, float y, float width, float height) {
        image.draw(x, y, width, height, filter);
    }

    /**
     * 在指定位置渲染图像。
     * @param x x位置
     * @param y y位置
     */
    public void draw(float x, float y) {
        image.draw(x, y, filter);
    }

    /**
     * 返回此实体的图像。
     * @return 用于渲染的图像
     */
    public Image getImage() {
        return image;
    }

    /**
     * 更改此实体的图像。
     * @param image 用于渲染的新图像
     */
    public void setImage(Image image) {
        this.image = image;
    }
}