/*
 * AnimationAlpha.java
 *
 *
 */

package mdes.slick.animation.entity.renderable;

import org.newdawn.slick.Animation;
import org.newdawn.slick.Color;

/**
 * 一个辅助类，用于从动画创建一个RenderableAlpha。
 * @author davedes
 */
public class AnimationAlpha implements RenderableAlpha {

    /** 用于绘制的过滤器（用于alpha）。 */
    protected Color filter = new Color(1f, 1f, 1f, 1f);

    /** 要渲染的动画。 */
    protected Animation animation;

    /**
     * 使用指定的动画创建这个类的一个新的实例。
     * @param animation 要使用的动画
     */
    public AnimationAlpha(Animation animation) {
        this.animation = animation;
    }

    /**
     * 返回此实体的alpha值作为百分比。
     * @return alpha值，介于0和1之间
     */
    public float getAlpha() {
        return filter!=null ? filter.a : 0f;
    }

    /**
     * 将此实体的alpha设置为给定的百分比。
     * @param alpha 新的alpha值，介于0和1之间
     */
    public void setAlpha(float alpha) {
        if (filter!=null)
            filter.a = alpha;
    }

    /**
     * 返回用于渲染动画的过滤器。
     * @return 处理alpha的颜色过滤器
     */
    public Color getFilter() {
        return filter;
    }

    /**
     * 在指定位置渲染动画。
     * @param x x位置
     * @param y y位置
     */
    public void draw(float x, float y) {
        animation.draw(x, y, filter);
    }

    /**
     * 返回此实体的动画。
     * @return 动画
     */
    public Animation getAnimation() {
        return animation;
    }

    /**
     * 设置此实体的动画。
     * @param animation 新的动画
     */
    public void setAnimation(Animation animation) {
        this.animation = animation;
    }
}