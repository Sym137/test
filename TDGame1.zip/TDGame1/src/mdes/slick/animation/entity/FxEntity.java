/*
 * FxEntity.java
 *
 *
 */

package mdes.slick.animation.entity;

/**
 * 一个标记接口，意味着一个对象可以通过时间轴/特效进行动画化。
 *
 * @author davedes
 */
public interface FxEntity {
}
