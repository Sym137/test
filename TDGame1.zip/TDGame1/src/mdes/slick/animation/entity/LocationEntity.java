/*
 * LocationEntity.java
 *
 *
 */

package mdes.slick.animation.entity;

/**
 * 一个接口，定义了一个可以移动和动画化的实体。
 * @author davedes
 */
public interface LocationEntity extends FxEntity {

    /**
     * 返回当前在(x,y)坐标空间中的x位置。
     * @return x位置
     */
    public float getX();

    /**
     * 返回当前在(x,y)坐标空间中的y位置。
     * @return y位置
     */
    public float getY();

    /**
     * 将此实体移动到指定位置。
     * @param x 新的x位置
     * @param y 新的y位置
     */
    public void setLocation(float x, float y);
}