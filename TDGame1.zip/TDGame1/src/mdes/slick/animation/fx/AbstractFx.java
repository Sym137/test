/*
 * AbstractFx.java
 *
 *
 */

package mdes.slick.animation.fx;

import mdes.slick.animation.Easing;
import mdes.slick.animation.Fx;

/**
 * 一个基础的Fx类，被大多数缓动动画Fx使用。
 * @author davedes
 */
public abstract class AbstractFx extends Fx {

    /** 这个Fx的缓动。 */
    protected Easing easing;

    /**
     * 使用指定的持续时间和缓动创建一个AbstractFx。
     * @param duration 持续时间（毫秒）
     * @param easing 默认缓动
     */
    public AbstractFx(int duration, Easing easing) {
        super(duration);
        this.easing = easing;
    }

    /**
     * 更改这个动画的缓动。
     * @param easing 新的缓动
     */
    public void setEasing(Easing easing) {
        this.easing = easing;
    }

    /**
     * 返回这个动画的缓动。
     * @return 这个动画使用的缓动
     */
    public Easing getEasing() {
        return easing;
    }
}