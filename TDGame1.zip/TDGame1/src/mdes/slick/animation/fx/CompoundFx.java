/*
 * CompoundFx.java
 *
 *
 */

package mdes.slick.animation.fx;

import mdes.slick.animation.Fx;

/**
 * 一个同时动画化两个Fx的Fx。
 * @author davedes
 */
public class CompoundFx extends Fx {

    protected Fx one;
    protected Fx other;

    /** 创建一个新的CompoundFx实例 */
    public CompoundFx(Fx one, Fx other) {
        super(Math.max(one.getDuration(), other.getDuration()));
        this.one = one;
        this.other = other;
    }

    public void animate(int time) {
        one.animate(time);
        other.animate(time);
    }

    public void rewind() {
        one.rewind();
        other.rewind();
    }

    public void fastForward() {
        one.fastForward();
        other.fastForward();
    }
}