/*
 * AlphaFx.java
 *
 *
 */

package mdes.slick.animation.fx;

import mdes.slick.animation.Easing;
import mdes.slick.animation.entity.AlphaEntity;

/**
 * 一个淡入淡出动画，影响指定的AlphaEntity。
 *
 * @author davedes
 */
public class AlphaFx extends AbstractFx {

    /** 开始的alpha值。 */
    private float startAlpha;

    /** 结束的alpha值。 */
    private float endAlpha;

    /** Alpha实体。 */
    private AlphaEntity entity;

    /**
     * 使用指定参数创建一个新的AlphaFx实例。
     *
     * @param duration 这个Fx应该持续的时间
     * @param entity 要修改的实体
     * @param startAlpha 开始的alpha值
     * @param endAlpha 结束的alpha值
     * @param easing 缓动
     */
    public AlphaFx(int duration, AlphaEntity entity, float startAlpha, float endAlpha, Easing easing) {
        super(duration, easing);
        this.entity = entity;
        this.startAlpha = startAlpha;
        this.endAlpha = endAlpha;
    }

    /**
     * 使用指定参数和实体当前的alpha值（通过getAlpha）创建一个新的AlphaFx实例。
     *
     * @param duration 这个Fx应该持续的时间
     * @param entity 要修改的实体
     * @param endAlpha 结束的alpha值
     * @param easing 缓动
     */
    public AlphaFx(int duration, AlphaEntity entity, float endAlpha, Easing easing) {
        this(duration, entity, entity.getAlpha(), endAlpha, easing);
    }

    public void setEntity(AlphaEntity entity) {
        this.entity = entity;
    }

    public AlphaEntity getEntity() {
        return entity;
    }

    public void animate(int time) {
        float change = endAlpha-startAlpha;
        float duration = (float)getDuration();
        float a = easing.ease(time, startAlpha, change, duration);
        if (a<0f)
            a=0f;
        else if (a>1f)
            a=1f;
        entity.setAlpha(a);
    }

    public void rewind() {
        entity.setAlpha(startAlpha);
    }

    public void fastForward() {
        entity.setAlpha(endAlpha);
    }

    public String toString() {
        return "FadeFx";
    }

    public float getStartAlpha() {
        return startAlpha;
    }

    public void setStartAlpha(float startAlpha) {
        this.startAlpha = startAlpha;
    }

    public float getEndAlpha() {
        return endAlpha;
    }

    public void setEndAlpha(float endAlpha) {
        this.endAlpha = endAlpha;
    }
}