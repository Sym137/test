/*
 * Fx.java
 *
 *
 */

package mdes.slick.animation;

/**
 * Fx类负责产生一个动画效果（通常在一个覆盖层上）在分配的持续时间内。子类应在animate、rewind和fastForward方法中提供功能。
 * 那些寻找空Fx（即：延迟）的人应该看看EmptyFx。
 *
 * @author davedes
 */
public abstract class Fx {

    /** 这个效果将持续的时间。 */
    private int duration = 0;

    /**
     * 使用指定的持续时间创建一个新的Fx实例。
     * @param duration 这个动画应该持续的时间（以tick计，大致是毫秒）
     */
    public Fx(int duration) {
        this.setDuration(duration);
    }

    /**
     * 时间轴调用以继续动画。如果这个方法返回false，时间轴将移动到下一个动画。大多数子类不应该覆盖这个方法。
     *
     * @param time 时间轴的当前tick
     * @return <tt>true</tt> 如果这个动画仍在进行中
     */
    protected boolean continueAnimation(int time) {
        if (time > getDuration()) { //已完成
            return false;
        }
        animate(time);
        return true;
    }

    /**
     * 使用指定的当前时间（tick）来动画化这个Fx。
     * @param time 当前时间，以帧或秒/毫秒计
     */
    public abstract void animate(int time);

    /** 将这个Fx回退到初始状态。 */
    public abstract void rewind();

    /** 将这个Fx快进到结束状态。 */
    public abstract void fastForward();

    /**
     * 返回这个Fx将持续的持续时间。
     * @return 这个Fx的持续时间
     */
    public int getDuration() {
        return duration;
    }

    /**
     * 设置这个Fx的持续时间。
     * @param duration 新的持续时间
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }
}