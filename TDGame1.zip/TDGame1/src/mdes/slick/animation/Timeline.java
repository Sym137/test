/*
 * Timeline.java
 *
 *
 */

package mdes.slick.animation;

import java.util.*;

/**
 * <p>时间轴持有一组Fx，它们将一个接一个地触发。</p>
 * @author davedes
 */
public class Timeline {

    /**
     * 当前Fx的tick。
     */
    private int ticks = 0;

    /**
     * 存储在这个时间轴中的动作。
     */
    private ArrayList<Fx> actions = new ArrayList<Fx>();

    /**
     * 当前动作的指针。
     */
    private int pointer = 0;

    /**
     * 当前的Fx动作。
     */
    private Fx current = null;

    /**
     * 这个时间轴是否处于活动（运行）状态。
     */
    private boolean active = false;

    /**
     * 这个时间轴是否循环。
     */
    private boolean looping = false;

    private int oldend;
    private int start = 0;
    private int end = Integer.MAX_VALUE;

    /**
     * 创建一个新的时间轴实例，它不处于活动状态且不循环。
     */
    public Timeline() {
    }

    /**
     * 将指定的Fx添加到这个时间轴。
     *
     * @param fx 要添加的Fx
     */
    public void add(Fx fx) {
        actions.add(fx);
    }

    /**
     * 从这个时间轴中移除指定的Fx。
     *
     * @param fx 要移除的Fx
     */
    public void remove(Fx fx) {
        actions.remove(fx);
    }

    /**
     * 更改这个时间轴的状态。如果为<tt>true</tt>，
     * 时间轴将运行，否则它将暂停。
     *
     * @param active 时间轴是否应该运行
     */
    public void setActive(boolean active) {
        this.active = active;
    }

    /**
     * 从开始处重启这个时间轴（将时间设置为0）。
     */
    public void restart() {
        current = null;
        ticks = 0;
        pointer = start;
    }

    /**
     * 清除这个时间轴中的所有Fx并从0重新开始。
     */
    public void clear() {
        actions.clear();
        restart();
    }

    public int getStartIndex() {
        return start;
    }

    public int getEndIndex() {
        return end;
    }

    public int getOldEnd() {
        return oldend;
    }


    public void setRange(int start, int end) {
        this.oldend = this.end;
        if (start > end) {
            throw new IllegalArgumentException("start must be <= end");
        }
        if (start < 0 || end < 0) {
            throw new IllegalArgumentException("start and end must be > 0");
        }
        this.start = start;
        this.end = end;
        if (pointer < start || pointer > end - 1) {
            restart();
        }
    }

    /**
     * 返回当前Fx的tick数。
     *
     * @return 当前Fx的tick数，当Fx改变时重置为
     * 0
     */
    public int getTicks() {
        return ticks;
    }

    /**
     * 返回<tt>true</tt>如果这个时间轴正在运行，<tt>false</tt>如果它已暂停。
     *
     * @return 这个时间轴是否处于活动状态
     */
    public boolean isActive() {
        return active;
    }

    /**
     * 返回当前正在动画化的Fx。
     *
     * @return 当前的fx
     */
    public Fx getCurrent() {
        if (actions.isEmpty() || pointer + 1 > actions.size())
            return null;
        else
            return (Fx) actions.get(pointer);
    }

    /**
     * 将这个时间轴的Fx回退到它们的原始状态，并调用restart()。
     */
    public void rewind() {
        for (int i = pointer; i >= 0 && i < actions.size(); i--) {
            Fx fx = (Fx) actions.get(i);
            fx.rewind();
        }
        restart();
    }

    /*public void fastForward() {
        for (int i=pointer; i<actions.size(); i++) {
            current = (Fx)actions.get(i);
            current.fastForward();
        }
        pointer = actions.size()-1;
        current = null;
    }*/

    /**
     * 调用以更新这个时间轴并动画化附加的Fx对象。
     *
     * @param delta 帧之间的时间差
     */
    public void update(int delta) {
        if (!isActive())
            return;
        //移动到下一个
        if (current == null && !actions.isEmpty()) {
            current = null;
            ticks = 0;
            if (pointer + 1 > actions.size() || pointer + 1 > end) {
                if (isLooping())
                    restart();
                else
                    setActive(false);
                return;
            }
            current = (Fx) actions.get(pointer++);
        }

        //update current
        if (current != null) {
            ticks += delta;
            boolean cont = current.continueAnimation(ticks);
            if (!cont)
                current = null;
        }
    }

    /**
     * 返回<tt>true</tt>如果这个时间轴在所有Fx完成后应该从零重复，<tt>false</tt>否则。一个终止的
     * * （非循环的）时间轴将在完成后被停用。
     * *
     * * @return 这个时间轴是否循环
     */
    public boolean isLooping() {

        return looping;
    }

    /**
     * 将这个时间轴的循环标志设置为<tt>looping</tt>。一个终止的
     * （非循环的）时间轴将在完成后被停用。
     *
     * @param looping 如果这个时间轴在所有Fx完成后应该从零重复，<tt>true</tt>否则
     */
    public void setLooping(boolean looping) {
        this.looping = looping;
    }
}