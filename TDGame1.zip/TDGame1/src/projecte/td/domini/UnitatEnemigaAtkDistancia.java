package projecte.td.domini;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import org.newdawn.slick.Image;

/**
 * UnitatEnemigaAtkDistancia类：远程攻击的敌方单位
 * @author Ernest Daban 和 David Alvarez
 */
public class UnitatEnemigaAtkDistancia extends UnitatEnemiga {

    int cadencia;//射击的定时频率
    protected ProjectilEstatic projectil;//单位将发射的弹药
    protected Timer timer;//用于射击的计时器
    protected boolean dispara = true;//是否射击
    protected float posXProj;//弹药的X坐标
    protected float posYProj;//弹药的Y坐标

    /**
     * 类的构造函数
     * @param vida 单位的生命值
     * @param frames 行走动画的图像
     * @param framesMort 死亡动画的图像
     * @param milisegons 行走动画每帧之间的毫秒数
     * @param frames2 攻击动画的图像
     * @param velocitat 单位的速度
     * @param milisegonsAtck 攻击动画每帧之间的毫秒数
     * @param cadencia 射击的定时频率
     * @param projectil 单位将发射的弹药
     * @param posXProj 弹药的X坐标
     * @param posYProj 弹药的Y坐标
     */
    public UnitatEnemigaAtkDistancia(int vida, int cadencia, Image[] frames, Image[] framesMort, int milisegons, ProjectilEstatic projectil, Image[] frames2, double velocitat, int milisegonsAtck, float posXProj, float posYProj) {
        super(vida, frames, framesMort, milisegons, frames2, velocitat, milisegonsAtck);
        this.cadencia = cadencia;
        this.projectil = projectil;
        this.posXProj = posXProj;
        this.posYProj = posYProj;
        timer = new Timer(cadencia, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (!mort) {
                    dispara = true;
                }
            }
        });
    }

    /**
     * 设置单位位置的setter方法
     * @param posX X坐标
     * @param posY Y坐标
     */
    @Override
    public void setLocation(float posX, float posY) {
        super.setLocation(posX, posY);
        projectil.setLocation(posX - projectil.getAnimation().getWidth() + posXProj, posY + posYProj);
    }

    /**
     * 激活单位的射击功能
     */
    public void activarDispars() {
        timer.start();
        super.activat = true;
    }

    /**
     * 单位已完成射击
     */
    public void haDisparat() {
        dispara = false;
    }

    /**
     * 禁用单位的射击功能
     */
    public void desactivarDispars() {
        activat = false;
        timer.stop();
    }

    /**
     * isShooting的getter方法
     * @return 如果正在射击则返回true
     */
    public boolean estaDisparant() {
        return dispara;
    }

    /**
     * 调整射击频率的setter方法
     */
    protected void ajustarTimer() {
        timer.setDelay(cadencia);
    }

    /**
     * 射击频率的getter方法
     * @return 射击频率
     */
    public int getCadencia() {
        return cadencia;
    }

    /**
     * 射击频率的setter方法
     * @param cadencia 射击频率
     */
    public void setCadencia(int cadencia) {
        this.cadencia = cadencia;
    }

    /**
     * 弹药的getter方法
     * @return 弹药对象的克隆
     */
    public Projectil getProjectil() {
        return projectil.cloneProjectil();
    }
}