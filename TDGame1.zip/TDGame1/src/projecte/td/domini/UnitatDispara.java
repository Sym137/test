package projecte.td.domini;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;

/**
 * 类 UnitatDispara: 进行射击的友方单位。
 * @作者
 */
public class UnitatDispara extends UnitatAbstract implements IAuraRapidesa {

    private int cadencia;
    private Projectil projectil;
    // 用于控制单位每隔多少秒射击一次的计时器
    private Timer timer;
    private boolean dispara = true;
    private boolean activat;
    private float posXProj;// 子弹位置的X坐标
    private float posYProj;// 子弹位置的Y坐标


    /**
     * UnitatDispara 类的构造函数
     * @param vida 生命值
     * @param cadencia 射击频率
     * @param frames 动画帧数组
     * @param framesMort 死亡动画帧数组
     * @param milisegons 每帧的时间（毫秒）
     * @param projectil 子弹对象
     * @param posXProj 子弹位置的X坐标偏移量
     * @param posYProj 子弹位置的Y坐标偏移量
     */
    public UnitatDispara(int vida, int cadencia, Image[] frames, Image[] framesMort, int milisegons,
                         Projectil projectil, float posXProj, float posYProj) {
        super(vida, frames, framesMort, milisegons);
        this.cadencia = cadencia;
        this.projectil = projectil;
        this.posXProj = posXProj;
        this.posYProj = posYProj;

        timer = new Timer(cadencia, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (!mort) {
                    dispara = true;
                }
            }
        });
    }

    /**
     * 更改单位的位置
     * @param posX X坐标
     * @param posY Y坐标
     */
    @Override
    public void setLocation(float posX, float posY) {
        super.setLocation(posX, posY);
        projectil.setLocation(posX + animation.getWidth() + posXProj, posY + posYProj);
    }

    /**
     * 判断单位是否可以装备某种光环
     * @param aura 光环对象
     * @return 是否可以装备
     */
    @Override
    public boolean potEquiparAura(Aura aura) {
        if (aura.getTipus().equals("MagRapidesa") || aura.getTipus().equals("MagVida")) {
            return true;
        }
        return false;
    }

    /**
     * 激活单位的射击功能
     */
    public void activarDispars() {
        timer.start();
        activat = true;
    }

    /**
     * 表示射击已经结束
     */
    public void haDisparat() {
        dispara = false;
    }

    /**
     * 停用单位的射击功能
     */
    public void desactivarDispars() {
        activat = false;
        timer.stop();
    }

    /**
     * 获取激活状态
     * @return 是否已激活
     */
    public boolean estaActivat() {
        return activat;
    }

    /**
     * 获取是否正在射击
     * @return 是否正在射击
     */
    public boolean estaDisparant() {
        return dispara;
    }

    /**
     * 调整计时器
     */
    protected void ajustarTimer() {
        timer.setDelay(cadencia);
    }

    /**
     * 获取射击频率
     * @return 射击频率
     */
    public int getCadencia() {
        return cadencia;
    }

    /**
     * 设置射击频率
     * @param cadencia 射击频率
     */
    public void setCadencia(int cadencia) {
        this.cadencia = cadencia;
    }

    /**
     * 获取子弹对象
     * @return 子弹对象
     */
    public Projectil getProjectil() {
        return projectil.cloneProjectil();
    }
}
