package projecte.td.domini;

import org.newdawn.slick.Animation;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;

/**
 * 类 ProjectilEstatic: 一个静态的、不移动的射弹，由动画表示。
 * @author Ernest Daban 和 David Alvarez
 */
public class ProjectilEstatic extends Projectil implements Cloneable {

    Animation animation;
    Image[] frames;
    int milisegons;

    /**
     * ProjectilEstatic 类的构造函数
     * @param dany 伤害值
     * @param frames 图像帧数组
     * @param milisegons 每帧的持续时间（毫秒）
     */
    public ProjectilEstatic(double dany, Image[] frames, int milisegons) {
        super(dany);
        this.frames = frames;
        this.animation = new Animation(frames, milisegons);
        this.animation.setLooping(false);
        this.milisegons = milisegons;
    }

    /**
     * 改变射弹的位置
     * @param posX X坐标
     * @param posY Y坐标
     */
    @Override
    public void setLocation(float posX, float posY) {
        super.setLocation(posX, posY);
        super.shape = new Rectangle(posX, posY, animation.getWidth(), animation.getHeight());
    }

    /**
     * 更新射弹的状态
     * @param delta 时间间隔（毫秒）
     */
    @Override
    public void update(int delta) {
        if (animation.isStopped()) {
            mort = true;
        }
    }

    /**
     * 复制射弹对象
     * @return 复制的射弹对象
     */
    @Override
    public Object clone() {
        return new ProjectilEstatic(dany, frames, milisegons);
    }

    /**
     * 获取克隆的射弹
     * @return 克隆的射弹对象
     */
    public Projectil cloneProjectil() {
        Projectil p = (Projectil) clone();
        p.setLocation(posX, posY);
        return p;
    }

    /**
     * 渲染射弹
     * @param gc 游戏容器
     * @param g 图形对象
     */
    public void render(GameContainer gc, Graphics g) {
        g.drawAnimation(animation, posX, posY);
    }

    /**
     * 生成撞击效果
     */
    public void impacte() {
    }

    /**
     * 获取动画对象
     * @return 动画对象
     */
    public Animation getAnimation() {
        return animation;
    }
}
