package projecte.td.domini;

/**
 * 子弹类：由友方或敌方单位发射的对象。
 * @author
 */
public abstract class Projectil extends Entitat {

    protected double dany; // 子弹造成的伤害

    /**
     * 子弹类的构造函数
     * @param dany 伤害值
     */
    public Projectil(double dany) {
        this.dany = dany;
    }

    /**
     * 改变子弹的位置
     * @param posX X坐标
     * @param posY Y坐标
     */
    public void setLocation(float posX, float posY) {
        super.posX = posX;
        super.posY = posY;
    }

    /**
     * 更新子弹状态
     * @param delta 时间增量
     */
    public void update(int delta) {
    }

    /**
     * 模拟撞击的方法
     */
    public abstract void impacte();

    /**
     * 用于克隆子弹的方法
     * @return 克隆的子弹
     */
    public abstract Projectil cloneProjectil();

    /**
     * 获取伤害值
     * @return 伤害值
     */
    public double getDany() {
        return dany;
    }

    /**
     * 设置伤害值
     * @param dany 伤害值
     */
    public void setDany(int dany) {
        this.dany = dany;
    }
}