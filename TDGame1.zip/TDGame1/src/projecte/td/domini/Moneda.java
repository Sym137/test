package projecte.td.domini;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.gui.GUIContext;
import projecte.td.managers.ManagerRecursos;

/**
 * 类 Moneda: 可点击的对象，由矿工提取。
 * @author
 */
public class Moneda extends AbstractComponent {

    private Shape area; // 填充硬币的形状
    private Image imatgeMoneda; // 硬币图像
    private int comptador;
    private float transparencia = 1;
    private boolean desapareix;
    private boolean actiu;

    /**
     * Moneda 类的构造函数
     * @param gui
     * @param posX
     * @param posY
     * @param tipus
     */
    public Moneda(GUIContext gui, int posX, int posY, String tipus) {
        super(gui);
        imatgeMoneda = getImageCorrecta(tipus);
        area = getArea(tipus, posX, posY);
        addListener();
    }

    /**
     * 获取 Moneda 的区域
     * @param tipus
     * @param posX
     * @param posY
     * @return area2
     */
    private Shape getArea(String tipus, int posX, int posY) {
        Shape area2 = null;
        if (tipus.equals("Miner")) {
            area2 = new Rectangle(posX + 32, posY + 45, imatgeMoneda.getWidth(), imatgeMoneda.getHeight());
        } else if (tipus.equals("MagVida")) {
            area2 = new Rectangle(posX + 15, posY + 25, imatgeMoneda.getWidth(), imatgeMoneda.getHeight());
        } else if (tipus.equals("MagRapidesa")) {
            area2 = new Rectangle(posX + 20, posY + 20, imatgeMoneda.getWidth(), imatgeMoneda.getHeight());
        }
        return area2;
    }

    /**
     * 获取正确的图像
     * @param tipus (Miner, MagVida, MagRapidesa)
     * @return image
     */
    private Image getImageCorrecta(String tipus) {
        Image image = null;
        if (tipus.equals("Miner")) {
            image = ManagerRecursos.getImage("monedaImage");
        } else if (tipus.equals("MagVida")) {
            image = ManagerRecursos.getImage("monedaVidaImage");
        } else if (tipus.equals("MagRapidesa")) {
            image = ManagerRecursos.getImage("monedaRapidesaImage");
        }
        return image;
    }

    /**
     * 更新硬币
     */
    public void update() {
        comptador++;
        if (comptador > 200) {
            transparencia -= 0.002;
        }
        if (transparencia <= 0) {
            desapareix = true;
        }
    }

    /**
     * 渲染按钮的所有组件
     * @param gc : 渲染上下文
     * @param g : 用于渲染图像和动画的图形对象
     */
    public void render(GUIContext gc, Graphics g) {
        imatgeMoneda.setAlpha(transparencia);
        g.drawImage(imatgeMoneda, area.getX(), area.getY());
        imatgeMoneda.setAlpha(1f);
    }

    /**
     * 为这个按钮添加监听器
     * @param unitat
     */
    public void addListener() {
        addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                actiu = true;
            }
        });
    }

    /**
     * 检查鼠标是否点击了这个元素
     * @param button : 被点击的按钮
     * @param mx : 鼠标点击时的 X 坐标
     * @param my : 鼠标点击时的 Y 坐标
     */
    @Override
    public void mousePressed(int button, int mx, int my) {
        if (area.contains(mx, my)) {
            notifyListeners();
        }
    }
    /**
     * 更改硬币的位置
     * @param x
     * @param y
     */
    public void setLocation(int x, int y) {
        if (area != null) {
            area.setX(x);
            area.setY(y);
        }
    }
    /**
     * 获取高度
     * @return height
     */
    public int getHeight() {
        return (int) (area.getMaxY() - area.getY());
    }
    /**
     * 获取宽度
     * @return width
     */
    public int getWidth() {
        return (int) (area.getMaxX() - area.getX());
    }
    /**
     * 获取 X 坐标
     * @return X
     */
    public int getX() {
        return (int) area.getX();
    }
    /**
     * 获取 Y 坐标
     * @return Y
     */
    public int getY() {
        return (int) area.getY();
    }
    /**
     * 获取是否消失
     * @return desapareix
     */
    public boolean isDesapareix() {
        return desapareix;
    }
    /**
     * 设置是否消失
     * @param desapareix
     */
    public void setDesapareix(boolean desapareix) {
        this.desapareix = desapareix;
    }
    /**
     * 获取是否活跃
     * @return actiu
     */
    public boolean isActiu() {
        return actiu;
    }
    /**
     * 设置是否活跃
     * @param actiu
     */
    public void setActiu(boolean actiu) {
        this.actiu = actiu;
    }
    /**
     * 获取透明度
     * @return
     */
    public float getTransparencia() {
        return transparencia;
    }
    /**
     * 设置透明度
     * @param transparencia
     */
    public void setTransparencia(float transparencia) {
        this.transparencia = transparencia;
    }
}