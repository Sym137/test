package projecte.td.domini;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;
import projecte.td.managers.ManagerContext;
import projecte.td.managers.ManagerDinersAures;
import projecte.td.managers.ManagerPerfil;

/**
 * 矿工类：友方单位，负责挖掘资金或物品。
 * @author
 */
public class Miner extends UnitatAbstract implements IAuraRapidesa {

    private int cadencia;
    private int capacitat;
    private Timer timer;
    private Moneda moneda;//单位将要挖掘的物体
    private static ManagerDinersAures diners;//管理资金的管理器
    private String tipus;//矿工类型(Miner,MagVida,MagRapidesa)
 
    private boolean haSonat;

    /**
     * 矿工类的构造函数
     *@param vida 生命值
     * @param cadencia 频率
     * @param capacitat 容量
     * @param frames 帧数组
     * @param framesMort 死亡帧数组
     * @param milisegons 毫秒数
     * @param tipus 类型
     * @param sound 声音
     */
    public Miner(int vida, int cadencia, int capacitat, Image[] frames, Image[] framesMort,
            int milisegons, String tipus) {
        super(vida, frames, framesMort, milisegons);
        this.cadencia = cadencia;
        this.capacitat = capacitat;
        this.tipus = tipus;
        diners = ManagerContext.getDiners();
        activar();

    }

    /**
     * 绘制单位
     * @param gc GameContainer
     * @param g Graphics
     */
    @Override
    public void render(GameContainer gc, Graphics g) {
        super.render(gc, g);
        g.drawAnimation(animation, posX, posY);
        if (moneda != null) {
            moneda.render(gc, g);
        }
    }

    /**
     * 更新单位
     * @param delta
     */
    @Override
    public void update(int delta) {
        if (moneda != null) {
            moneda.update();
            if (!haSonat) {
            
                haSonat = true;
            }
            if (moneda.isDesapareix()) {
                moneda = null;
            } else if (moneda.isActiu()) {
                if (tipus.equals("Miner")) {
                    diners.afegirDiners(capacitat);
                } else if (tipus.equals("MagVida") || tipus.equals("MagRapidesa")) {
                    diners.setTipusAuraEspera(tipus);
                }
                moneda = null;
            }
        }
    }

    /**
     * 创建并启动定时器
     */
    public void activar() {
        timer = new Timer(cadencia, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                moneda = new Moneda(ManagerContext.getGui(), (int) posX, (int) posY, tipus);
                haSonat = false;
            }
        });
        timer.start();
    }

    /**
     * 检查是否可以装备光环
     * @param aura 光环
     * @return 是否可以装备
     */
    @Override
    public boolean potEquiparAura(Aura aura) {
        if (aura.getTipus().equals("MagRapidesa") || aura.getTipus().equals("MagVida")) {
            return true;
        }
        return false;
    }

    /**
     * 调整定时器
     */
    protected void ajustarTimer() {
        timer.setDelay(cadencia);
    }

    /**
     * Getter auraActiva;
     * @return auraActiva
     */
    @Override
    public boolean isAuraActiva() {
        return auraActiva;
    }

    /**
     * Getter capacitat
     * @return capacitat
     */
    public int getCapacitat() {
        return capacitat;
    }

    /**
     * Setter Capacitat
     * @param capacitat
     */
    public void setCapacitat(int capacitat) {
        this.capacitat = capacitat;
    }

    /**
     * Getter cadencia
     * @return
     */
    public int getCadencia() {
        return cadencia;
    }

    /**
     * Setter cadencia
     * @param cadencia
     */
    public void setCadencia(int cadencia) {
        this.cadencia = cadencia;
    }

    /**
     * Para el timer
     */
    public void desactivarTimer() {
        if (timer != null) {
            if (timer.isRunning()) {
                timer.stop();
            }
        }
    }

}
