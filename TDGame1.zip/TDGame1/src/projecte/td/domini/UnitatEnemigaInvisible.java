package projecte.td.domini;
import org.newdawn.slick.Animation;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;
import org.newdawn.slick.geom.Rectangle;
import projecte.td.managers.ManagerPerfil;

/**
 * 类 UnitatEnemigaInvisible: 一种敌方单位，最初是隐形的，直到与友方单位发生碰撞。
 * @author Ernest Daban 和 David Alvarez
 */
public class UnitatEnemigaInvisible extends UnitatEnemigaAtkNormal {

    private boolean invisible = true;
    private boolean apareix = true;
    private Animation animation2;
    private Animation ainvisible;

    /**
     * UnitatEnemigaInvisible 的构造函数
     * @param vida 生命值
     * @param frames 动画帧数组
     * @param framesMort 死亡动画帧数组
     * @param milisegons 每帧时间（毫秒）
     * @param frames2 另一组动画帧
     * @param velocitat 速度
     * @param milisegonsAtck 攻击间隔时间（毫秒）
     * @param dany 伤害值
     * @param frames3 另一组动画帧
     * @param frames4 另一组动画帧
     * @param milisegons3 动画3的每帧时间（毫秒）
     * @param milisegons4 动画4的每帧时间（毫秒）
     */

    public UnitatEnemigaInvisible(int vida, Image[] frames, Image[] framesMort, int milisegons, Image[] frames2, double velocitat, int milisegonsAtck, double dany, Image[] frames3, Image[] frames4, int milisegons3, int milisegons4) {
        super(vida, frames, framesMort, milisegons, frames2, velocitat, milisegonsAtck, dany);
        animation2 = new Animation(frames3, milisegons3);
        ainvisible = new Animation(frames4, milisegons4);
    }

    /**
     * 更改 shape
     */
    public void canviShape() {
        shape = new Rectangle(posX + 48, posY + 12, animation.getWidth() - 48, animation.getHeight() - 12);
    }

    /**
     * 将 shape 恢复到原始位置
     */
    public void segonCanviShape() {
        super.setLocation(posX, posY);
    }

    /**
     * 绘制单位
     * @param gc GameContainer
     * @param g Graphics
     */
    @Override
    public void render(GameContainer gc, Graphics g) {
        // 如果是隐形的，则不显示任何内容
        if (!invisible) {
            if (apareix && activat) {
                // 显示出现时的动画，并停止动画
                g.drawAnimation(atck, (posX + (shape.getWidth()) - atck.getWidth()), posY + shape.getHeight() - atck.getHeight());
                atck.stopAt(31);
            } else if (!apareix && activat) {
                renderVida(gc, g);
                g.drawAnimation(animation, posX, posY);
                if (!animation.isStopped() && !soAcabat && animation.getFrame() == 0) {
                    soAcabat = true;
                }
            } else if (!activat) {
                renderVida(gc, g);
                g.drawAnimation(animation2, posX, posY);
            }
        } else {
            g.drawAnimation(ainvisible, posX + shape.getWidth() / 2, posY);
        }
        if (animation.getFrame() == animation.getFrameCount() - 1) {
            soAcabat = false;
        }
    }

    /**
     * 更新单位状态
     * @param delta 时间 delta
     */
    @Override
    public void update(int delta) {
        if (posX <= 0 - getWidth() / 2) {
            haArribat = true;
        }
        if (!activat) {
            posX -= velocitat * delta;
            setLocation(posX, posY);
        }
        if (activat) {
            invisible = false;
            if (atck.isStopped()) {
                apareix = false;
            }
        }
    }

    /**
     * 获取伤害值
     * @return 伤害值
     */
    @Override
    public double getDany() {
        if (!mort && !invisible && !apareix) {
            return dany;
        } else {
            return 0;
        }
    }

    /**
     * 对单位造成伤害
     * @param dany 伤害值
     */
    @Override
    public void impacte(double dany) {
        if (!invisible && !apareix) {
            super.impacte(dany);
        }
    }

    /**
     * 获取是否隐形
     * @return 是否隐形
     */
    public boolean isInvisible() {
        return invisible;
    }
}