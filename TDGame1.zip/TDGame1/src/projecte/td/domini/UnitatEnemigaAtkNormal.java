package projecte.td.domini;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;
import projecte.td.managers.ManagerPerfil;

/**
 * 敌方单位类 UnitatEnemigaAtkNormal: 进行近战攻击的敌方单位。
 * @author Ernest Daban i David Alvarez
 */
public class UnitatEnemigaAtkNormal extends UnitatEnemiga {

    double dany; // 攻击伤害
    protected boolean soAcabat; // 声音是否已经播放完毕

    /**
     * 构造函数 UnitatEnemigaAtkNormal
     * @param vida 生命值
     * @param frames 动画帧
     * @param framesMort 死亡动画帧
     * @param milisegons 每帧持续时间（毫秒）
     * @param frames2 攻击动画帧
     * @param velocitat 移动速度
     * @param milisegonsAtck 攻击动画每帧持续时间（毫秒）
     * @param dany 攻击伤害
     */
    public UnitatEnemigaAtkNormal(int vida, Image[] frames, Image[] framesMort, int milisegons, Image[] frames2, double velocitat, int milisegonsAtck, double dany) {
        super(vida, frames, framesMort, milisegons, frames2, velocitat, milisegonsAtck);
        this.dany = dany;
    }

    /**
     * 构造函数 UnitatEnemigaAtkNormal
     * @param vida 生命值
     * @param frames 动画帧
     * @param framesMort 死亡动画帧
     * @param milisegons 每帧持续时间（毫秒）
     * @param velocitat 移动速度
     * @param dany 攻击伤害
     */
    public UnitatEnemigaAtkNormal(int vida, Image[] frames, Image[] framesMort, int milisegons, double velocitat, double dany) {
        super(vida, frames, framesMort, milisegons, velocitat);
        this.dany = dany;
    }

    /**
     * 获取激活状态
     * @return 如果已激活则返回 true
     */
    public boolean isActivat() {
        return activat;
    }

    /**
     * 设置激活状态
     * @param activat 激活状态
     */
    public void setActivat(boolean activat) {
        this.activat = activat;
    }

    /**
     * 获取攻击伤害
     * @return 如果单位未死亡则返回攻击伤害，否则返回 0
     */
    public double getDany() {
        if (!mort) {
            return dany;
        } else {
            return 0;
        }
    }

    /**
     * 绘制单位
     * @param gc 游戏容器
     * @param g 图形对象
     */
    @Override
    public void render(GameContainer gc, Graphics g) {
        renderVida(gc, g);
        if (activat) {
            float x = getPosX() - (atck.getWidth() - getWidth());
            g.drawAnimation(atck, x, posY);
            if (!atck.isStopped() && !soAcabat && atck.getFrame() == 0) {
                soAcabat = true;
            }
        } else {
            g.drawAnimation(animation, posX, posY);
        }
        if (atck.getFrame() == atck.getFrameCount() - 1) {
            soAcabat = false;
        }
    }
}