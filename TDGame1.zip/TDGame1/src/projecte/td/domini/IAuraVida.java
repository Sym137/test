package projecte.td.domini;

/**
 * Aura Vida 接口：用于确定友军单位是否可以装备这种光环。
 * @author
 */
public interface IAuraVida {

    // 观察是否可以装备光环
    public boolean potEquiparAura(Aura aura);

    // 激活光环
    public void activarAura(Aura aura);

    // 取消激活光环
    public void desactivarAura();

    // 获取 AuraActiva 状态
    public boolean isAuraActiva();

    // 设置 AuraActiva 状态
    public void setAuraActiva(boolean activa);
}
