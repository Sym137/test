package projecte.td.domini;

import org.newdawn.slick.Animation;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;

/**
 * 抽象单位类：不执行任何攻击的友军单位。
 * @author
 */
public class UnitatAbstract extends Entitat implements IAuraVida {

    // 单位的生命值
    protected float vida;
    // 单位在棋盘上放置时的生命值
    protected float vidaTotal;
    // 单位的动画
    protected Animation animation;
    // 单位可以装备的光环
    Aura aura;
    // 绘制光环的浮点数
    protected float alphaAura = 1;
    // 指示单位是否有激活的光环
    protected boolean auraActiva;
    protected Animation animation_mort;
    private boolean soMort = true;

    /**
     * 抽象单位构造函数
     * @param vida 生命值
     * @param frames 动画帧
     * @param framesMort 死亡动画帧
     * @param milisegons 毫秒数
     */
    public UnitatAbstract(int vida, Image[] frames, Image[] framesMort, int milisegons) {
        this.vida = vida;
        this.vidaTotal = vida;
        this.animation = new Animation(frames, milisegons);
        this.animation_mort = new Animation(framesMort, 30);
    }

    /**
     * 抽象单位构造函数
     * @param vida 生命值
     * @param frames 动画帧
     * @param milisegons 毫秒数
     */
    public UnitatAbstract(int vida, Image[] frames, int milisegons) {
        this.vida = vida;
        this.vidaTotal = vida;
        this.animation = new Animation(frames, milisegons);
    }

    /**
     * 改变单位的位置
     * @param x X坐标
     * @param y Y坐标
     */
    public void setLocation(float x, float y) {
        super.posX = x;
        super.posY = y;
        super.shape = new Rectangle(posX, posY, animation.getWidth(), animation.getHeight());
    }

    /**
     * 渲染单位
     * @param gc 游戏容器
     * @param g 图形
     */
    public void render(GameContainer gc, Graphics g) {
        g.drawAnimation(animation, posX, posY);
        renderVida(gc, g);
    }

    /**
     * 渲染单位的死亡
     * @param gc 游戏容器
     * @param g 图形
     */
    public void renderMort(GameContainer gc, Graphics g) {
        if (mort && animation_mort != null) {
            g.drawAnimation(animation_mort, posX + shape.getWidth() / 2, posY);
            animation_mort.setLooping(false);
        }
    }

    /**
     * 方法指定是否播放单位死亡的声音
     * @return
     */
    public boolean efectuarSoMort() {
        if (mort && animation_mort != null && !animation_mort.isStopped() && soMort) {
            soMort = false;
            return true;
        }
        return false;
    }

    /**
     * 方法用于不播放单位死亡的声音
     */
    public void noEfectuarSoMort() {
        soMort = false;
    }

    /**
     * 死亡获取器
     * @return 是否死亡
     */
    @Override
    public boolean isMort() {
        if (animation_mort != null) {
            if (mort && animation_mort.isStopped()) {
                return true;
            }
        } else {
            if (mort) {
                return true;
            }
        }
        return false;
    }

    /**
     * 方法对单位产生影响
     * @param dany 伤害
     */
    public void impacte(double dany) {
        if (vida > 0) {
            vida -= dany;
        }
        if (vida <= 0) {
            mort = true;
        }
    }

    /**
     * 渲染单位的生命值
     * @param gc 游戏容器
     * @param g 图形
     */
    public void renderVida(GameContainer gc, Graphics g) {
        if (vida > 0) {
            g.setColor(Color.red);
            g.fillRect(posX + 5, posY - 15, (vida / vidaTotal) * 30, 5);
        }
        if (auraActiva) {
            aura.getImage().setAlpha(0.15f);
            g.drawImage(aura.getImage(), posX, posY);
        }
        g.setColor(Color.white);
        g.drawRect(posX + 5, posY - 15, 30, 5);
    }

    /**
     * 更新单位
     * @param delta 时间差
     */
    public void update(int delta) {
    }

    /**
     * 方法用于激活光环
     * @param aura 光环
     */
    @Override
    public void activarAura(Aura aura) {
        auraActiva = true;
        this.aura = aura;
        this.aura.setBo(this);
        this.aura.activarAura();
    }

    /**
     * 方法用于禁用光环
     */
    @Override
    public void desactivarAura() {
        auraActiva = false;
        aura.desactivarAura();
        aura = null;
    }

    /**
     * 方法指定是否可以装备光环
     * @param aura 光环
     * @return 是否可以装备
     */
    public boolean potEquiparAura(Aura aura) {
        if (aura.getTipus().equals("MagVida")) {
            return true;
        }
        return false;
    }

    /**
     * 激活光环获取器
     * @return 是否激活
     */
    @Override
    public boolean isAuraActiva() {
        return auraActiva;
    }

    /**
     * 激活光环设置器
     * @param auraActiva 是否激活
     */
    @Override
    public void setAuraActiva(boolean auraActiva) {
        this.auraActiva = auraActiva;
    }

    /**
     * 设置光环透明度
     * @param alphaAura 透明度
     */
    public void setAlphaAura(float alphaAura) {
        this.alphaAura = alphaAura;
    }

    /**
     * 动画获取器
     * @return 动画
     */
    public Animation getAnimation() {
        return animation;
    }

    /**
     * 动画设置器
     * @param animation 动画
     */
    public void setAnimation(Animation animation) {
        this.animation = animation;
    }

    /**
     * 光环获取器
     * @return 光环
     */
    public Aura getAura() {
        return aura;
    }

    /**
     * 光环设置器
     * @param aura 光环
     */
    public void setAura(Aura aura) {
        this.aura = aura;
    }

    /**
     * 生命值获取器
     * @return 生命值
     */
    public float getVida() {
        return vida;
    }

    /**
     * 生命值设置器
     * @param vida 生命值
     */
    public void setVida(float vida) {
        this.vida = vida;
    }

    /**
     * 总生命值获取器
     * @return 总生命值
     */
    public float getVidaTotal() {
        return vidaTotal;
    }

    /**
     * 总生命值设置器
     * @param vidaTotal 总生命值
     */
    public void setVidaTotal(float vidaTotal) {
        this.vidaTotal = vidaTotal;
    }
}