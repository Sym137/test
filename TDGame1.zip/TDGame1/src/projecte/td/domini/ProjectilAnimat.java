package projecte.td.domini;

import org.newdawn.slick.Animation;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;
import projecte.td.managers.ManagerRecursos;

/**
 * 动画子弹类：具有由动画表示移动效果的子弹。
 * @author
 */
public class ProjectilAnimat extends Projectil implements Cloneable {

    private Animation animation; // 动画
    private int milisegons; // 毫秒数，用于动画帧的切换

    /**
     * 动画子弹类的构造函数
     * @param dany 伤害值
     * @param frames 动画帧图像数组
     * @param milisegons 每帧动画的持续时间（毫秒）
     */
    public ProjectilAnimat(double dany, Image[] frames, int milisegons) {
        super(dany);
        this.milisegons = milisegons;
        this.animation = new Animation(frames, milisegons);
    }

    /**
     * 改变子弹的位置
     * @param posX X坐标
     * @param posY Y坐标
     */
    @Override
    public void setLocation(float posX, float posY) {
        super.posX = posX;
        super.posY = posY;
        super.shape = new Rectangle(posX, posY, animation.getWidth(), animation.getHeight());
    }

    /**
     * 更新子弹状态
     * @param delta 时间增量
     */
    @Override
    public void update(int delta) {
        if (posX > 1024) {
            mort = true; // 如果子弹超出屏幕范围，则标记为“已死亡”
        } else {
            posX += 0.4 * delta; // 否则，根据时间增量移动子弹
            shape.setLocation(posX, posY); // 更新子弹形状的位置
        }
    }

    /**
     * 渲染子弹
     * @param gc 游戏容器
     * @param g 图形上下文
     */
    @Override
    public void render(GameContainer gc, Graphics g) {
        g.drawAnimation(animation, posX, posY); // 在指定位置绘制动画
    }

    /**
     * 复制子弹
     * @return 复制的子弹对象
     */
    @Override
    public Object clone() {
        return new ProjectilAnimat(dany, ManagerRecursos.getImageArray("motoristaAnimation"), milisegons);
    }

    /**
     * 获取复制的子弹（作为Projectil类型）
     * @return 复制的子弹
     */
    @Override
    public Projectil cloneProjectil() {
        Projectil p = (Projectil) clone(); // 复制子弹
        p.setLocation(posX, posY); // 设置复制子弹的位置
        return p;
    }

    /**
     * 执行撞击效果
     */
    @Override
    public void impacte() {
        // 此处可添加撞击时的具体实现，例如播放声音、产生特效等
    }
}
