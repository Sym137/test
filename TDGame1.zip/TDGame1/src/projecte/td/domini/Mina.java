package projecte.td.domini;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;

/**
 * 类 矿：友军单位 矿。
 * @author
 */
public class Mina extends UnitatAbstract implements InterficieBomba {

    private Projectil projectil;//矿的弹药
    private boolean dispara;
    private Timer timer;//激活时间计时器
    private boolean activa;

    /**
     * 矿的构造函数
     * @param vida 生命值
     * @param frames 动画帧
     * @param milisegons 时间间隔
     * @param projectil 弹药
     */
    public Mina(int vida, Image[] frames, int milisegons, Projectil projectil) {
        super(vida, frames, milisegons);
        this.projectil = projectil;
        timer = new Timer(5000, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                activa = true;
            }
        });
        timer.setRepeats(false);
        timer.start();
    }

    /**
     * 改变矿的位置
     * @param posX X坐标
     * @param posY Y坐标
     */
    @Override
    public void setLocation(float posX, float posY) {
        super.setLocation(posX, posY);
        projectil.setLocation(0, 0);
    }

    /**
     * 更新单位
     * @param delta 时间差
     */
    @Override
    public void update(int delta) {
    }

    /**
     * 处理冲击
     * @param dany 伤害值
     */
    @Override
    public void impacte(double dany) {
        if (activa) {
            dispara = true;
            projectil.setLocation(posX - ((projectil.getWidth() - shape.getWidth()) / 2), posY + shape.getHeight() - projectil.getHeight() + 5);
        }
    }

    /**
     * 绘制单位
     * @param gc GameContainer
     * @param g Graphics
     */
    @Override
    public void render(GameContainer gc, Graphics g) {
        renderVida(gc, g);
        if (!activa) {
            Image image = animation.getImage(0);
            g.drawImage(image, posX, posY);
        } else {
            g.drawAnimation(animation, posX, posY);
        }
    }

    /**
     * 射击完成
     */
    public void haDisparat() {
        dispara = false;
        mort = true;
    }

    /**
     * 获取是否射击
     * @return dispara
     */
    public boolean isDispara() {
        return dispara;
    }

    /**
     * 设置是否射击
     * @param dispara
     */
    public void setDispara(boolean dispara) {
        this.dispara = dispara;
    }

    /**
     * 获取弹药
     * @return projectil
     */
    public Projectil getProjectil() {
        return projectil;
    }

    /**
     * 设置弹药
     * @param projectil
     */
    public void setProjectil(Projectil projectil) {
        this.projectil = projectil.cloneProjectil();
    }

}