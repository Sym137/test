package projecte.td.domini;

import org.newdawn.slick.Image;

/**
 * 类 UnitatAigua: 用于消灭雪花球的友方单位。
 * @作者
 */
public class UnitatAigua extends UnitatAbstract {

    /**
     * UnitatAigua 类的构造函数
     * @param vida 生命值
     * @param frames 动画帧数组
     * @param framesMort 死亡动画帧数组
     * @param milisegons 每帧的时间（毫秒）
     */
    public UnitatAigua(int vida, Image[] frames, Image[] framesMort, int milisegons) {
        super(vida, frames, framesMort, milisegons);
    }
}
