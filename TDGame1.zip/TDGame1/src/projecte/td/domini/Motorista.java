package projecte.td.domini;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;

/**
 * 骑行者类：友方单位，在第一次接触时会迅速离开。
 * @author
 */
public class Motorista extends UnitatAbstract implements InterficieBomba {

    private Projectil projectil; // 要发射的子弹
    private boolean dispara;

    /**
     * 骑行者类的构造函数
     * @param vida 生命值
     * @param frames 动画帧
     * @param milisegons 动画时间
     * @param projectil 子弹
     * @param sound 声音
     */
    public Motorista(int vida, Image[] frames, int milisegons, Projectil projectil) {
        super(vida, frames, milisegons);
        this.projectil = projectil;
    }

    /**
     * 改变单位的位置
     * @param posX X坐标
     * @param posY Y坐标
     */
    @Override
    public void setLocation(float posX, float posY) {
        super.setLocation(posX, posY);
        projectil.setLocation(posX, posY);
    }

    /**
     * 更新单位状态
     * @param delta 时间增量
     */
    @Override
    public void update(int delta) {
    }

    /**
     * 对单位造成影响
     * @param dany 伤害
     */
    @Override
    public void impacte(double dany) {
        vida -= 1;
        dispara = true;
    }

    /**
     * 渲染单位
     * @param gc GameContainer
     * @param g Graphics
     */
    @Override
    public void render(GameContainer gc, Graphics g) {
        renderVida(gc, g);
        g.drawAnimation(animation, posX, posY);
    }

    /**
     * 发射结束
     */
    public void haDisparat() {
        dispara = false;
        mort = true;
    }

    /**
     * 获取是否发射
     * @return 是否发射
     */
    public boolean isDispara() {
        return dispara;
    }

    /**
     * 设置是否发射
     * @param dispara 是否发射
     */
    public void setDispara(boolean dispara) {
        this.dispara = dispara;
    }

    /**
     * 获取子弹
     * @return 子弹
     */
    public Projectil getProjectil() {
        return projectil.cloneProjectil();
    }

    /**
     * 设置子弹
     * @param projectil 子弹
     */
    public void setProjectil(Projectil projectil) {
        this.projectil = projectil.cloneProjectil();
    }

}