package projecte.td.domini;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.geom.Shape;

/**
 * Entitat 类.
 * @author
 */
public abstract class Entitat {

    float posX; //X 坐标位置
    float posY; //Y 坐标位置
    boolean mort;//是否死亡
    Shape shape; //表示实体的几何图形

    public Entitat() {
    }

    /**
     * 更新实体
     * @param delta 时间增量
     */
    public abstract void update(int delta);

    /**
     * 渲染实体
     * @param gc GameContainer
     * @param g Graphics
     */
    public abstract void render(GameContainer gc, Graphics g);

    /**
     * 更改实体的位置。
     * @param x X坐标
     * @param y Y坐标
     */
    public abstract void setLocation(float x, float y);

    /**
     * 检查此实体的形状是否与另一个形状相交。
     * @param s 另一个形状
     * @return 如果相交则返回 true
     */
    public boolean collideWith(Shape s) {
        if (shape.intersects(s)) {
            return true;
        }
        return false;
    }

    /**
     * Getter mort
     * @return
     */
    public boolean isMort() {
        return mort;
    }

    /**
     * Setter mort
     * @param mort
     */
    public void setMort(boolean mort) {
        this.mort = mort;
    }

    /**
     * Getter posX
     * @return Posx
     */
    public float getPosX() {
        return posX;
    }

    /**
     * Setter posY
     * @param posX
     */
    public void setPosX(float posX) {
        this.posX = posX;
    }

    /**
     * Getter posY
     * @return posy
     */
    public float getPosY() {
        return posY;
    }

    /**
     * Setter posY
     * @param posY
     */
    public void setPosY(float posY) {
        this.posY = posY;
    }

    /**
     * Getter Shape
     * @return shape
     */
    public Shape getShape() {
        return shape;
    }

    /**
     * Setter shape
     * @param shape
     */
    public void setShape(Shape shape) {
        this.shape = shape;
    }

    /**
     * Getter Height
     * @return height
     */
    public float getHeight() {
        return shape.getHeight();
    }

    /**
     * Getter width
     * @return width
     */
    public float getWidth() {
        return shape.getWidth();
    }
}
