package projecte.td.domini;

import org.newdawn.slick.Animation;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;

/**
 * 类 UnitatEnemigaAtkDistanciaSalta: 跳跃并射击的敌方单位
 * @author
 */
public class UnitatEnemigaAtkDistanciaSalta extends UnitatEnemigaAtkDistancia {

    private boolean salta; // 正在跳跃或不
    private boolean haRebutImpacte; // 是否受到过撞击
    private int ySalt; // 跳跃的高度
    private Animation salt; // 跳跃的动画
    private boolean primeraMort; // true 如果已经“死亡”过一次

    /**
     * 构造函数 UnitatEnemigaAtkDistanciaSalta
     * @param vida 生命值
     * @param cadencia 射击频率
     * @param frames 动画帧
     * @param framesMort 死亡动画帧
     * @param milisegons 每帧的时间（毫秒）
     * @param projectil 射击的静态项目
     * @param frames2 动画帧2
     * @param velocitat 速度
     * @param milisegonsAtck 攻击动画每帧的时间（毫秒）
     * @param posXProj 射击项目的 x 位置
     * @param posYProj 射击项目的 y 位置
     * @param frames3 跳跃动画帧
     */
    public UnitatEnemigaAtkDistanciaSalta(int vida, int cadencia, Image[] frames, Image[] framesMort, int milisegons, ProjectilEstatic projectil, Image[] frames2, double velocitat, int milisegonsAtck, float posXProj, float posYProj, Image[] frames3) {
        super(vida, cadencia, frames, framesMort, milisegons, projectil, frames2, velocitat, milisegonsAtck, posXProj, posYProj);
        salt = new Animation(frames3, 100);
    }

    /**
     * 单位受到撞击
     * @param dany 损伤
     */
    @Override
    public void impacte(double dany) {
        super.impacte(dany);
        // 观察第一次撞击
        if (!haRebutImpacte) {
            haRebutImpacte = true;
            salta = true;
        }
    }

    /**
     * 已经跳跃
     */
    public void haSaltat() {
        salta = false;
    }

    /**
     * Getter salta
     * @return
     */
    public boolean isSaltant() {
        return salta;
    }

    /**
     * 随机计算跳跃的高度
     * @param llargadaTotal 总长度
     */
    public void calculaSalt(int llargadaTotal) {
        ySalt = (int) (Math.random() * llargadaTotal);
    }

    /**
     * Getter 跳跃高度
     * @return
     */
    public int getySalt() {
        return ySalt;
    }

    /**
     * 绘制单位
     * @param gc GameContainer
     * @param g Graphics
     */
    @Override
    public void render(GameContainer gc, Graphics g) {
        renderVida(gc, g);
        // 如果激活了，绘制攻击动画
        if (activat) {
            g.drawAnimation(atck, posX, posY);
        } // 如果正在跳跃，显示跳跃动画
        else if (salta) {
            g.drawAnimation(salt, posX, posY);
            salt.setLooping(false);
        } // 如果既没有激活，也没有跳跃，显示正常动画
        else {
            g.drawAnimation(animation, posX, posY);
        }
    }

    /**
     * 观察跳跃动画是否已经结束
     * @return
     */
    public boolean haFinalitzatAnimacio() {
        return salt.isStopped();
    }

    /**
     * 观察单位是否死亡
     * @return
     */
    @Override
    public boolean isMort() {
        // 第一次死亡，跳跃前
        if (!primeraMort && mort) {
            primeraMort = true;
            return true;
        } // 第二次死亡
        else {
            if (animation_mort != null) {
                if (mort && animation_mort.isStopped()) {
                    return true;
                }
            } else {
                if (mort) {
                    return true;
                }
            }
            return false;
        }
    }
}
