package projecte.td.domini;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;
import projecte.td.managers.ManagerPerfil;

/**
 * 敌方单位类 Bola Neu: 敌方单位 Bola Neu。
 * @author Ernest Daban 和 David Alvarez
 */
public class UnitatEnemigaBolaNeu extends UnitatEnemigaAtkNormal {

    /**
     * 构造函数 UnitatEnemigaBolaNeu
     * @param vida 生命值
     * @param frames 动画帧
     * @param framesMort 死亡动画帧
     * @param milisegons 动画帧的持续时间
     * @param velocitat 速度
     * @param dany 伤害
     */
    public UnitatEnemigaBolaNeu(int vida, Image[] frames, Image[] framesMort, int milisegons, double velocitat, double dany) {
        super(vida, frames, framesMort, milisegons, velocitat, dany);
    }

    /**
     * 更新单位
     * @param delta 自上次更新以来的时间（毫秒）
     */
    @Override
    public void update(int delta) {
        if (posX <= 0 - getWidth() / 2) {
            haArribat = true;
        }
        posX -= velocitat * delta;
        setLocation(posX, posY);
    }

    /**
     * 绘制单位
     * @param gc GameContainer
     * @param g Graphics
     */
    @Override
    public void render(GameContainer gc, Graphics g) {
        renderVida(gc, g);
        g.drawAnimation(animation, posX, posY);
        if (activat) {
            if (!animation.isStopped() && !soAcabat && animation.getFrame() == 0) {
                soAcabat = true;
            }

        }
        if (animation.getFrame() == animation.getFrameCount() - 1) {
            soAcabat = false;

        }
    }

    /**
     * 接受热水攻击
     */
    public void rebreAigua() {
        impacte(vida);
    }
}