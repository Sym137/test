package projecte.td.domini;

import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;

/**
 * 类 Bomba: 友方单位，地面炸弹。
 * @author
 */
public class Bomba extends UnitatAbstract implements InterficieBomba {

    private Projectil projectil; // 要发射的子弹
    private boolean dispara; // 是否发射

    /**
     * 炸弹构造函数
     * @param vida 生命值
     * @param frames 帧数组
     * @param milisegons 毫秒数
     * @param projectil 子弹对象
     */
    public Bomba(int vida, Image[] frames, int milisegons, Projectil projectil) {
        super(vida, frames, milisegons);
        animation.setLooping(false);
        this.projectil = projectil;
    }

    /**
     * 更改位置
     * @param posX X坐标
     * @param posY Y坐标
     */
    @Override
    public void setLocation(float posX, float posY) {
        super.setLocation(posX, posY);
        projectil.setLocation(0, posY);
    }

    /**
     * 更新单位状态
     * @param delta 时间delta
     */
    @Override
    public void update(int delta) {
        if (animation.getFrame() < 9) {
            posX += 1;
        } else if (animation.isStopped()) {
            dispara = true;
        }
    }

    /**
     * 发射完成
     */
    public void haDisparat() {
        dispara = false;
        mort = true;
    }

    /**
     * 获取是否发射
     * @return dispara
     */
    public boolean isDispara() {
        return dispara;
    }

    /**
     * 设置是否发射
     * @param dispara
     */
    public void setDispara(boolean dispara) {
        this.dispara = dispara;
    }

    /**
     * 获取子弹对象
     * @return projectil
     */
    public Projectil getProjectil() {
        return projectil;
    }

    /**
     * 设置子弹对象
     * @param projectil
     */
    public void setProjectil(Projectil projectil) {
        this.projectil = projectil.cloneProjectil();
    }
}