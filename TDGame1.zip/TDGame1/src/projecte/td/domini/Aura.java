package projecte.td.domini;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import org.newdawn.slick.Image;

/**
 * 类 Aura：用于放置在友方单位上的光环。
 * @author Ernest Daban 和 David Alvarez
 */
public class Aura {

    private String tipus; // 光环类型
    private Image image; // 光环图像
    private int capacitat; // 光环能力值
    UnitatAbstract bo; // 光环将放置的单位
    Timer timer; // 计时器

    /**
     * Aura 构造函数
     * @param tipus 光环类型
     * @param image 光环图像
     * @param capacitat 光环能力值
     */
    public Aura(String tipus, Image image, int capacitat) {
        this.tipus = tipus;
        this.image = image;
        this.capacitat = capacitat;
    }

    /**
     * 激活光环
     */
    public void activarAura() {
        if (tipus.equals("MagRapidesa")) { // 如果光环类型是增加攻击速度
            if (bo instanceof Miner) { // 如果光环作用于矿工
                Miner miner = (Miner) bo;
                miner.setCadencia(miner.getCadencia() / capacitat); // 减少攻击间隔
                miner.ajustarTimer(); // 调整计时器
            } else if (bo instanceof UnitatDispara) { // 如果光环作用于射击单位
                UnitatDispara ud = (UnitatDispara) bo;
                ud.setCadencia(ud.getCadencia() / capacitat); // 减少攻击间隔
                ud.ajustarTimer(); // 调整计时器
            }
        } else if (tipus.equals("MagVida")) { // 如果光环类型是增加生命值
            timer = new Timer(500, new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    if (bo.getVida() <= bo.getVidaTotal() + 1) { // 如果生命值未超过上限
                        bo.setVida(bo.getVida() + 1); // 增加生命值
                    }
                }
            });
            timer.start(); // 启动计时器
        }
    }

    /**
     * 停用光环
     */
    public void desactivarAura() {
        if (tipus.equals("MagRapidesa")) { // 如果光环类型是增加攻击速度
            //bo.setCadencia(bo.getCadencia() * capacitat); // 恢复攻击间隔（注释掉了）
        } else if (tipus.equals("MagVida")) { // 如果光环类型是增加生命值
            timer.stop(); // 停止计时器
            timer = null; // 清除计时器
        }
    }

    /**
     * 获取友方单位
     * @return bo 单位
     */
    public UnitatAbstract getBo() {
        return bo;
    }

    /**
     * 设置友方单位
     * @param bo 单位
     */
    public void setBo(UnitatAbstract bo) {
        this.bo = bo;
    }

    /**
     * 获取图像
     * @return 图像
     */
    public Image getImage() {
        return image;
    }

    /**
     * 设置图像
     * @param image 图像
     */
    public void setImage(Image image) {
        this.image = image;
    }

    /**
     * 获取光环类型
     * @return 光环类型
     */
    public String getTipus() {
        return tipus;
    }

    /**
     * 设置光环类型
     * @param tipus 光环类型
     */
    public void setTipus(String tipus) {
        this.tipus = tipus;
    }
}
