package projecte.td.domini;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;

/*
*
 炸弹飞机类：友军单位，从空中投下的炸弹。
 @author
 */
public class BombaAerea extends UnitatAbstract implements InterficieBomba {

    private float posicioYExplosio;// 爆炸最终位置
    private Projectil projectil;// 要发射的子弹
    private boolean dispara; // 是否发射

    /**

    /**
     *炸弹飞机构造函数
     * @param vida
     * @param frames
     * @param milisegons
     * @param projectil
     * @param sound
     */
    public BombaAerea(int vida, Image[] frames, int milisegons, Projectil projectil) {
        super(vida, frames, milisegons);
        this.projectil = projectil;
    }

    /**
     * 更改单位的位置
     * @param posX X坐标
     * @param posY Y坐标
     */
    @Override
    public void setLocation(float posX, float posY) {
        posicioYExplosio = posY;
        super.setLocation(posX, -20);
        projectil.setLocation(0, 0);
    }

    /**
     * 更新单位状态
     * @param delta 时间间隔
     */
    @Override
    public void update(int delta) {
        float y = super.getPosY();
        y += 4;
        super.setLocation(posX, y);
        // 当到达最终位置时，准备爆炸
        if (posY >= posicioYExplosio) {
            projectil.setLocation(posX - ((projectil.getWidth() - shape.getWidth()) / 2), posicioYExplosio + shape.getHeight() - projectil.getHeight() + 5);
            dispara = true;
        }
    }

    /**
     * 处理撞击效果
     * @param dany 撞击伤害
     */
    @Override
    public void impacte(double dany) {
    }

    /**
     * 渲染单位
     * @param gc 游戏容器
     * @param g 图形对象
     */
    @Override
    public void render(GameContainer gc, Graphics g) {
        g.drawAnimation(animation, posX, posY);

    }

    /**
     * 发射完毕
     */
    public void haDisparat() {
        dispara = false;
        mort = true;
    }

    /**
     * Getter dispara
     * @return
     */
    public boolean isDispara() {
        return dispara;
    }

    /**
     * Setter dispara
     * @param dispara
     */
    public void setDispara(boolean dispara) {
        this.dispara = dispara;
    }

    /**
     * Getter projectil
     * @return
     */
    public Projectil getProjectil() {
        return projectil;
    }

    /**
     * Setter projectil
     * @param projectil
     */
    public void setProjectil(Projectil projectil) {
        this.projectil = projectil.cloneProjectil();
    }

}
