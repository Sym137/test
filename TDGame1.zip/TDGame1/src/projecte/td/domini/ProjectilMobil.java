package projecte.td.domini;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;

/**
 * 类 ProjectilMobil: 代表一个带有移动的子弹，使用图像表示。
 * @author
 */
public class ProjectilMobil extends Projectil implements Cloneable {

    protected Image image;

    /**
     * ProjectilMobil 类的构造函数
     * @param dany 伤害值
     * @param image 子弹的图像
     */
    public ProjectilMobil(double dany, Image image) {
        super(dany);
        this.image = image;
    }

    /**
     * 改变子弹的位置
     * @param posX X坐标
     * @param posY Y坐标
     */
    @Override
    public void setLocation(float posX, float posY) {
        super.setLocation(posX, posY);
        super.shape = new Rectangle(posX, posY, image.getWidth(), image.getHeight());
    }

    /**
     * 更新子弹的状态
     * @param delta 时间增量
     */
    @Override
    public void update(int delta) {
        if (posX > 1024) {
            mort = true;
        } else {
            posX += 0.2 * delta;
            shape.setLocation(posX, posY);
        }
    }

    /**
     * 渲染子弹
     * @param gc GameContainer对象
     * @param g Graphics对象
     */
    @Override
    public void render(GameContainer gc, Graphics g) {
        g.drawImage(image, posX, posY);
    }

    /**
     * 克隆子弹
     * @return 克隆出的子弹
     */
    @Override
    public Object clone() {
        return new ProjectilMobil(dany, image);
    }

    /**
     * 获取克隆的子弹
     * @return 子弹对象
     */
    public Projectil cloneProjectil() {
        Projectil p = (Projectil) clone();
        p.setLocation(posX, posY);
        return p;
    }

    /**
     * 产生碰撞
     */
    public void impacte() {
        this.mort = true;
    }
}
