package projecte.td.domini;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;
import projecte.td.managers.ManagerPerfil;

/**
 * 类 UnitatEnemigaVola：出现在棋盘上飞行的敌方单位。
 * @author
 */
public class UnitatEnemigaVola extends UnitatEnemigaAtkNormal {

    private float posYFinal;
    private boolean inici;
    private float posXVol;
    private int contadorSo;

    /**
     * UnitatEnemigaVola 构造函数
     * @param vida
     * @param frames
     * @param framesMort
     * @param milisegons
     * @param velocitat
     * @param dany
     * @param soAtck
     */
    public UnitatEnemigaVola(int vida, Image[] frames, Image[] framesMort, int milisegons, double velocitat, double dany) {
        super(vida, frames, framesMort, milisegons, velocitat, dany);
        calcularVol();

    }

    /**
     * 计算飞行的位置
     */
    public void calcularVol() {
        posXVol = (int) (Math.random() * 600) + 400;
    }

    /**
     * 更改单位的位置
     * @param posX
     * @param posY
     */
    @Override
    public void setLocation(float posX, float posY) {
        if (!inici) {
            posYFinal = posY;
            inici = true;
            super.setLocation(posXVol, 0);
        } else {
            super.setLocation(posXVol, posY);
        }


    }

    /**
     * 更新单位
     * @param delta
     */
    @Override
    public void update(int delta) {
        if (posX <= 0 - getWidth() / 2) {
            haArribat = true;
        }
        if (!activat) {
            if (posYFinal > posY) {
                posY += velocitat * delta;
                setLocation(posXVol, posY);
            } else if (posYFinal <= posY) {
                posXVol -= velocitat * delta;
                setLocation(posXVol, posY);
            }
        }
    }

    /**
     * 渲染单位
     * @param gc
     * @param g
     */
    @Override
    public void render(GameContainer gc, Graphics g) {
        renderVida(gc, g);
        g.drawAnimation(animation, posX, posY);
        if (activat) {
            if (!animation.isStopped() && !soAcabat && animation.getFrame() == 0) {

                soAcabat = true;
            }

        }
        if (animation.getFrame() == animation.getFrameCount() - 1 && contadorSo % 20 == 0) {
            soAcabat = false;

        }
        contadorSo++;
    }
}
