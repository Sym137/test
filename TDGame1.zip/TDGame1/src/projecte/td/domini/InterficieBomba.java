package projecte.td.domini;

import org.newdawn.slick.Sound;

/**
 * Bomba 接口：用于所有作为炸弹的友军单位。
 * @author
 */
public interface InterficieBomba {

    public void haDisparat();

    public boolean isDispara();

    public void setDispara(boolean dispara);

    public Projectil getProjectil();

    public void setProjectil(Projectil projectil);

}