package projecte.td.componentIngame;

import java.util.ArrayList;
import org.newdawn.slick.Font;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.gui.GUIContext;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.estats.EstatGuanya;
import projecte.td.managers.ManagerRecursos;
import projecte.td.factories.FactoriaUnitatsEnemics;
import projecte.td.managers.ManagerDinersAures;
import projecte.td.managers.ManagerEnemics;
import projecte.td.managers.ManagerPerfil;

/**
 * 在游戏状态（EstatIngame）中使用的菜单
 * @author
 */
public class MenuIngame extends AbstractComponent {

    // MenuIngame将位于此上下文中
    private GUIContext gui;
    // 用于访问所需状态的状态容器
    private StateBasedGame state;
    // 代表菜单的图像
    private Image image;
    // 货币的图像
    private Image imatgeMoneda;
    // 光环的图像
    private Image imatgeAura;
    // 包含MenuIngame的区域
    private Shape area;
    // 存储菜单中可用的按钮Unitat的ArrayList
    private ArrayList<BotoIngame> botonsUnitat;
    // 用于保存按钮引用的按钮
    private BotoIngame botoAux;
    // 用于访问菜单和游戏选项的按钮
    private BotoMenu botoOpcions;
    // 铲子按钮的图像
    private BotoIngame botoPala;
    // 用于正确初始化buttonsUnitat和相应的图像
    private String unitats;
    // 指示正在等待定位的元素
    private String elementEsperant;
    // 指示可用的光环类型
    private String auraDisponible;
    // 标志，用于检查是否有待处理的元素
    private boolean enEspera;
    // 管理和控制游戏中玩家的金钱
    private ManagerDinersAures md;

    // 用于写入文本的字体
    private Font font;

    /**
     * 游戏菜单容器，允许在屏幕上选择要放置的元素
     * @param gui: 菜单将位于此上下文
     * @param posX: 菜单的X轴位置
     * @param posY: 菜单的Y轴位置
     * @param image: 代表菜单的图像
     * @param unitats: 可供选择的单位
     * @param md: 控制玩家金钱的管理者
     */
    public MenuIngame(GUIContext gui, int posX, int posY, Image image, String unitats, ManagerDinersAures md, StateBasedGame state) {
        super(gui);
        this.gui = gui;
        this.state = state;
        this.image = image;
        area = new Rectangle(posX, posY, image.getWidth(), image.getHeight());
        this.unitats = unitats;
        this.md = md;
  
        font = ManagerRecursos.getFont("dejavuNormalFont");
        imatgeMoneda = ManagerRecursos.getImage("monedaImage");
        init();
        crearBotonsUnitats();
        crearBotoMenu();
        afegirListener();
        crearBotoPala();
    }

    /**
     * 初始化基本组件
     */
    private void init() {
        botonsUnitat = new ArrayList<BotoIngame>();
        elementEsperant = "null";
    }

    /**
     * 渲染按钮的所有组件
     * @param gc : 渲染上下文
     * @param g : 用于渲染图像和动画的图形对象
     */
    public void render(GUIContext gc, Graphics g) {
        int xp = 0;
        int yp = 600;
        g.drawImage(image, xp, yp);
        for (BotoIngame b : botonsUnitat) {
            b.render(gui, g);
        }
        botoPala.render(gc, g);
        botoOpcions.render(container, g);
        g.setFont(font);
        g.drawImage(imatgeMoneda, 820, 625);
        g.drawString(md.getTotal() + "", 880, 625);
        if (auraDisponible.equals("MagVida")) {
            g.drawImage(imatgeAura, 940, 665);
        } else if (auraDisponible.equals("MagRapidesa")) {
            g.drawImage(imatgeAura, 940, 665);
        }
    }

    /**
     * 更新菜单和其中的buttonsUnitat
     */
    public void update() {
        for (BotoIngame b : botonsUnitat) {
            b.update(md.getTotal());
            if (b.isClicat()) {
                elementEsperant = b.getAccio();
                enEspera = true;
                botoAux = b;
            }
        }
        botoPala.update(md.getTotal());
        if (botoPala.isClicat()) {

            elementEsperant = botoPala.getAccio();
            enEspera = true;
            botoAux = botoPala;
        }
        if (md.isAuraEnEspera()) {
            auraDisponible = md.getTipusAuraEspera();
            if (auraDisponible.equals("MagVida")) {
                imatgeAura = ManagerRecursos.getImage("monedaVidaImage");
            } else if (auraDisponible.equals("MagRapidesa")) {
                imatgeAura = ManagerRecursos.getImage("monedaRapidesaImage");
            }
        } else {
            auraDisponible = "null";
        }
    }

    /**
     * 创建每个菜单所需的buttonsUnitat
     */
    private void crearBotonsUnitats() {
        String[] st = unitats.split("-");
        BotoIngame.setImatgeSeleccionat(ManagerRecursos.getImage("marcSeleccionatIngameImage"));
        BotoIngame.setImatgeNoSeleccionat(ManagerRecursos.getImage("marcIngameImage"));
        BotoIngame.setImatgeTapada(ManagerRecursos.getImage("noSeleccionableIngameImage"));
        int comptador = 0;
        for (String s : st) {
            int posX = (comptador * 90) + 40;
            BotoIngame boto = new BotoIngame(gui, ManagerRecursos.getImage("carta" + s + "Image"),
                    posX, 640, 200, true);
            boto.addListener(s);
            botonsUnitat.add(boto);
            comptador++;
        }
    }

    /**
     * 创建用于删除单位的铲子按钮
     */
    private void crearBotoPala() {
        BotoIngame.setImatgeSeleccionat2(ManagerRecursos.getImage("botoPalaSeleccionatImage"));
        BotoIngame.setImatgeNoSeleccionat2(ManagerRecursos.getImage("cartaPalaImage"));
        botoPala = new BotoIngame(gui, ManagerRecursos.getImage("botoPalaImage"), 822, 661, 0, false);
        botoPala.addListener("pala");
    }

    /**
     * 创建用于访问游戏菜单的按钮
     */
    private void crearBotoMenu() {
        botoOpcions = new BotoMenu(container, ManagerRecursos.getImage("botoPetitImage"), 420, 300);
        botoOpcions.setLocation(820, 705);
        botoOpcions.setMouseOverImage(ManagerRecursos.getImage("botoPetitOverImage"));
        botoOpcions.setImageText(ManagerRecursos.getImage("textMenuPetitImage"));

        botoOpcions.setActiu(true);
    }
    /**
     * 为按钮添加监听器
     */
    private void afegirListener() {
        botoOpcions.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatGuanya.ID);
                ManagerPerfil.sumaPerdudes();
                ManagerPerfil.guardarEstadistiques();
                ManagerEnemics.pararTimer();
            }
        });
    }

    /**
     * 重置所有buttonsUnitat的状态
     */
    public void reiniciarBotons() {
        for (BotoIngame b : botonsUnitat) {
            b.clear();
        }
        botoPala.clear();
    }

    /**
     * 重置菜单的一些变量
     */
    public void clear() {
        enEspera = false;
        elementEsperant = "null";
    }

    /**
     * 如果需要，从ManagerDiners中扣除金钱
     */
    public void realitzaTransaccio() {
        if (botoAux != null) {
            md.restarDiners(botoAux.getCost());
        }
        reiniciarBotons();
        botoAux.activarTimer();
        botoAux = null;

        ManagerPerfil.sumaUnitat();
    }

    /**
     * 将元素放置在指定位置
     * @param x : X轴位置
     * @param y: Y轴位置
     */
    public void setLocation(int x, int y) {
        if (area != null) {
            area.setX(x);
            area.setY(y);
        }
    }

    // Getters i setters
    public int getHeight() {
        return (int) (area.getMaxY() - area.getY());
    }

    public int getWidth() {
        return (int) (area.getMaxX() - area.getX());
    }

    public int getX() {
        return (int) area.getX();
    }

    public int getY() {
        return (int) area.getY();
    }

    public ArrayList<BotoIngame> getBotons() {
        return botonsUnitat;
    }

    public void setBotons(ArrayList<BotoIngame> botons) {
        this.botonsUnitat = botons;
    }

    public String getElementEsperant() {
        return elementEsperant;
    }

    public void setElementEsperant(String elementEsperant) {
        this.elementEsperant = elementEsperant;
    }

    public boolean isEnEspera() {
        return enEspera;
    }

    public void setEnEspera(boolean enEspera) {
        this.enEspera = enEspera;
    }

    public GUIContext getGui() {
        return gui;
    }

    public void setGui(GUIContext gui) {
        this.gui = gui;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public String getUnitats() {
        return unitats;
    }

    public void setUnitats(String unitats) {
        this.unitats = unitats;
    }

    public Object getElement() {
        return FactoriaUnitatsEnemics.getUnitatBona(elementEsperant);
    }
}
