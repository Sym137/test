package projecte.td.componentIngame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.gui.GUIContext;

/**
 * 这些是在游戏状态（EstatIngame）中使用的按钮
 * @author
 */
public class BotoIngame extends AbstractComponent {

    private static boolean botoSeleccionat;
    // 如果按钮可以点击，则显示的图像
    private static Image imatgeTapada;
    // 如果按钮被选中，则显示的图像
    private static Image imatgeSeleccionat;
    // 如果按钮未被选中，则显示的图像
    private static Image imatgeNoSeleccionat;
    // 如果按钮被选中，则显示的另一图像
    private static Image imatgeSeleccionat2;
    // 如果按钮未被选中，则显示的另一图像
    private static Image imatgeNoSeleccionat2;
    // 标识每个按钮的图像
    private Image imatgeNormal;
    // 标志，用以确定按钮是否可用
    private boolean disponible;
    // 标志，用以确定按钮是否被点击
    private boolean clicat;
    // 标志，用以确定按钮是否被选中
    private boolean seleccionat;
    // 标志，用以确定按钮的计时器是否激活
    private boolean timerActiu;
    // 用于按钮位置和点击事件控制的形状
    private Shape area;
    // 按钮代表的单位的成本
    private int cost;
    // 描述要执行的动作
    private String accio;
    // 用于在一段时间内禁用按钮
    private Timer timer;
    // 检查状态以渲染按钮
    private boolean cond;
    /**
     * 在游戏进行中（ingame）使用的按钮，用于选择要放置在场景中的单位或元素。
     * @param gui: 按钮将被放置的上下文
     * @param imatgeNormal: 代表按钮的图像
     * @param x : X轴位置
     * @param y : Y轴位置
     * @param cost : 按钮代表元素的成本
     */
    public BotoIngame(GUIContext gui, Image imatgeNormal, int x, int y, int cost, boolean cond) {
        super(gui);
        this.imatgeNormal = imatgeNormal;
        this.cost = cost;
        if (cond) {
            area = new Rectangle(x, y, imatgeSeleccionat.getWidth(), imatgeSeleccionat.getHeight());
        } else {
            area = new Rectangle(x, y, imatgeSeleccionat2.getWidth(), imatgeSeleccionat2.getHeight());
        }

        accio = "null";
        this.cond = cond;
    }

    /**
     * 检查按钮是否可用
     * @param diners : 购买元素所需的资金
     */
    public void update(int diners) {
        if (diners >= cost && !timerActiu) {
            disponible = true;
        } else {
            disponible = false;
        }
    }

    /**
     * 渲染按钮的所有组件
     * @param gc : 渲染上下文
     * @param g : 用于渲染图像和动画的图形对象
     */
    public void render(GUIContext gc, Graphics g) {
        Image img = null;
        Image imgN = null;
        int a=0;
        int b=0;
        int c=0;
        if (cond) {
            img = imatgeSeleccionat;
            imgN = imatgeNoSeleccionat;
            a=15;
            b=36;
            c=53;
        } else {
            img = imatgeSeleccionat2;
            imgN = imatgeNoSeleccionat2;
        }
        if (disponible && seleccionat) {
            g.drawImage(img, area.getX(), area.getY());
            g.drawImage(imatgeNormal, area.getX() + a, area.getY() + a);
        } else if (disponible) {
            g.drawImage(imgN, area.getX(), area.getY());
            g.drawImage(imatgeNormal, area.getX() + a, area.getY() + a);
        } else {
            g.drawImage(imgN, area.getX(), area.getY());
            g.drawImage(imatgeNormal, area.getX() + a, area.getY() + a);
            g.drawImage(imatgeTapada, area.getX() + b, area.getY() + c);
        }
    }

    /**
     * 将元素放置在指定位置
     * @param x : X轴位置
     * @param y: Y轴位置
     */
    public void setLocation(int x, int y) {
        if (area != null) {
            area.setX(x);
            area.setY(y);
        }
    }

    /**
     * 检查鼠标是否点击了此元素
     * @param button : 被点击的按钮
     * @param mx : 鼠标点击时的X位置
     * @param my : 鼠标点击时的Y位置
     */
    @Override
    public void mousePressed(int button, int mx, int my) {
        if (area.contains(mx, my)) {
            notifyListeners();
        }
    }

    /**
     * 重置一些变量的值
     */
    public void clear() {
        accio = "null";
        clicat = false;
        seleccionat = false;
        botoSeleccionat = false;
    }

    /**
     * 为此按钮添加监听器
     * @param unitat
     */
    public void addListener(final String unitat) {
        addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (disponible && !botoSeleccionat) {
                    botoSeleccionat = true;
                    clicat = true;
                    seleccionat = true;
                    accio = unitat;
                }
            }
        });
    }

    /**
     * 激活计时器，以在一定时间内禁用按钮
     */
    public void activarTimer() {
        disponible = false;
        timerActiu = true;
        timer = new Timer(3000, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                clear();
                timerActiu = false;
            }
        });
        timer.start();
        timer.setRepeats(false);
    }

    // Getters i setters
    public void setClicat(boolean clicat) {
        this.clicat = clicat;
    }

    public boolean isClicat() {
        return clicat;
    }

    public int getHeight() {
        return (int) (area.getMaxY() - area.getY());
    }

    public int getWidth() {
        return (int) (area.getMaxX() - area.getX());
    }

    public int getX() {
        return (int) area.getX();
    }

    public int getY() {
        return (int) area.getY();
    }

    public String getAccio() {
        return accio;
    }

    public void setAccio(String accio) {
        this.accio = accio;
    }

    public Shape getArea() {
        return area;
    }

    public void setArea(Shape area) {
        this.area = area;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public Image getImatgeNormal() {
        return imatgeNormal;
    }

    public void setImatgeNormal(Image imatgeNormal) {
        this.imatgeNormal = imatgeNormal;
    }

    public static Image getImatgeSeleccionat() {
        return imatgeSeleccionat;
    }

    public static void setImatgeSeleccionat(Image imatgeSeleccionat) {
        BotoIngame.imatgeSeleccionat = imatgeSeleccionat;
    }

    public static Image getImatgeTapada() {
        return imatgeTapada;
    }

    public static void setImatgeTapada(Image imatgeTapada) {
        BotoIngame.imatgeTapada = imatgeTapada;
    }

    public boolean isSeleccionat() {
        return seleccionat;
    }

    public void setSeleccionat(boolean seleccionat) {
        this.seleccionat = seleccionat;
    }

    public static Image getImatgeNoSeleccionat() {
        return imatgeNoSeleccionat;
    }

    public static void setImatgeNoSeleccionat(Image imatgeNoSeleccionat) {
        BotoIngame.imatgeNoSeleccionat = imatgeNoSeleccionat;
    }

    public static void setImatgeNoSeleccionat2(Image imatgeNoSeleccionat2) {
        BotoIngame.imatgeNoSeleccionat2 = imatgeNoSeleccionat2;
    }

    public static void setImatgeSeleccionat2(Image imatgeSeleccionat2) {
        BotoIngame.imatgeSeleccionat2 = imatgeSeleccionat2;
    }
}
