package projecte.td.utilitats;

import java.io.FileOutputStream;
import java.net.URL;
import java.util.Properties;
import java.util.Set;
import org.newdawn.slick.util.ResourceLoader;

/**
 * 这个类负责将配置文件加载到内存中，并从中提取所需的数据。
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class ArxiuConfiguracio {

    // 读取值的对象
    private Properties propietats;
    // 配置文件的路径
    private String arxiu;

    /**
     * 根据给定的路径打开配置文件
     * @param referencia 配置文件所在路径
     */
    public ArxiuConfiguracio(String referencia) {
        boolean cond = false;
        while (!cond) {
            try {
                propietats = new Properties();
                URL url = ResourceLoader.getResource(referencia);
                arxiu = url.toURI().getPath();
                propietats.load(url.openStream());
                cond = true;

            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }

    /**
     * 将数据保存到配置文件
     */
    public void guardar() {
        try {
            propietats.store(new FileOutputStream(arxiu), "Configuracio");
        } catch (Exception e) {
            throw new RuntimeException("无法保存文件: " + arxiu);
        }
    }

    // 获取器和设置器

    public String getPropietatString(String clau) {
        return propietats.getProperty(clau);
    }

    public void setPropietatString(String clau, String valor) {
        propietats.setProperty(clau, valor);
    }

    public Boolean getPropietatBoolean(String clau) {
        return Boolean.parseBoolean(propietats.getProperty(clau));
    }

    public void setPropietatBoolean(String clau, Boolean valor) {
        propietats.setProperty(clau, String.valueOf(valor));
    }

    public int getPropietatInt(String clau) {
        return Integer.parseInt(propietats.getProperty(clau));
    }

    public void setPropietatInt(String clau, int valor) {
        propietats.setProperty(clau, String.valueOf(valor));
    }

    public float getPropietatFloat(String clau) {
        Float f=null;
        String propietat=propietats.getProperty(clau);
        if(propietat.contains("-")){
            String[] linia=propietat.split("-");
            f=Float.parseFloat(linia[1]);
            f*=-1;
        }
        else{
            f=Float.parseFloat(propietat);
        }
        return f;
    }

    public void setPropietatFloat(String clau, float valor) {
        propietats.setProperty(clau, String.valueOf(valor));
    }

    public long getPropietatLong(String clau) {
        return Long.parseLong(propietats.getProperty(clau));
    }

    public void setPropietatLong(String clau, long valor) {
        propietats.setProperty(clau, String.valueOf(valor));
    }

    public double getDoublePropietat(String clau) {
        return Double.parseDouble(propietats.getProperty(clau));
    }

    public void setDoublePropietat(String clau, double valor) {
        propietats.setProperty(clau, String.valueOf(valor));
    }

    public Set<Object> getTotesPropietats() {
        return propietats.keySet();
    }

    public String getStringArxiu() {
        return arxiu;
    }
}