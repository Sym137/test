package projecte.td.utilitats;

/**
 * 负责在内存中加载不同的配置文件，并在适当的时候使用它们
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class Configuracio {

    // 在此文件中保存其他配置文件的路径
    private static ArxiuConfiguracio configuracio;
    // 敌人的特性
    private static ArxiuConfiguracio enemics;
    // 资源文件，包含图像、音频、音乐和字体的路径
    private static ArxiuConfiguracio recursos;
    // 游戏的一般选项
    private static ArxiuConfiguracio opcions;
    // 单位的特性
    private static ArxiuConfiguracio unitats;
    // 个人资料 1 的选项
    private static ArxiuConfiguracio perfil1;
    // 个人资料 2 的选项
    private static ArxiuConfiguracio perfil2;
    // 个人资料 3 的选项
    private static ArxiuConfiguracio perfil3;
    // 波次的特性
    private static ArxiuConfiguracio wave;

    // 该文件将在应用程序启动时静态加载
    static {
        configuracio = new ArxiuConfiguracio("config/td.cfg");
    }

    // 以下方法负责在内存中加载 ArxiuConfiguracio（如果尚未加载），然后在其他对象请求时返回它。
    public static ArxiuConfiguracio getPerfil1() {
        if (perfil1 == null) {
            perfil1 = new ArxiuConfiguracio(configuracio.getPropietatString("perfil1"));
        }
        return perfil1;
    }

    public static ArxiuConfiguracio getPerfil2() {
        if (perfil2 == null) {
            perfil2 = new ArxiuConfiguracio(configuracio.getPropietatString("perfil2"));
        }
        return perfil2;
    }

    public static ArxiuConfiguracio getPerfil3() {
        if (perfil3 == null) {
            perfil3 = new ArxiuConfiguracio(configuracio.getPropietatString("perfil3"));
        }
        return perfil3;
    }

    public static ArxiuConfiguracio getWaves() {
        if (wave == null) {
            wave = new ArxiuConfiguracio(configuracio.getPropietatString("wave"));
        }
        return wave;
    }

    public static ArxiuConfiguracio getRecursos() {
        if (recursos == null) {
            recursos = new ArxiuConfiguracio(configuracio.getPropietatString("recursos"));
        }
        return recursos;
    }

    public static ArxiuConfiguracio getOpcions() {
        if (opcions == null) {
            opcions = new ArxiuConfiguracio(configuracio.getPropietatString("opcions"));
        }
        return opcions;
    }

    public static ArxiuConfiguracio getUnitats() {
        if (unitats == null) {
            unitats = new ArxiuConfiguracio(configuracio.getPropietatString("unitats"));
        }
        return unitats;
    }

    public static ArxiuConfiguracio getEnemics() {
        if (enemics == null) {
            enemics = new ArxiuConfiguracio(configuracio.getPropietatString("enemics"));
        }
        return enemics;
    }
}
