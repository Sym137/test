package projecte.td.managers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.Timer;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import projecte.td.domini.UnitatAbstract;
import projecte.td.factories.FactoriaUnitatsEnemics;
import projecte.td.utilitats.ArxiuConfiguracio;
import projecte.td.utilitats.Configuracio;

/**
 * 这个管理器负责提取波次中应该出现的敌人，并调整每个敌人的出发时间。
 * 在波次开始时激活一个计时器，并在游戏胜利或失败后停止。
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class ManagerEnemics {

    // 当前波次的ID
    private static int waveActual;
    // 波次总持续时间
    private static int tempsTotal;
    // 辅助变量，存储之前要添加的时间
    private static int tempsAnterior;
    // 包含当前波次特性的文件
    private static ArxiuConfiguracio propietatsWave;
    // 包含敌人特性的文件
    private static ArxiuConfiguracio enemics;
    // 将出现的敌人波次
    private static String enemicsWave;
    // 将出现的所有敌人列表
    private static List llistaEnemics;
    // 用于在敌人开始出现前倒计时的计时器
    private static Timer timerInici;
    // 用于触发每个敌人出发的计时器
    private static Timer timer;
    // 指示是否有敌人等待出发
    private static boolean unitatEsperant;
    // 指示波次是否处于初始阶段
    private static boolean inici;
    // 指示在波次开始时是否显示“Go”图像
    private static boolean mostraCartell;
    // 指示等待出发的敌人类型
    private static String unitatEnEspera;
    // 当波次开始时显示的图像
    private static Image iniciWaveImatge;

    /**
     * 初始化组织波次所需的值
     * @param wave 要进行的波次编号
     */
    public static void iniciaWave(int wave) {
        waveActual = wave;
        // 获取配置文件
        propietatsWave = Configuracio.getWaves();
        enemics = Configuracio.getEnemics();
        enemicsWave = propietatsWave.getPropietatString("enemicsWave" + waveActual);
        tempsTotal = propietatsWave.getPropietatInt("temps" + waveActual);
        llistaEnemics = new ArrayList();
        tempsAnterior = 0;
        inici = true;
        iniciWaveImatge = ManagerRecursos.getImage("iniciWaveImage");
        carregaEnemics();
    }

    /**
     * 负责处理信息并创建将出现的敌人列表。一旦列表创建完成，将按时间排序。
     */
    private static void carregaEnemics() {
        if (timer != null && timer.isRunning()) {
            timer.stop();
        }
        String[] unitats = enemicsWave.split("-");
        for (String z : unitats) {
            String[] informacio = z.split(":");
            int totalUnitats = Integer.parseInt(informacio[1]);
            int comptador = 0;
            for (int k = 0; k < totalUnitats; k++) {
                if (k == 0) {
                    llistaEnemics.add(new InfoEnemicManager(informacio[0], tempsTotal / totalUnitats));
                    comptador += tempsTotal / totalUnitats;
                } else {
                    int tempsUnitat = comptador + (tempsTotal / totalUnitats);
                    llistaEnemics.add(new InfoEnemicManager(informacio[0], tempsUnitat));
                    comptador += tempsTotal / totalUnitats;
                }
            }
        }
        ordenarArray();
    }

    /**
     * 按出发时间排序敌人列表
     */
    public static void ordenarArray() {
        Collections.sort(llistaEnemics);
    }

    /**
     * 创建负责将单位发送到棋盘的计时器
     * @param temps
     */
    public static void crearTimer(int temps) {
        timer = new Timer(temps, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (inici) {
                    inici = false;
                    mostraCartell = false;
                } else {
                    if (llistaEnemics.size() >= 1) {
                        ajustarTimer();
                        unitatEsperant = true;
                    }
                }
            }
        });
        timer.start();
    }

    /**
     * 调整计时器时间以适应下一个出发的敌人
     */
    private static void ajustarTimer() {
        InfoEnemicManager iem = (InfoEnemicManager) llistaEnemics.get(0);
        if (iem.getTempsSortida() > tempsAnterior) {
            timer.setDelay(iem.getTempsSortida() - tempsAnterior);
        }
        unitatEnEspera = iem.getTipusEnemic();
        tempsAnterior = iem.getTempsSortida();
        llistaEnemics.remove(iem);
    }

    /**
     * 随机选择一个出发路径
     * @return
     */
    public static int triarCarril() {
        int random = (int) (Math.random() * 600);
        return random;
    }

    /**
     * 停止这个类中使用的两个计时器
     */
    public static void pararTimer() {
        if (timer != null) {
            if (timer.isRunning()) {
                timer.stop();
            }
        }
        if (timerInici != null) {
            if (timerInici.isRunning()) {
                timerInici.stop();
            }
        }
        timer = null;
        timerInici = null;
    }

    /**
     * 指示是否所有敌人都已出发
     * @return
     */
    public static boolean fidelaWave() {
        if (llistaEnemics.size() == 0) {
            return true;
        }
        return false;
    }

    /**
     * 激活发射敌人前的倒计时
     */
    public static void iniciarCompteEnrere() {
        timerInici = new Timer(15000, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                mostraCartell = true;
                crearTimer(4000);
            }
        });
        timerInici.setRepeats(false);
        timerInici.start();
    }

    /**
     * 在屏幕上绘制开始标志
     * @param gc
     * @param g
     */
    public static void renderCartell(GameContainer gc, Graphics g) {
        iniciWaveImatge.draw(gc.getWidth() / 2 - iniciWaveImatge.getWidth() / 2 , 80);
    }

    // Getters i setters
    public static boolean isEnEspera() {
        return unitatEsperant;
    }

    public static UnitatAbstract getUnitat() {
        unitatEsperant = false;
        return FactoriaUnitatsEnemics.getUnitatDolenta(unitatEnEspera);
    }

    public static boolean isMostraCartell() {
        return mostraCartell;
    }

    public static void setMostraCartell(boolean mostra) {
        mostraCartell = mostra;
    }
}
