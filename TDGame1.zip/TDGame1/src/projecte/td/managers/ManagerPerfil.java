package projecte.td.managers;

import projecte.td.utilitats.*;
import projecte.td.utilitats.Configuracio;

/**
 * 在这个管理器中控制当前激活的用户个人资料。同时保存有关用户选项或统计数据的信息。
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class ManagerPerfil {

    // 玩家选择的游戏个人资料
    private static int perfilTriat;
    // 玩家开始游戏的波次
    private static int wave;
    // 当前正在玩的波次
    private static int waveActual;
    // 音乐音量
    private static int volumMusica;
    // 音效音量
    private static int volumEfectes = 20;
    // 波次总时长
    private static int tempsTotal;
    // 将出现的敌人总数
    private static int enemicsTotals;
    // 玩家在当前波次中可选择的单位
    private static String unitatsDisponibles;
    // 波次中将出现的敌人
    private static String enemicsWave;
    // 玩家为波次选择的单位
    private static String unitatsTriades;
    // 用于保存在状态改变时被选择的单位信息
    private static String informacioUnitat;
    // 玩家单位杀死的敌人总数
    private static int totalMorts;
    // 玩家放置在棋盘上的单位总数
    private static int totalUnitatsColocades;
    // 单位发射的子弹总数
    private static int totalBales;
    // 玩家赢得的游戏总数
    private static int totalGuanyades;
    // 玩家输掉的游戏总数
    private static int totalPerdudes;
    // 玩家在所有游戏中累积的金钱总数
    private static int totalDinersGuanyats;
    // 放置的光环总数
    private static int totalAuresColocades;
    // 选择的个人资料数据
    private static ArxiuConfiguracio dadesPerfil;
    // 当前波次的数据
    private static ArxiuConfiguracio dadesWave;
    // 指示玩家是否成功完成一个波次
    private static boolean canviWave;

    /**
     * 初始化使用该类所需的变量和资源
     * @param perfil 个人资料编号
     */
    public static void init(int perfil) {
        // 加载相应的文件
        perfilTriat = perfil;
        if (perfilTriat == 1) {
            dadesPerfil = Configuracio.getPerfil1();
        } else if (perfilTriat == 2) {
            dadesPerfil = Configuracio.getPerfil2();
        } else if (perfilTriat == 3) {
            dadesPerfil = Configuracio.getPerfil3();
        }
        // 加载要进行的波次数据
        dadesWave = Configuracio.getWaves();
        wave = dadesPerfil.getPropietatInt("seguentWave");
        waveActual = dadesPerfil.getPropietatInt("seguentWave");
        volumMusica = dadesPerfil.getPropietatInt("volumMusica");
        volumEfectes = dadesPerfil.getPropietatInt("volumEfectes");
        // 分配相关属性
        assignarPropietats();
        totalMorts = 0;
        totalBales = 0;
        totalGuanyades = 0;
        totalPerdudes = 0;
        totalDinersGuanyats = 0;
        totalAuresColocades = 0;
    }

    /**
     * 当玩家完成一个波次时，记录必要的数据
     */
    public static void passaASeguentWave() {
        if (waveActual==wave) {
            wave++;
            waveActual++;
            dadesPerfil.setPropietatInt("seguentWave", wave);
            dadesPerfil.guardar();
            canviWave = true;
        }
    }

    /**
     * 分配玩家在下一个波次中可选择的单位
     */
    public static void assignarPropietats() {
        unitatsDisponibles = dadesWave.getPropietatString("unitatsDisponibles" + wave);
        tempsTotal = dadesWave.getPropietatInt("temps" + wave);
        enemicsTotals = dadesWave.getPropietatInt("nombreEnemics" + wave);
        enemicsWave = retornaEnemics();
    }

    /**
     * 返回下一个要进行的波次中将出现的敌人信息字符串
     * @return 包含敌人信息的字符串
     */
    private static String retornaEnemics() {
        String enemics = "";
        String[] unitatsEnemigues = dadesWave.getPropietatString("enemicsWave" + wave).split("-");
        for (String z : unitatsEnemigues) {
            enemics += z.split(":")[0] + "-";
        }
        return enemics.substring(0, enemics.length() - 1);
    }

    /**
     * 返回下一个波次中可用的单位
     * @return 可用单位
     */
    public static String getUnitatsDisponibles() {
        if (canviWave) {
            assignarPropietats();
            canviWave = false;
        }
        return unitatsDisponibles;
    }

    /**
     * 指示是否可以在下一个波次状态中改变波次
     * @return
     */
    public static boolean potRestarWave() {
        if (wave > 1) {
            return true;
        }
        return false;
    }

    /**
     * 指示是否可以在下一个波次状态中增加波次
     * @return
     */
    public static boolean potSumarWave() {
        if (wave < waveActual) {
            return true;
        }
        return false;
    }

    /**
     * 减少当前波次的单位（在EstatSeguentWave状态中需要）
     */
    public static void restaWaveActual() {
        wave--;
    }

    /**
     * 增加当前波次的单位（在EstatSeguentWave状态中需要）
     */
    public static void sumaWaveActual() {
        wave++;
    }

    /**
     * 返回波次中将出现的敌人
     * @return
     */
    public static String getEnemicsWave() {
        if (canviWave) {
            assignarPropietats();
            canviWave = false;
        }
        return enemicsWave;
    }

    /**
     * 将玩家的统计数据保存到相应的文本文件中
     */
    public static void guardarEstadistiques() {
        int total = dadesPerfil.getPropietatInt("totalMorts");
        total += totalMorts;
        dadesPerfil.setPropietatInt("totalMorts", total);
        total = dadesPerfil.getPropietatInt("totalBales");
        total += totalBales;
        dadesPerfil.setPropietatInt("totalBales", total);
        total = dadesPerfil.getPropietatInt("totalGuanyades");
        total += totalGuanyades;
        dadesPerfil.setPropietatInt("totalGuanyades", total);
        total = dadesPerfil.getPropietatInt("totalPerdudes");
        total += totalPerdudes;
        dadesPerfil.setPropietatInt("totalPerdudes", total);
        total = dadesPerfil.getPropietatInt("totalDiners");
        total += totalDinersGuanyats;
        dadesPerfil.setPropietatInt("totalDiners", total);
        total = dadesPerfil.getPropietatInt("totalAures");
        total += totalAuresColocades;
        dadesPerfil.setPropietatInt("totalAures", total);
        total = dadesPerfil.getPropietatInt("totalUnitats");
        total += totalUnitatsColocades;
        dadesPerfil.setPropietatInt("totalUnitats", total);
        dadesPerfil.guardar();
    }

    /**
     * 将音量值保存到相应的文本文件中
     */
    public static void guardarValorsMusica() {
        dadesPerfil.setPropietatInt("volumMusica", volumMusica);
        dadesPerfil.setPropietatInt("volumEfectes", volumEfectes);
        dadesPerfil.guardar();
    }

    // 为玩家统计数据增加分数的方法
    public static void sumaMort() {
        totalMorts++;
    }

    public static void sumaBala() {
        totalBales++;
    }

    public static void sumaUnitat() {
        totalUnitatsColocades++;
    }

    public static void sumaGuanyada() {
        totalGuanyades++;
    }

    public static void sumaPerdudes() {
        totalPerdudes++;
    }

    public static void sumaDiners(int diners) {
        totalDinersGuanyats += diners;
    }

    public static void sumaAuraColocada() {
        totalAuresColocades++;
    }

    // 返回某个统计数据当前值的方法
    public static int getUnitats() {
        return dadesPerfil.getPropietatInt("totalUnitats");
    }

    public static int getAures() {
        return dadesPerfil.getPropietatInt("totalAures");
    }

    public static int getTotalMorts() {
        return dadesPerfil.getPropietatInt("totalMorts");
    }

    public static int getGuanyades() {
        return dadesPerfil.getPropietatInt("totalGuanyades");
    }

    public static int getPerdudes() {
        return dadesPerfil.getPropietatInt("totalPerdudes");
    }

    public static int getBales() {
        return dadesPerfil.getPropietatInt("totalBales");
    }

    public static int getDiners() {
        return dadesPerfil.getPropietatInt("totalDiners");
    }

    // Getters i setters
    public static void setUnitatsTriades(String triades) {
        unitatsTriades = triades;
    }

    public static String getUnitatsTriades() {
        return unitatsTriades;
    }

    public static int getWave() {
        return wave;
    }

    public static int getWaveActual() {
        return waveActual;
    }

    public static void setWave(int wave) {
        ManagerPerfil.wave = wave;
    }

    public static int getEnemicsTotals() {
        return enemicsTotals;
    }

    public static void setEnemicsTotals(int enemicsTotals) {
        ManagerPerfil.enemicsTotals = enemicsTotals;
    }

    public static int getTempsTotal() {
        return tempsTotal;
    }

    public static void setTempsTotal(int tempsTotal) {
        ManagerPerfil.tempsTotal = tempsTotal;
    }

    public int getTotalAuresColocades() {
        return totalAuresColocades;
    }

    public static String getInformacioUnitat() {
        return informacioUnitat;
    }

    public static void setInformacioUnitat(String informacioEnemic) {
        ManagerPerfil.informacioUnitat = informacioEnemic;
    }

    public static int getPerfilTriat() {
        return perfilTriat;
    }

    public static ArxiuConfiguracio getArxiuConfiguracio() {
        return dadesPerfil;
    }

    public static int getVolumEfectes() {
        return volumEfectes;
    }

    public static void setVolumEfectes(int volumEfectes) {
        ManagerPerfil.volumEfectes = volumEfectes;
    }

    public static int getVolumMusica() {
        return volumMusica;
    }

    public static void setVolumMusica(int volumMusica) {
        ManagerPerfil.volumMusica = volumMusica;
    }
}
