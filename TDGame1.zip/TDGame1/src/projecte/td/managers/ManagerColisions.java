package projecte.td.managers;

import projecte.td.domini.*;
import java.util.ArrayList;

/**
 * 负责检查单位、子弹和敌人间的碰撞
 * @author David Alvarez Palau i Ernest Daban Macià
 */
public class ManagerColisions {

    // 二维数组，用于存储友军单位
    private UnitatAbstract[][] unitatsAmigues;
    // 每条路径的敌人数组（分开存储）
    ArrayList[] arrays_enemics;
    // 每条路径的友军子弹数组（分开存储）
    ArrayList[] arrays_projectils_amics;
    // 每条路径的敌军子弹数组（分开存储）
    ArrayList[] arrays_projectils_enemics;
    // 表示各路径是否有敌人
    private boolean[] controlaFiles;

    /**
     * 多参数构造函数
     * @param arrays_enemics: 敌人数组
     * @param arrays_projectils_amics: 友军子弹数组
     * @param arrays_projectils_enemics: 敌军子弹数组
     * @param controlaFiles
     * @param unitatsAmigues
     */
    public ManagerColisions(ArrayList[] arrays_enemics, ArrayList[] arrays_projectils_amics, ArrayList[] arrays_projectils_enemics, boolean[] controlaFiles, UnitatAbstract[][] unitatsAmigues) {
        this.arrays_enemics = arrays_enemics;
        this.arrays_projectils_amics = arrays_projectils_amics;
        this.arrays_projectils_enemics = arrays_projectils_enemics;
        this.controlaFiles = controlaFiles;
        this.unitatsAmigues = unitatsAmigues;
    }

    /**
     * 检查可能发生碰撞的元素之间是否发生碰撞
     */
    public void comprovarColisions() {
        // 友军子弹与敌人碰撞检查
        for (int i = 0; i < controlaFiles.length; i++) {
            if (controlaFiles[i]) {
                for (Object ob1 : arrays_enemics[i]) {
                    UnitatAbstract enemic = (UnitatAbstract) ob1;
                    for (Object ob2 : arrays_projectils_amics[i]) {
                        Projectil p = (Projectil) ob2;
                        // 检查单位是否为隐形类型
                        if (enemic instanceof UnitatEnemigaInvisible) {
                            UnitatEnemigaInvisible ui = (UnitatEnemigaInvisible) enemic;
                            ui.canviShape();
                            if (!ui.isInvisible() && ui.collideWith(p.getShape())) {
                                enemic.impacte(p.getDany());
                                p.impacte();
                            }
                            ui.segonCanviShape();
                        }
                        // 检查敌人是否与友军子弹碰撞
                        else if (enemic.collideWith(p.getShape())) {
                            if (p instanceof ProjectilMobil) {
                                if (!p.isMort()) {
                                    enemic.impacte(p.getDany());
                                }
                            } else {
                                enemic.impacte(p.getDany());
                            }
                            p.impacte();
                        }
                    }
                }
            }
        }
        // 敌军子弹与友军单位碰撞检查
        for (int i = 0; i < controlaFiles.length; i++) {
            if (controlaFiles[i]) {
                for (int col = 0; col < unitatsAmigues[i].length; col++) {
                    if (unitatsAmigues[i][col] != null) {
                        for (Object ob : arrays_projectils_enemics[i]) {
                            Projectil p = (Projectil) ob;
                            if (unitatsAmigues[i][col].collideWith(p.getShape())) {
                                unitatsAmigues[i][col].impacte(p.getDany());
                                p.impacte();
                            }
                        }
                    }
                }
            }
        }
        // 敌人与友军单位碰撞检查
        for (int i = 0; i < controlaFiles.length; i++) {
            if (!arrays_enemics[i].isEmpty()) {
                for (Object ob1 : arrays_enemics[i]) {
                    UnitatEnemiga enemic = (UnitatEnemiga) ob1;
                    for (UnitatAbstract unitatAmiga : unitatsAmigues[i]) {
                        if (unitatAmiga != null) {
                            if (unitatAmiga.collideWith(enemic.getShape()) && unitatAmiga.getPosX() <= enemic.getPosX()) {
                                if (enemic instanceof UnitatEnemigaAtkDistancia) {
                                    UnitatEnemigaAtkDistancia enemicD = (UnitatEnemigaAtkDistancia) enemic;
                                    enemicD.activarDispars();
                                } else if (enemic instanceof UnitatEnemigaAtkNormal) {
                                    UnitatEnemigaAtkNormal enemicN = (UnitatEnemigaAtkNormal) enemic;
                                    enemicN.setActivat(true);
                                    // 水球
                                    if (enemic instanceof UnitatEnemigaBolaNeu) {
                                        if (unitatAmiga instanceof UnitatAigua) {
                                            UnitatEnemigaBolaNeu un = (UnitatEnemigaBolaNeu) enemic;
                                            un.rebreAigua();
                                        } else {
                                            unitatAmiga.impacte(enemicN.getDany());
                                        }
                                    } else {
                                        unitatAmiga.impacte(enemicN.getDany());
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
