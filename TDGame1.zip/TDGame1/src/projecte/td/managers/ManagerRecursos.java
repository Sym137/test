package projecte.td.managers;

import projecte.td.utilitats.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.newdawn.slick.AngelCodeFont;
import org.newdawn.slick.Font;
import org.newdawn.slick.Image;
import org.newdawn.slick.Music;
import org.newdawn.slick.Sound;
import projecte.td.utilitats.Configuracio;

/**
 * 该类负责映射游戏中使用的不同资源，并在应用程序的任何部分请求时提供这些资源。
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class ManagerRecursos {

    // 存储图像的Map
    private static Map<String, Image> imatges = new HashMap<String, Image>();
    // 存储图像数组的Map
    private static Map<String, Image[]> animacions = new HashMap<String, Image[]>();
    // 存储文本字体的Map
    private static Map<String, Font> fonts = new HashMap<String, Font>();
    // 配置文件，包含资源路径的映射
    private static ArxiuConfiguracio recursos;

    /**
     * 该方法在应用程序启动时只创建一次
     */
    public static void init() {
        carregaObjectesJoc();
    }

    /**
     * 负责获取所有需要加载的资源，创建相应的对象并将其放入适当的映射中
     */
    private static void carregaObjectesJoc() {
        recursos = Configuracio.getRecursos();
        Set<Object> claus = recursos.getTotesPropietats();
        for (Object objecte : claus) {
            String clau = (String) objecte;
            try {
                crearObjectes(clau);
            } catch (Exception ex) {
                throw new RuntimeException("无法创建资源: " + clau);
            }
        }
    }

    /**
     * 根据传入的字符串创建资源。根据字符串的后缀，将创建不同类型的资源
     * @param clau : 要加载的资源
     * @throws Exception
     */
    private static void crearObjectes(String clau) throws Exception {
        String valor = recursos.getPropietatString(clau);
        if (clau.endsWith("Sound")) {

        } else if (clau.endsWith("Music")) {

        } else if (clau.endsWith("Image")) {
            imatges.put(clau, new Image(valor));
        } else if (clau.endsWith("Animation")) {
            animacions.put(clau, convertirImatgeArray(valor));
        } else if (clau.endsWith("Font")) {
            fonts.put(clau, new AngelCodeFont(valor + ".fnt", valor + ".png", true));
        }
    }

    /**
     * 根据字符串加载相关的资源（图像）并返回
     * @param valor : 要加载的资源
     * @return 生成的图像数组
     * @throws Exception
     */
    private static Image[] convertirImatgeArray(String valor) throws Exception {
        String[] frames = valor.split("-");
        Image[] image = new Image[frames.length];
        for (int z = 0; z < frames.length; z++) {
            image[z] = new Image(frames[z]);
        }
        return image;
    }

    // Getters 和 setters
    public static Image getImage(String name) {
        return imatges.get(name);
    }

    public static Image[] getImageArray(String name) {
        return animacions.get(name);
    }

    public static Font getFont(String name) {
        return fonts.get(name);
    }


}
