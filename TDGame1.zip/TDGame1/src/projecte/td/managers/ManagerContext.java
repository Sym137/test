package projecte.td.managers;

import org.newdawn.slick.gui.GUIContext;
import org.newdawn.slick.state.StateBasedGame;

/**
 * 这个管理器负责提供三个对象，这些对象需要在不同状态中使用
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class ManagerContext {

    // 游戏开发的环境
    private static GUIContext gui;
    // 用于从一个状态跳转到另一个状态的对象
    private static StateBasedGame state;
    // 管理用户收入的 ManagerDinersAures
    private static ManagerDinersAures diners;

    // 类的获取器和设置器

    public static GUIContext getGui() {
        return gui;
    }

    public static void setGui(GUIContext gui) {
        ManagerContext.gui = gui;
    }

    public static StateBasedGame getState() {
        return state;
    }

    public static void setState(StateBasedGame state) {
        ManagerContext.state = state;
    }

    public static ManagerDinersAures getDiners() {
        return diners;
    }

    public static void setDiners(ManagerDinersAures diners) {
        ManagerContext.diners = diners;
    }
}