package projecte.td.managers;

/**
 * 负责管理用户在游戏过程中拥有的金钱。还会在购买单位时进行相应的交易。
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class ManagerDinersAures {

    // 累计的总金额
    private int total;
    // 指示是否有一个光环在等待被放置
    private boolean auraEnEspera;
    // 指示在等待的光环类型（如果有的话）。
    private String tipusAuraEspera;

    /**
     * 无参数构造函数
     */
    public ManagerDinersAures() {
        total = 200;
    }

    /**
     * 将一定数量的金钱添加到已累计的金额中
     * @param quantitat : 要添加的金钱
     */
    public void afegirDiners(int quantitat) {
        total += quantitat;
        ManagerPerfil.sumaDiners(quantitat);
    }

    /**
     * 从已累计的金额中减少一定数量的金钱
     * @param quantitat : 要减少的金钱
     */
    public void restarDiners(int quantitat) {
        total -= quantitat;
    }

    /**
     * 指示是否有足够的资源
     * @param quantitat
     * @return
     */
    public boolean suficientsDinerst(int quantitat) {
        if (total - quantitat >= 0) {
            return true;
        }
        return false;
    }

    /**
     * 返回当前累计的金钱
     * @return
     */
    public int getTotal() {
        return total;
    }

    /**
     * 将累计的金钱设置为所需的数量
     * @param total
     */
    public void setTotal(int total) {
        this.total = total;
    }

    /**
     * 重置光环的值，以便没有可用的光环
     */
    public void clearAures() {
        auraEnEspera = false;
        tipusAuraEspera = "null";
    }

    /**
     * 指示是否有一个光环在等待
     * @return 如果有一个光环在等待则返回true，否则返回false
     */
    public boolean isAuraEnEspera() {
        return auraEnEspera;
    }

    /**
     * 返回等待的光环类型
     * @return 包含等待光环信息的字符串
     */
    public String getTipusAuraEspera() {
        return tipusAuraEspera;
    }

    /**
     * 将所需的光环类型设置为当前活动的等待光环
     * @param tipusAuraEspera
     */
    public void setTipusAuraEspera(String tipusAuraEspera) {
        auraEnEspera = true;
        this.tipusAuraEspera = tipusAuraEspera;
    }
}
