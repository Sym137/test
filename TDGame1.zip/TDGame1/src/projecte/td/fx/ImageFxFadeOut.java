package projecte.td.fx;

import mdes.slick.animation.Easing;
import mdes.slick.animation.Fx;
import mdes.slick.animation.Timeline;
import mdes.slick.animation.entity.AlphaEntity;
import mdes.slick.animation.fx.AlphaFx;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.GUIContext;

/**
 * 该类用于在启动画面中实现淡出效果
 * @author 修改者：David Alvarez Palau 和 Ernest Daban Macià
 */
public class ImageFxFadeOut extends AbstractComponent implements AlphaEntity {

    private int x;
    private int y;
    private int startAt;
    private int longUpdate;
    private int counter;
    private Image image;
    private Rectangle area;
    private Fx fx;
    private Timeline timeline;
    private Color filter = new Color(Color.white);

    /**
     * 带8个参数的构造函数
     * @param container
     * @param image
     * @param x
     * @param y
     * @param width
     * @param height
     * @param startAt
     * @param longUpdate
     */
    public ImageFxFadeOut(GUIContext container, Image image, int x, int y,
                          int width, int height, int startAt, int longUpdate) {
        super(container);
        this.x = x;
        this.y = y;
        this.startAt = startAt;
        this.longUpdate = longUpdate;
        this.image = image;
        setLocation(x, y);
        area = new Rectangle(x, y, width, height);
        timeline = new Timeline();
        Easing ease = Easing.CUBIC_IN;
        fx = new AlphaFx(2000, this, 1f, .0f, ease);
        timeline.add(fx);
    }

    /**
     * 开始淡出效果（变黑）
     */
    private void fxFadeOut() {
        timeline.rewind();
        timeline.setActive(true);
    }

    /**
     * 渲染图像
     * @param container
     * @param g
     */
    public void render(GUIContext container, Graphics g) {
        if (counter >= startAt && counter < startAt + longUpdate) {
            image.draw(x, y, filter);
        }
    }

    /**
     * 更新类的逻辑
     * @param delta
     */
    public void update(int delta) {
        if (counter == startAt) {
            fxFadeOut();
        } else if (counter > startAt && counter < startAt + longUpdate) {
            timeline.update(delta);
        }
        counter += delta;

    }

    /**
     * 将区域定位到正确的位置
     * @param xPos
     * @param yPos
     */
    public void setLocation(int xPos, int yPos) {
        if (area != null) {
            area.setX(xPos);
            area.setY(yPos);
        }
    }

    // 获取和设置方法
    public int getX() {
        return (int) area.getX();
    }

    public int getY() {
        return (int) area.getY();
    }

    public int getWidth() {
        return (int) (area.getMaxX() - area.getX());
    }

    public int getHeight() {
        return (int) (area.getMaxY() - area.getY());
    }

    public float getAlpha() {
        // TODO 生成的方法
        return filter.a;
    }

    public void setAlpha(float alpha) {
        // TODO 生成的方法
        filter.a = alpha;
    }
}
