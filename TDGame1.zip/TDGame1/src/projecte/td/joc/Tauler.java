package projecte.td.joc;

import java.util.ArrayList;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Sound;
import org.newdawn.slick.geom.Rectangle;
import projecte.td.domini.InterficieBomba;
import projecte.td.domini.Miner;
import projecte.td.managers.ManagerColisions;
import projecte.td.domini.Projectil;
import projecte.td.domini.ProjectilEstatic;
import projecte.td.domini.ProjectilMobil;
import projecte.td.domini.UnitatAbstract;
import projecte.td.domini.UnitatDispara;
import projecte.td.domini.UnitatEnemiga;
import projecte.td.domini.UnitatEnemigaAtkDistancia;
import projecte.td.domini.UnitatEnemigaAtkDistanciaSalta;
import projecte.td.domini.UnitatEnemigaAtkNormal;
import projecte.td.domini.UnitatEnemigaInvisible;
import projecte.td.managers.ManagerPerfil;
import projecte.td.managers.ManagerRecursos;

/**
 * 负责游戏运行的棋盘类
 * @author Ernest Daban 和 David Alvarez
 */
public class Tauler {

    private int nFiles; // 棋盘行数
    private int nColumnes; // 棋盘列数
    private int nCeles; // 棋盘上的格子数
    private int ampladaTotal; // 棋盘总宽度
    private int llargadaTotal; // 棋盘总高度
    private double amplada; // 格子宽度
    private double llargada; // 格子高度
    private boolean[][] clicades; // 控制格子是否被点击的数组
    private boolean dibuixarQuadrat; // 绘制方格的条件
    private int[] posicioQuadrat; // 选中方格的坐标
    private Rectangle[][] celes; // 棋盘上的格子数组
    private UnitatAbstract[][] unitatsAmigues; // 棋盘上所有友军单位的数组
    ArrayList[] arrays_enemics; // 棋盘上所有敌人的数组
    ArrayList<UnitatAbstract> enemics_morts; // 棋盘上死亡敌人的数组
    ArrayList[] arrays_projectils_amics; // 友军炮弹的数组
    ArrayList[] arrays_projectils_enemics; // 敌军炮弹的数组
    ArrayList<Projectil> projectils_finalitzats; // 已结束的炮弹数组
    private boolean[] controlaFiles; // 控制敌人占用行的数组
    ManagerColisions mc; // 碰撞管理器
    ArrayList<UnitatEnemigaAtkDistanciaSalta> unitatsSaltant; // 存储跳跃单位的数组
    /**
     * 棋盘构造函数
     * @param nFiles 棋盘行数
     * @param nColumnes 棋盘列数
     * @param ampladaTotal 棋盘总宽度（像素）
     * @param llargadaTotal 棋盘总高度（像素）
     */
    public Tauler(int nFiles, int nColumnes, int ampladaTotal, int llargadaTotal) {
        this.nFiles = nFiles;
        this.nColumnes = nColumnes;
        this.ampladaTotal = ampladaTotal;
        this.llargadaTotal = llargadaTotal;
        crearCeles();
        inicialitzar();
    }

    /**
     * 创建棋盘上的格子
     */
    private void crearCeles() {
        nCeles = nFiles * nColumnes;
        clicades = new boolean[nFiles][nColumnes];
        celes = new Rectangle[nFiles][nColumnes];
        amplada = ampladaTotal / nColumnes;
        llargada = llargadaTotal / nFiles;
        int x = 0;
        int y = 0;
        for (int fil = 0; fil < nFiles; fil++) {
            for (int col = 0; col < nColumnes; col++) {
                Rectangle r = new Rectangle(x, y, ampladaTotal / nColumnes, llargadaTotal / nFiles);
                celes[fil][col] = r;
                x += amplada;
            }
            x = 0;
            y += llargada;
        }
    }

    /**
     * 初始化棋盘上所有数组以存储实体
     */
    private void inicialitzar() {
        unitatsAmigues = new UnitatAbstract[nFiles][nColumnes];
        controlaFiles = new boolean[nFiles];
        arrays_enemics = new ArrayList[nFiles];
        arrays_projectils_amics = new ArrayList[nFiles];
        arrays_projectils_enemics = new ArrayList[nFiles];
        for (int i = 0; i < nFiles; i++) {
            ArrayList<UnitatAbstract> enemics = new ArrayList<UnitatAbstract>();
            arrays_enemics[i] = enemics;
            ArrayList<Projectil> projectils_amics = new ArrayList<Projectil>();
            arrays_projectils_amics[i] = projectils_amics;
            ArrayList<Projectil> projectils_enemics = new ArrayList<Projectil>();
            arrays_projectils_enemics[i] = projectils_enemics;
        }
        projectils_finalitzats = new ArrayList<Projectil>();
        enemics_morts = new ArrayList<UnitatAbstract>();
        mc = new ManagerColisions(arrays_enemics, arrays_projectils_amics, arrays_projectils_enemics, controlaFiles, unitatsAmigues);
        unitatsSaltant = new ArrayList<UnitatEnemigaAtkDistanciaSalta>();
    }
    /**
     * 检查是否在棋盘的任何格子上进行了点击
     * @param x 点击的x坐标
     * @param y 点击的y坐标
     * @return 如果点击正确，则返回true
     */
    public boolean comprovaClickCorrecte(int x, int y) {
        int[] posFC = {-1, -1};
        for (int fil = 0; fil < nFiles; fil++) {
            for (int col = 0; col < nColumnes; col++) {
                if (celes[fil][col].contains(x, y)) {
                    posFC[0] = fil;
                    posFC[1] = col;
                }
            }
        }
        if (posFC[0] == -1 && posFC[1] == -1) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * 检查点击属于哪个格子
     * @param x 点击的x坐标
     * @param y 点击的y坐标
     * @return 格子在数组中的行和列位置
     */
    public int[] mirarCoordenadesClick(int x, int y) {
        int[] posFC = {0, 0};
        for (int fil = 0; fil < nFiles; fil++) {
            for (int col = 0; col < nColumnes; col++) {
                if (celes[fil][col].contains(x, y)) {
                    posFC[0] = fil;
                    posFC[1] = col;
                }
            }
        }
        return posFC;
    }

    /**
     * 检查格子是否被占用
     * @param fil 行号
     * @param col 列号
     * @return 如果格子为空，则返回true
     */
    public boolean comprovarClick(int fil, int col) {
        if (!clicades[fil][col]) {
            return true;

        }
        return false;
    }

    /**
     * 在棋盘上放置一个友军单位
     * @param fil 行号
     * @param col 列号
     * @param unitatAmiga 要放置的友军单位
     */
    public void posicionaUnitatAmiga(int fil, int col, UnitatAbstract unitatAmiga) {
        clicades[fil][col] = true;
        // 放置友军单位
        float Lx = (float) (celes[fil][col].getCenterX() - (double) unitatAmiga.getAnimation().getImage(0).getWidth() / 2);
        float Ly = (float) (celes[fil][col].getY() + llargada - unitatAmiga.getAnimation().getImage(0).getHeight());
        unitatAmiga.setLocation(Lx, Ly);
        unitatsAmigues[fil][col] = unitatAmiga;
    }

    /**
     * 获取友军单位
     * @param x 点击的x坐标
     * @param y 点击的y坐标
     * @return 被点击的友军单位
     */
    public UnitatAbstract getUnitatAmiga(int x, int y) {
        int[] posFC = mirarCoordenadesClick(x, y);
        return unitatsAmigues[posFC[0]][posFC[1]];
    }
    /**
     * 从棋盘上移除一个友军单位
     * @param fil 行号
     * @param col 列号
     */
    private void eliminaUnitatAmiga(int fil, int col) {
        if (unitatsAmigues[fil][col] instanceof UnitatDispara) {
            UnitatDispara ud = (UnitatDispara) unitatsAmigues[fil][col];
            ud.desactivarDispars(); // 停止计时器
        } else if (unitatsAmigues[fil][col] instanceof Miner) {
            Miner miner = (Miner) unitatsAmigues[fil][col];
            miner.desactivarTimer(); // 停止计时器
        }
        unitatsAmigues[fil][col] = null;
        clicades[fil][col] = false;
        stopAtacUnitatsEnemigues(fil);
    }

    /**
     * 在棋盘上放置一个敌军单位
     * @param x 坐标
     * @param y 坐标
     * @param enemic 要放置的敌军单位
     */
    public void posicionaUnitatEnemiga(int x, int y, UnitatAbstract enemic) {
        for (int fil = 0; fil < nFiles; fil++) {
            for (int col = 0; col < nColumnes; col++) {
                if (celes[fil][col].contains(x, y)) {
                    enemic.setLocation(ampladaTotal, (float) (celes[fil][col].getY() + llargada - enemic.getAnimation().getHeight()));
                    arrays_enemics[fil].add(enemic);
                    if (!controlaFiles[fil] && !(enemic instanceof UnitatEnemigaInvisible)) {
                        controlaFiles[fil] = true;
                    }

                }
            }
        }
    }

    /**
     * 停止友军单位的攻击
     */
    private void stopUnitatsAmigues() {
        for (int i = 0; i < nFiles; i++) {
            if (arrays_enemics[i].isEmpty()) {
                controlaFiles[i] = false;
                for (UnitatAbstract amic : unitatsAmigues[i]) {
                    if (amic instanceof UnitatDispara) {
                        UnitatDispara ud = (UnitatDispara) amic;
                        ud.desactivarDispars();
                    }
                }
            }
        }
    }

    /**
     * 停止敌军单位的攻击
     * @param fila 行号
     */
    private void stopAtacUnitatsEnemigues(int fila) {
        for (Object en : arrays_enemics[fila]) {
            if (en instanceof UnitatEnemigaAtkDistancia) {
                UnitatEnemigaAtkDistancia enemic = (UnitatEnemigaAtkDistancia) en;
                enemic.desactivarDispars();
            } else if (en instanceof UnitatEnemigaAtkNormal) {
                UnitatEnemigaAtkNormal enemic = (UnitatEnemigaAtkNormal) en;
                enemic.setActivat(false);
            }

        }

    }

    /**
     * 友军单位射击
     * @param ud 友军单位
     * @param numFila 行号
     * @param p 单位的炮弹
     */
    private void dispararUnitatDispara(UnitatDispara ud, int numFila, Projectil p) {
        if (ud.estaDisparant()) {
            arrays_projectils_amics[numFila].add(p);
            ud.haDisparat();

            ManagerPerfil.sumaBala();
        }
        if (!ud.estaActivat()) {
            ud.activarDispars();
        }
    }

    /**
     * 所有友军单位射击
     */
    private void dispararUnitatsAmigues() {
        for (int i = 0; i < nFiles; i++) {
            for (UnitatAbstract t : unitatsAmigues[i]) {
                if (t != null && t instanceof InterficieBomba) {
                    InterficieBomba u = (InterficieBomba) t;
                    if (u.isDispara()) {
                        arrays_projectils_amics[i].add(u.getProjectil());
                        u.haDisparat();

                        ManagerPerfil.sumaBala();
                    }
                } else {
                    if (controlaFiles[i]) {
                        if (t != null && t instanceof UnitatDispara) {
                            for (Object ob : arrays_enemics[i]) {
                                UnitatAbstract enemic = (UnitatAbstract) ob;
                                UnitatDispara ud = (UnitatDispara) t;
                                Projectil p = ud.getProjectil();
                                if (enemic.getPosX() >= ud.getPosX()) {
                                    if (p instanceof ProjectilMobil) {
                                        dispararUnitatDispara(ud, i, p);
                                    } else if (p instanceof ProjectilEstatic) {
                                        if (!arrays_enemics[i].isEmpty()) {
                                            if (enemic.getPosX() <= ud.getPosX() + 150) {
                                                dispararUnitatDispara(ud, i, p);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 所有敌军单位射击
     */
    private void disparaUnitatsEnemigues() {
        for (int i = 0; i < nFiles; i++) {
            if (controlaFiles[i]) {
                for (Object en : arrays_enemics[i]) {
                    if (en instanceof UnitatEnemigaAtkDistancia) {
                        UnitatEnemigaAtkDistancia enemic = (UnitatEnemigaAtkDistancia) en;
                        if (enemic.estaActivat() && enemic.estaDisparant()) {
                            arrays_projectils_enemics[i].add(enemic.getProjectil());
                            enemic.haDisparat();

                        }
                    }
                }
            }
        }
    }

    /**
     * 绘制棋盘上的所有内容
     * @param g Graphics
     * @param gc GameContainer
     */
    public void dibuixar(Graphics g, GameContainer gc) {
        for (int i = 0; i < nFiles; i++) {
            for (UnitatAbstract t : unitatsAmigues[i]) {
                if (t != null) {
                    t.render(gc, g);
                }
            }
            for (Object en : arrays_enemics[i]) {
                UnitatAbstract enemic = (UnitatAbstract) en;
                enemic.render(gc, g);
            }
            for (Object ob : arrays_projectils_amics[i]) {
                Projectil p = (Projectil) ob;
                p.render(gc, g);
            }
            for (Object ob : arrays_projectils_enemics[i]) {
                Projectil p = (Projectil) ob;
                p.render(gc, g);
            }
            for (UnitatAbstract t : unitatsAmigues[i]) {
                if (t != null) {
                    t.renderMort(gc, g);
                    if(t.efectuarSoMort()){

                    }
                }
            }
            for (Object en : arrays_enemics[i]) {
                UnitatAbstract enemic = (UnitatAbstract) en;
                enemic.renderMort(gc, g);
            }
        }
        dibuixarQuadrat(g, gc);
    }

    /**
     * 绘制选中格子的边框
     * @param g Graphics
     * @param gc GameContainer
     */
    private void dibuixarQuadrat(Graphics g, GameContainer gc) {
        if (dibuixarQuadrat) {
            int[] quadricula = mirarCoordenadesClick(posicioQuadrat[0], posicioQuadrat[1]);
            if (quadricula[0] != 15) {
                Rectangle rectangle = getCela(quadricula[0], quadricula[1]);
                if (comprovarClick(quadricula[0], quadricula[1])) {
                    g.setColor(Color.green);
                } else {
                    g.setColor(Color.red);
                }
                g.setLineWidth(2);
                g.drawRoundRect(rectangle.getX() + 2, rectangle.getY() + 2, rectangle.getWidth() - 2,
                        rectangle.getHeight() - 2, 15);
                g.setColor(Color.white);
                g.setLineWidth(1);
            }
        }
    }

    /**
     * 删除所有结束的炮弹和死亡的敌人
     */
    private void finalitzarProjectils_Enemics() {
        for (int i = 0; i < nFiles; i++) {
            for (Projectil b : projectils_finalitzats) {
                arrays_projectils_amics[i].remove(b);
            }
            for (Projectil b : projectils_finalitzats) {
                arrays_projectils_enemics[i].remove(b);
            }
            for (UnitatAbstract en : enemics_morts) {
                arrays_enemics[i].remove(en);
            }

        }
        projectils_finalitzats.clear();
        enemics_morts.clear();
    }

    /**
     * 放置跳跃的单位
     */
    private void colocarUnitatsSaltant() {
        for (UnitatEnemigaAtkDistanciaSalta eS : unitatsSaltant) {
            posicionaUnitatEnemigaSalta((int) eS.getPosX(), eS.getySalt(), eS);
        }
        unitatsSaltant.clear();
    }

    /**
     * 在棋盘上放置一个跳跃的单位
     * @param x X坐标
     * @param y Y坐标
     * @param enemic 单位
     */
    private void posicionaUnitatEnemigaSalta(int x, int y, UnitatAbstract enemic) {

        int[] PosFC = mirarCoordenadesClick(x, y);
        enemic.setMort(false);
        enemic.setLocation(x, (float) (celes[PosFC[0]][PosFC[1]].getY() + llargada - enemic.getAnimation().getHeight()));
        arrays_enemics[PosFC[0]].add(enemic);
        if (!controlaFiles[PosFC[0]]) {
            controlaFiles[PosFC[0]] = true;
        }
    }

    /**
     * 检查棋盘上所有单位的死亡情况
     * @param cond 如果为true，则添加到每个玩家的个人资料中
     */
    private void comprovarMorts(boolean cond) {
        for (int i = 0; i < nFiles; i++) {
            for (Object en : arrays_enemics[i]) {
                UnitatAbstract enemic = (UnitatAbstract) en;
                if (enemic.isMort()) {
                    if (cond) {
                        ManagerPerfil.sumaMort();// 添加死亡数
                    }
                    if (enemic instanceof UnitatEnemigaAtkDistancia) {
                        UnitatEnemigaAtkDistancia ud = (UnitatEnemigaAtkDistancia) enemic;
                        ud.desactivarDispars();
                    }
                    enemics_morts.add(enemic);
                }
            }
            for (Object ob : arrays_projectils_amics[i]) {
                Projectil p = (Projectil) ob;
                if (p.isMort()) {
                    projectils_finalitzats.add(p);
                }
            }
            for (Object ob : arrays_projectils_enemics[i]) {
                Projectil p = (Projectil) ob;
                if (p.isMort()) {
                    projectils_finalitzats.add(p);
                }
            }
            for (int col = 0; col < nColumnes; col++) {
                if (unitatsAmigues[i][col] != null) {
                    if (unitatsAmigues[i][col].isMort()) {
                        eliminaUnitatAmiga(i, col);
                    }
                }
            }
        }
    }

    /**
     * 激活棋盘上所有单位
     * @param delta
     */
    private void accionarUnitats(int delta) {
        for (int i = 0; i < nFiles; i++) {
            for (Object en : arrays_enemics[i]) {
                UnitatAbstract enemic = (UnitatAbstract) en;
                // 跳跃的敌军单位：
                if (enemic instanceof UnitatEnemigaAtkDistanciaSalta) {
                    UnitatEnemigaAtkDistanciaSalta eS = (UnitatEnemigaAtkDistanciaSalta) enemic;
                    if (eS.isSaltant() && !eS.estaActivat() && eS.haFinalitzatAnimacio()) {
                        eS.setMort(true);
                        eS.calculaSalt(llargadaTotal);
                        eS.haSaltat();
                        unitatsSaltant.add(eS);
                    }
                }
                // 隐形的敌军单位：
                if (enemic instanceof UnitatEnemigaInvisible) {
                    UnitatEnemigaInvisible ui = (UnitatEnemigaInvisible) enemic;
                    if (!ui.isInvisible()) {
                        controlaFiles[i] = true;
                    }
                }
                enemic.update(delta);
            }
            for (Object ob : arrays_projectils_amics[i]) {
                Projectil p = (Projectil) ob;
                p.update(delta);
            }
            for (Object ob : arrays_projectils_enemics[i]) {
                Projectil p = (Projectil) ob;
                p.update(delta);
            }
            for (int col = 0; col < nColumnes; col++) {
                if (unitatsAmigues[i][col] != null) {
                    unitatsAmigues[i][col].update(delta);
                }
            }
        }
    }

    /**
     * 更新整个棋盘
     * @param delta
     */
    public void update(int delta) {
        accionarUnitats(delta);
        comprovarMorts(true);
        dispararUnitatsAmigues();
        stopUnitatsAmigues();
        finalitzarProjectils_Enemics();
        colocarUnitatsSaltant();
        mc.comprovarColisions();
        disparaUnitatsEnemigues();
    }

    /**
     * 设置是否绘制格子
     * @param dibuixarQuadrat
     */
    public void setDibuixarQuadrat(boolean dibuixarQuadrat) {
        this.dibuixarQuadrat = dibuixarQuadrat;
    }

    /**
     * 设置绘制格子的位置
     * @param x X坐标
     * @param y Y坐标
     */
    public void setPosicioDibuixQuadrat(int x, int y) {
        posicioQuadrat = new int[2];
        posicioQuadrat[0] = x;
        posicioQuadrat[1] = y;
    }

    /**
     * 通过点击删除选中的单位
     * @param x 点击的X坐标
     * @param y 点击的Y坐标
     */
    public void borrarUnitatAmiguesClick(int x, int y) {
        int[] PosFC = mirarCoordenadesClick(x, y);
        eliminaUnitatAmiga(PosFC[0], PosFC[1]);
    }

    /**
     * 删除棋盘上所有单位
     */
    public void borrarTot() {
        for (int i = 0; i < nFiles; i++) {
            for (UnitatAbstract amic : unitatsAmigues[i]) {
                if (amic != null) {
                    amic.setMort(true);
                    amic.noEfectuarSoMort();
                }
            }
            for (Object ob : arrays_enemics[i]) {
                UnitatAbstract enemic = (UnitatAbstract) ob;
                enemic.setMort(true);

            }
            for (Object ob : arrays_projectils_amics[i]) {
                Projectil p = (Projectil) ob;
                p.setMort(true);
            }

            for (Object ob : arrays_projectils_enemics[i]) {
                Projectil p = (Projectil) ob;
                p.setMort(true);
            }
        }
        comprovarMorts(false);
        finalitzarProjectils_Enemics();
    }

    /**
     * 检查游戏是否结束
     * @return 如果结束则返回true
     */
    public boolean observarPartidaFinalitzada() {
        for (int i = 0; i < nFiles; i++) {
            if (!arrays_enemics[i].isEmpty()) {
                for (Object ob : arrays_enemics[i]) {
                    UnitatEnemiga enemic = (UnitatEnemiga) ob;
                    if (enemic.isHaArribat()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * 获取格子
     * @param a 行号
     * @param b 列号
     * @return
     */
    public Rectangle getCela(int a, int b) {
        return celes[a][b];
    }
    /**
     * 检查棋盘上是否有敌人
     * @return 如果有则返回true
     */
    public boolean enemicsEnTauler() {
        for (int i = 0; i < nFiles; i++) {
            if (!arrays_enemics[i].isEmpty()) {
                return true;
            }
        }
        return false;
    }
}
