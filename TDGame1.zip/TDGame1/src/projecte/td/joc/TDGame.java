package projecte.td.joc;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.loading.LoadingList;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.estats.EstatDades;
import projecte.td.estats.EstatEstadistiques;
import projecte.td.estats.EstatGuanya;
import projecte.td.estats.EstatInGame;
import projecte.td.estats.EstatInfoEnemic;
import projecte.td.estats.EstatInfoUnitats;
import projecte.td.estats.EstatIntro;
import projecte.td.estats.EstatLoading;
import projecte.td.estats.EstatMenuPrincipal;
import projecte.td.estats.EstatMostraInfoEnemics;
import projecte.td.estats.EstatMostraInfoUnitats;
import projecte.td.estats.EstatMusica;
import projecte.td.estats.EstatPerd;
import projecte.td.estats.EstatPerfil;
import projecte.td.estats.EstatSeguentWave;
import projecte.td.estats.EstatSortir;
import projecte.td.managers.ManagerRecursos;

/**
 * 创建一个 StateBasedGame 的实例（基于状态的游戏中）。它强制我们实现 initStatesList 方法，在该方法中我们将添加用于在游戏中前进的不同状态。
 * @author David Alvarez Palau
 */
public class TDGame extends StateBasedGame {

    /**
     * 带有一个参数的构造函数
     * @param titol 在应用程序窗口（如果有）中显示的字符串
     */
    public TDGame(String titol) {
        super(titol);
    }

    /**
     * 所有扩展 StateBasedGame 的类都必须实现此方法
     * 我们告诉引擎稍后加载资源（EstatLoading）
     * 激活资源管理器以便可以使用图像和声音
     * 将我们创建的不同状态添加到相关列表中
     * @param container
     * @throws SlickException
     */
    @Override
    public void initStatesList(GameContainer container) throws SlickException {
        // 资源将延迟加载
        LoadingList.setDeferredLoading(true);
        // 激活资源管理器
        ManagerRecursos.init();
        // 将游戏的不同状态添加到列表中
        // 游戏介绍状态
        addState(new EstatIntro());
        // 加载资源的状态
        addState(new EstatLoading());
        // 选择要玩的个人资料的状态
        addState(new EstatPerfil());
        // 主菜单状态
        addState(new EstatMenuPrincipal());
        // 通知玩家下一轮的状态
        addState(new EstatSeguentWave());
        // 游戏进行中的状态
        addState(new EstatInGame());
        // 显示游戏内菜单的状态
        // 如果用户没有通过一轮，则显示的状态
        addState(new EstatPerd());
        // 如果用户通过了一轮，则显示的状态
        addState(new EstatGuanya());
        // 数据信息状态
        addState(new EstatDades());
        // 统计信息状态
        addState(new EstatEstadistiques());
        // 初始显示单位信息的状态
        addState(new EstatInfoUnitats());
        // 特定单位信息的状态
        addState(new EstatMostraInfoUnitats());
        // 初始显示敌人信息的状态
        addState(new EstatInfoEnemic());
        // 特定敌人信息的状态
        addState(new EstatMostraInfoEnemics());
        // 音乐选项状态
        addState(new EstatMusica());
        // 确认退出到桌面的状态
        addState(new EstatSortir());

    }

    @Override
    public boolean closeRequested() {
        return false;
    }
}