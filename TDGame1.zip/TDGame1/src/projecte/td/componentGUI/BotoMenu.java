package projecte.td.componentGUI;

import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.Sound;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.GUIContext;
import projecte.td.managers.ManagerPerfil;

/**
 * 这些是游戏中的主要按钮，用于在菜单之间导航
 * @author
 */
public class BotoMenu extends AbstractComponent {

    // 按钮状态
    protected static final int NORMAL = 1;
    protected static final int MOUSE_CLICK = 2;
    protected static final int MOUSE_OVER = 3;
    // 鼠标未悬停时的按钮图像
    protected Image imatgeNormal;
    // 鼠标悬停时的按钮图像
    protected Image imatgeMouseOver;
    // 鼠标点击时的按钮图像
    protected Image mouseDownImage;
    // 按钮需要包含的文本图像
    protected Image imageText;
    // 如果没有图像，按钮的颜色
    protected Color colorNormal = Color.white;
    protected Color colorMouserOver = Color.white;
    protected Color colorMouseClick = Color.white;
    // 鼠标悬停时按钮的声音
    protected Sound soOver;
    // 按钮被点击时的声音
    protected Sound soClick;
    // 按钮占据的区域
    protected Shape area;
    // 按钮的实际图像（将被渲染的）
    protected Image imatgeActual;
    // 按钮的实际颜色
    protected Color colorActual;
    // 表示是否有鼠标悬停
    protected boolean over;
    // 表示是否被鼠标点击
    protected boolean click;
    // 表示是否没有被点击
    protected boolean noClick;
    // 表示声音是否刚刚播放完毕
    protected boolean reproduit;
    // 表示按钮是否需要响应事件
    protected boolean actiu;
    // 按钮的当前状态
    protected int state = NORMAL;

    /**
     * 带有4个参数的构造器
     * @param container 游戏容器
     * @param image 鼠标未悬停时的按钮图像
     * @param x 按钮的X位置
     * @param y 按钮的Y位置
     */
    public BotoMenu(GUIContext container, Image image, int x, int y) {
        this(container, image, x, y, image.getWidth(), image.getHeight());
    }

    /**
     * 带有6个参数的构造器
     * @param container 游戏容器
     * @param image 鼠标未悬停时的按钮图像
     * @param x 按钮的X位置
     * @param y 按钮的Y位置
     * @param width 按钮的宽度
     * @param height 按钮的高度
     */
    public BotoMenu(GUIContext container, Image image, int x, int y, int width,
            int height) {
        this(container, image, new Rectangle(x, y, width, height));
    }

    /**
     * 带有3个参数的构造器
     * @param container 游戏容器
     * @param image 鼠标未悬停时的按钮图像
     * @param shape 按钮占据的区域
     */
    public BotoMenu(GUIContext container, Image image, Shape shape) {
        super(container);

        area = shape;
        imatgeNormal = image;
        imatgeActual = image;
        imatgeMouseOver = image;
        mouseDownImage = image;

        colorActual = colorNormal;

        state = NORMAL;
        Input input2 = container.getInput();
        over = area.contains(input2.getMouseX(), input2.getMouseY());
        click = input2.isMouseButtonDown(0);
        updateImage();
    }

    /**
     * 将按钮放置在指定的坐标
     * @param x 按钮的X位置
     * @param y 按钮的Y位置
     */
    public void setLocation(int x, int y) {
        if (area != null) {
            area.setX(x);
            area.setY(y);
        }
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     * @param container 游戏容器
     * @param g 图形上下文
     */
    public void render(GUIContext container, Graphics g) {
        // 如果已经有图像
        if (imatgeActual != null) {
            int xp = (int) (area.getX() + ((getWidth() - imatgeActual.getWidth()) / 2));
            int yp = (int) (area.getY() + ((getHeight() - imatgeActual.getHeight()) / 2));
            imatgeActual.draw(xp, yp, colorActual);
        } else {
            g.setColor(colorActual);
            g.fill(area);
        }
        // 如果有文本图像则绘制
        if (imageText != null) {
            int xp = (int) (area.getX() + ((getWidth() - imageText.getWidth()) / 2));
            int yp = (int) (area.getY() + ((getHeight() - imageText.getHeight()) / 2));

            imageText.draw(xp, yp, colorActual);
        }
        updateImage();
    }

    /**
     * 根据按钮的状态更新要显示的图像
     */
    protected void updateImage() {
        // 没有鼠标悬停
        if (!over) {
            imatgeActual = imatgeNormal;
            colorActual = colorNormal;
            state = NORMAL;
            noClick = false;
            reproduit = false;
        } else {
            // 鼠标悬停
            if (click) {
                // 被点击
                if ((state != MOUSE_CLICK) && (noClick)) {
                    if (soClick != null && actiu) {
                        soClick.play(1, (float)ManagerPerfil.getVolumEfectes() / 100);
                    }
                    imatgeActual = mouseDownImage;
                    colorActual = colorMouseClick;
                    state = MOUSE_CLICK;
                    notifyListeners();
                    noClick = false;
                }
            } else {
                // 未被点击
                noClick = true;
                if (state != MOUSE_OVER) {
                    if (soOver != null) {
                        if (!reproduit && actiu) {
                            soOver.play(1, (float)ManagerPerfil.getVolumEfectes() / 100);
                            reproduit = true;
                        }
                    }
                    // 如果处于活动状态...
                    if (actiu) {
                        imatgeActual = imatgeMouseOver;
                        colorActual = colorMouserOver;
                        state = MOUSE_OVER;
                    }
                }
            }
        }
        click = false;
        state = NORMAL;
    }

    /**
     * 检查是否有鼠标悬停在按钮上
     * @param oldx
     * @param oldy
     * @param newx
     * @param newy
     */
    @Override
    public void mouseMoved(int oldx, int oldy, int newx, int newy) {
        over = area.contains(newx, newy);
    }

    /**
     * 检查是否在按钮上点击了鼠标
     * @param button
     * @param mx
     * @param my
     */
    @Override
    public void mousePressed(int button, int mx, int my) {
        over = area.contains(mx, my);
        if (button == 0 && actiu) {
            click = true;
        }
    }

    /**
     * 检查是否发生了鼠标释放事件
     * @param button
     * @param mx
     * @param my
     */
    @Override
    public void mouseReleased(int button, int mx, int my) {
        over = area.contains(mx, my);
        if (button == 0) {
            click = false;
        }
    }

    // Getters i setters
    public int getX() {
        return (int) area.getX();
    }

    public int getY() {
        return (int) area.getY();
    }

    public void setNormalColor(Color color) {
        colorNormal = color;
    }

    public void setMouseOverColor(Color color) {
        colorMouserOver = color;
    }

    public void setMouseDownColor(Color color) {
        colorMouseClick = color;
    }

    public void setNormalImage(Image image) {
        imatgeNormal = image;
    }

    public void setMouseOverImage(Image image) {
        imatgeMouseOver = image;
    }

    public void setImageText(Image image) {
        imageText = image;
    }

    public void setMouseDownImage(Image image) {
        mouseDownImage = image;
    }

    public int getHeight() {
        return (int) (area.getMaxY() - area.getY());
    }

    public int getWidth() {
        return (int) (area.getMaxX() - area.getX());
    }

    public GUIContext getContainer() {
        return container;
    }

    public Image getImatgeActual() {
        return imatgeActual;
    }

    public void setActiu(boolean actiu) {
        this.actiu = actiu;
    }

    public boolean isActiu() {
        return this.actiu;
    }

    public void setMouseOverSound(Sound sound) {
        soOver = sound;
    }

    public void setMouseDownSound(Sound sound) {
        soClick = sound;
    }
}
