package projecte.td.componentGUI;


import java.util.ArrayList;
import org.newdawn.slick.Font;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.managers.ManagerPerfil;

import projecte.td.managers.ManagerRecursos;

/**
 * 这个类被用作支持下一个波次状态
 * 检查当前波次可以选择哪些单位以及玩家选择了哪些单位开始游戏
 * @author
 */

public class MenuSeleccio {

    // 游戏容器
    private GameContainer container;
    // 将显示的单位
    private String unitatsAMostrar;
    // 每个单位的相关信息
    private String informacio;
    // 开始放置第一个选择按钮的X位置
    private int posXVariable;
    // 开始放置第一个选择按钮的Y位置
    private int posYVariable;
    // 菜单的X位置
    private int posX;
    // 菜单的Y位置
    private int posY;
    // 希望在单位选择中显示的列数
    private int nColumnesMenu1 = 4;
    // 希望在单位选择中显示的列数
    private int nColumnesMenu2 = 8;
    // 表示是否有变化
    private boolean canvi;
    // 表示是否显示按钮信息
    private boolean mostrarInformacio;
    // 表示菜单是否激活
    private boolean actiu;
    // 用于存储单位选择按钮的ArrayList
    private ArrayList<BotoSeleccio> botonsSeleccio;
    // 用于删除必要单位的ArrayList
    private ArrayList<BotoSeleccio> botonsSeleccio2;
    // 用于存储已选择单位的按钮的ArrayList
    private ArrayList<BotoSeleccio> botonsTriats;
    // 用于删除必要单位的ArrayList
    private ArrayList<BotoSeleccio> botonsTriats2;

    // 用于存储代表敌人的标签的ArrayList
    private ArrayList<LabelSeleccio> cartesEnemics;


    // 用于绘制文本的字体
    private Font font;

    /**
     * 带有3个参数的构造器
     *
     * @param container 游戏
     * @param x         菜单的X位置
     * @param y         菜单的Y位置
     */
    public MenuSeleccio(GameContainer container, int x, int y) {
        this.container = container;
        posX = x;
        posY = y;
        posXVariable = posX + 40;
        posYVariable = posY + 220;
        botonsSeleccio = new ArrayList<BotoSeleccio>();
        botonsSeleccio2 = new ArrayList<BotoSeleccio>();
        botonsTriats = new ArrayList<BotoSeleccio>();
        botonsTriats2 = new ArrayList<BotoSeleccio>();
        cartesEnemics = new ArrayList<LabelSeleccio>();
        unitatsAMostrar = ManagerPerfil.getUnitatsDisponibles();

        font = ManagerRecursos.getFont("dejavuNormalFont");
        actiu = true;

        crearBotons();
        posicionarBotons();
        crearCartes();
    }

    /**
     * 引擎会负责调用这个方法，在这里更新在此状态下使用的变量或对象的数据
     *
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer game, StateBasedGame state, int delta) {
        comprovarMoviments();
        if (canvi) {
            canvi = false;
            posicionarBotons();
        }
        int comptador = 0;
        for (BotoSeleccio b : botonsSeleccio) {
            if (b.isOver()) {
                informacio = b.getUnitat();
                mostrarInformacio = true;
            } else {
                comptador++;
            }
        }
        if (comptador == botonsSeleccio.size()) {

            informacio = "";
            mostrarInformacio = false;
        }
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     *
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer game, StateBasedGame state, Graphics g) {
        for (BotoSeleccio b : botonsSeleccio) {
            b.render(container, g);
        }
        for (BotoSeleccio b : botonsTriats) {
            b.render(container, g);
        }
        if (actiu) {
            g.setFont(font);
            g.drawString("Wave: " + ManagerPerfil.getWave(), 745, 227);

        }
        for (LabelSeleccio ls : cartesEnemics) {
            ls.render(g);
        }
    }

    /**
     * 检查是否需要将某个单位从一个区域移动到另一个区域
     * （从选择区域到已选择单位区域，反之亦然）
     */
    private void comprovarMoviments() {
        if (botonsTriats.size() < 8) {
            for (BotoSeleccio b : botonsSeleccio) {
                if (b.isNotaCanvi()) {
                    b.setNotaCanvi(false);
                    botonsSeleccio2.add(b);
                    botonsTriats.add(b);
                    canvi = true;
                }
            }
            botonsSeleccio.removeAll(botonsSeleccio2);
            botonsSeleccio2.clear();
        } else {
            for (BotoSeleccio b : botonsSeleccio) {
                if (b.isNotaCanvi()) {
                    b.setNotaCanvi(false);
                }
            }
        }
        for (BotoSeleccio b : botonsTriats) {
            if (b.isNotaCanvi()) {
                b.setNotaCanvi(false);
                botonsTriats2.add(b);

                botonsSeleccio.add(b);

                canvi = true;
            }
        }
        botonsTriats.removeAll(botonsTriats2);
        botonsTriats2.clear();
    }

    /**
     * 将按钮放置在适当的位置
     */
    private void posicionarBotons() {
        int columnes = 0;
        int files = 0;
        for (BotoSeleccio b : botonsSeleccio) {
            int posicioBotoX = (columnes * 90) + posXVariable;
            int posicioBotoY = (files * 110) + posYVariable;
            b.setLocation(posicioBotoX, posicioBotoY);
            if (columnes == nColumnesMenu1) {
                columnes = 0;
                files++;
            } else {
                columnes++;
            }
        }
        columnes = 0;
        files = 0;
        for (BotoSeleccio b : botonsTriats) {
            int posicioBotoX = (columnes * 90) + 40;
            int posicioBotoY = (files * 110) + 40;
            b.setLocation(posicioBotoX, posicioBotoY);
            if (columnes == nColumnesMenu2) {

                columnes = 0;
                files++;
            } else {
                columnes++;
            }
        }
    }

    /**
     * 放置敌人的标签
     */
    private void posicionaCartes() {
        int columnes = 0;
        int files = 0;
        for (LabelSeleccio ls : cartesEnemics) {
            int posicioBotoX = (columnes * 90) + 550;
            int posicioBotoY = (files * 110) + 270;
            ls.setLocation(posicioBotoX, posicioBotoY);

            if (columnes == 4) {
                columnes = 0;
                files++;
            } else {
                columnes++;
            }
        }
    }

    /**
     * 创建必要的按钮
     */
    private void crearBotons() {
        String[] s = unitatsAMostrar.split("-");
        BotoSeleccio.setImatgeCarta(ManagerRecursos.getImage("botoCartaImage"));
        BotoSeleccio.setImatgeCartaOver(ManagerRecursos.getImage("botoCartaOverImage"));

        for (String text : s) {
            BotoSeleccio bs = new BotoSeleccio(container, ManagerRecursos.getImage("carta" + text + "Image"),
                    0, 0, text);
            bs.addListener();

            bs.setActiu(true);
            botonsSeleccio.add(bs);
        }
    }

    /**
     * 创建敌人的标签
     */
    private void crearCartes() {
        String[] enemicsImage = ManagerPerfil.getEnemicsWave().split("-");
        for (String z : enemicsImage) {
            LabelSeleccio ls = new LabelSeleccio(ManagerRecursos.getImage("botoCartaImage"),
                    ManagerRecursos.getImage("carta" + z + "Image"));
            cartesEnemics.add(ls);
        }
        posicionaCartes();
    }

    /**
     * 返回玩家选择的单位以进行下一个波次的游戏
     *
     * @return
     */
    public String agafarUnitats() {
        String seleccio = "";
        for (BotoSeleccio b : botonsTriats) {
            seleccio += b.getUnitat() + "-";
        }
        if (seleccio.length() > 1) {
            return seleccio.substring(0, seleccio.length() - 1);
        }
        return "";
    }

    /**
     * 检查是否选择了单位，如果没有选择则不允许继续
     *
     * @return true如果开始游戏
     */
    public boolean unitatsNoNull() {
        if (agafarUnitats().length() > 1) {
            return true;
        }
        return false;
    }

    /**
     * 当游戏开始时移动按钮
     *
     * @param incrementY
     */
    public void moureBotons(int incrementY) {
        for (BotoSeleccio bs : botonsSeleccio) {
            bs.setLocation(bs.getX(), bs.getY() + incrementY);
        }
        for (BotoSeleccio bs : botonsTriats) {
            bs.setLocation(bs.getX(), bs.getY() + incrementY);
        }
        for (LabelSeleccio ls : cartesEnemics) {
            ls.setLocation(ls.getPosX(), ls.getPosY() + incrementY);
        }
    }

    /**
     * 禁用按钮以防止被点击
     */
    public void silenciarBotons() {
        for (BotoSeleccio bs : botonsSeleccio) {
            bs.setActiu(false);
        }
        for (BotoSeleccio bs : botonsTriats) {
            bs.setActiu(false);
        }
        actiu = false;
    }
}
















































