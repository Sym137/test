package projecte.td.componentGUI;

import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;

/**

 用于显示图像的容器

 @author
 */
public class LabelSeleccio {

    // 卡片图像
    private Image imatgeCarta;
    // 敌人图像
    private Image imatgeEnemic;
    // 标签的x位置
    private int posX;
    // 标签的y位置
    private int posY;

    /**

     有两个参数的构造函数
     @param imatgeCarta 卡片图像
     @param imatgeEnemic 敌人图像
     */
    public LabelSeleccio(Image imatgeCarta, Image imatgeEnemic) {
        this.imatgeCarta = imatgeCarta;
        this.imatgeEnemic = imatgeEnemic;
    }
    /**

     此方法用于在屏幕上渲染或绘制想要的元素
     @param g
     */
    public void render(Graphics g) {
        g.drawImage(imatgeCarta, posX, posY);
        g.drawImage(imatgeEnemic, posX + 15, posY + 15);
    }
    /**

     将按钮定位到指定的坐标
     @param x 标签的x位置
     @param y 标签的y位置
     */
    public void setLocation(int posX, int posY) {
        this.posX = posX;
        this.posY = posY;
    }
    // Getters 和 setters
    public int getPosX() {
        return posX;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public int getPosY() {
        return posY;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }
}