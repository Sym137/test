package projecte.td.estats;

import org.newdawn.slick.Font;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.managers.ManagerPerfil;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ArxiuConfiguracio;
import projecte.td.utilitats.Configuracio;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 在这个状态下，通知用户他们已经赢得了比赛，并提供继续下一关、重玩当前关或返回主菜单的选项
 * @author David Alvarez Palau i Ernest Daban Macià
 */
public class EstatGuanya extends BasicGameState {

    // 状态标识符
    public static final int ID = 7;
    // 游戏容器
    private GameContainer container;
    // 状态容器，将用于访问所需的状态
    private StateBasedGame state;
    // 重新开始波次的按钮
    private BotoMenu botoReiniciarWave;
    // 返回主菜单的按钮
    private BotoMenu botoMenuPrincipal;
    // 继续下一关的按钮
    private BotoMenu botoSeguentWave;
    // 用于查看是否可以在下一关选择新单位的文件
    private ArxiuConfiguracio waves;
    // 有关可以使用的新单位的信息
    private String informacioNovesUnitats;
    // 屏幕背景图像
    private Image imatgeFons;
    // 状态标题
    private Image titolEstat;
    // 正常状态的按钮图像（无鼠标悬停）
    private Image imatgeBotoNormal;
    // 鼠标悬停时的按钮图像
    private Image imatgeBotoOver;
    // 正常状态的卡片图像
    private Image imatgeCarta;
    // 鼠标悬停时的角色图像
    private Image imatgePersonatge;
    // 重复按钮的图像
    private Image textRepetir;
    // 继续按钮的图像
    private Image textSeguir;
    // 退出按钮的图像
    private Image textSortir;
    // 用于检查是否需要显示新单位的布尔值
    private boolean unitatNova;
    // 表示是否是最后一关
    private boolean finalWave;

    // 用于渲染文本的字体
    private Font font;

    /**
     * BasicGameState要求我们实现这个方法
     * @return 返回游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化状态所需的变量
     * @param container 游戏容器
     * @param game 游戏状态
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame game)
            throws SlickException {
        this.state = game;
        this.container = container;
        waves = Configuracio.getWaves();
        imatgeFons = ManagerRecursos.getImage("fonsSelectorImage");
        imatgeBotoNormal = ManagerRecursos.getImage("botoPerfil2OverImage");
        imatgeBotoOver = ManagerRecursos.getImage("botoPerfilNormalImage");
        titolEstat = ManagerRecursos.getImage("textGuanyarImage");
        textSeguir = ManagerRecursos.getImage("textSeguirImage");
        textRepetir = ManagerRecursos.getImage("textRepetirImage");
        textSortir = ManagerRecursos.getImage("textSortirImage");
        imatgeCarta = ManagerRecursos.getImage("botoCartaImage");

        font = ManagerRecursos.getFont("dejavuNormalFont");
    }

    /**
     * 游戏引擎负责调用这个方法，在这里更新在此状态下使用的变量或对象的数据
     * @param container 游戏容器
     * @param game 游戏状态
     * @param delta 时间差
     * @throws SlickException
     */
    public void update(GameContainer container, StateBasedGame game, int delta)
            throws SlickException {
        ReproductorMusica.update(container);
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     * @param container 游戏容器
     * @param game 游戏状态
     * @param g 图形上下文
     * @throws SlickException
     */
    public void render(GameContainer container, StateBasedGame game, Graphics g)
            throws SlickException {
        imatgeFons.draw(0, 0);
        titolEstat.draw(250, 150);
        botoMenuPrincipal.render(container, g);
        botoReiniciarWave.render(container, g);
        if (!finalWave) {
            botoSeguentWave.render(container, g);
        }
        g.setFont(font);
        if (unitatNova) {
            imatgeCarta.draw(480, 220);
            imatgePersonatge.draw(490, 230);
        } else if (finalWave) {
            g.drawString("Congratulations,you have beaten all the waves!", 265, 270);
        }
    }

    /**
     * 每次进入这个状态时，会调用这个方法
     * @param gc 当前状态的上下文
     * @param state 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        crearBotonsMenuNormal();
        afegirListeners();
        informacioNovesUnitats = waves.getPropietatString("unitatNova" + ManagerPerfil.getWave());
        imatgePersonatge = ManagerRecursos.getImage("carta" + informacioNovesUnitats + "Image");
        unitatNova = false;
        if (informacioNovesUnitats.equals("final")) {
            finalWave = true;
        } else if (!informacioNovesUnitats.equals("null")) {
            unitatNova = true;
        }
    }

    @Override
    public void leave(GameContainer gc, StateBasedGame state) {
        unitatNova = false;
        finalWave = false;
    }

    /**
     * 在这个方法中创建主菜单中显示的按钮
     * 通过资源管理器为按钮分配图像和位置
     */
    private void crearBotonsMenuNormal() {
        if (!finalWave) {
            // 继续下一关的按钮
            botoSeguentWave = new BotoMenu(container, imatgeBotoNormal, 380, 350);
            botoSeguentWave.setMouseOverImage(imatgeBotoOver);
            botoSeguentWave.setImageText(textSeguir);

            botoSeguentWave.setActiu(true);
        }
        // 重新开始波次的按钮
        botoReiniciarWave = new BotoMenu(container, imatgeBotoNormal, 380, 450);
        botoReiniciarWave.setMouseOverImage(imatgeBotoOver);
        botoReiniciarWave.setImageText(textRepetir);

        botoReiniciarWave.setActiu(true);
        // 返回主菜单的按钮
        botoMenuPrincipal = new BotoMenu(container, imatgeBotoNormal, 380, 550);
        botoMenuPrincipal.setMouseOverImage(imatgeBotoOver);
        botoMenuPrincipal.setImageText(textSortir);

        botoMenuPrincipal.setActiu(true);
    }

    /**
     * 为按钮添加监听器，以便响应按钮操作
     */
    private void afegirListeners() {
        if (!finalWave) {
            botoReiniciarWave.addListener(new ComponentListener() {

                public void componentActivated(AbstractComponent comp) {
                    state.enterState(EstatSeguentWave.ID);
                }
            });
        }
        botoMenuPrincipal.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatMenuPrincipal.ID);
            }
        });
        botoSeguentWave.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                ManagerPerfil.passaASeguentWave();
                state.enterState(EstatSeguentWave.ID);
            }
        });
    }
}