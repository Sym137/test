package projecte.td.estats;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 在这个状态下，通知用户他们已经输了游戏，并提供重新玩当前波次或返回主菜单的选项
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class EstatPerd extends BasicGameState {

    // 状态标识符
    public static final int ID = 6;
    // 游戏容器
    private GameContainer container;
    // 状态容器，用于访问所需的状态
    private StateBasedGame state;
    // 重新开始波次的按钮
    private BotoMenu botoReiniciarWave;
    // 返回主菜单的按钮
    private BotoMenu botoMenuPrincipal;
    // 屏幕背景图像
    private Image imatgeFons;
    // 状态标题
    private Image titolEstat;
    // 正常按钮（鼠标未悬停）的图像
    private Image imatgeBotoNormal;
    // 鼠标悬停时的按钮图像
    private Image imatgeBotoOver;
    // 重复按钮的图像
    private Image textRepetir;
    // 退出按钮的图像
    private Image textSortir;


    /**
     * BasicGameState 要求必须实现这个方法
     *
     * @return int 返回游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化正确运行此状态所需的变量
     *
     * @param container
     * @param game
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame game)
            throws SlickException {
        this.state = game;
        this.container = container;
        imatgeFons = ManagerRecursos.getImage("fonsSelectorImage");
        imatgeBotoNormal = ManagerRecursos.getImage("botoPerfil2OverImage");
        imatgeBotoOver = ManagerRecursos.getImage("botoPerfilNormalImage");
        titolEstat = ManagerRecursos.getImage("textPerdreImage");
        textRepetir = ManagerRecursos.getImage("textRepetirImage");
        textSortir = ManagerRecursos.getImage("textSortirImage");
    }

    /**
     * 引擎负责调用这个方法，在这里将更新此状态中正在使用的变量或对象的数据
     *
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer container, StateBasedGame game, int delta)
            throws SlickException {
        ReproductorMusica.update(container);
    }

    /**
     * 这个方法用于在屏幕上渲染或绘制想要显示的元素
     *
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer container, StateBasedGame game, Graphics g)
            throws SlickException {
        imatgeFons.draw(0, 0);
        titolEstat.draw(250, 150);
        botoMenuPrincipal.render(container, g);
        botoReiniciarWave.render(container, g);
    }

    /**
     * 重写enter方法，该方法在每次进入此状态时都会被调用
     *
     * @param gc    : 当前状态所处的上下文
     * @param state : 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        crearBotonsMenuNormal();
        afegirListeners();
    }

    /**
     * 在这个方法中创建将在主菜单中显示的按钮
     * 通过资源管理器为按钮分配图像和位置
     */
    private void crearBotonsMenuNormal() {
        // BotoMenu 重新开始游戏波次
        botoReiniciarWave = new BotoMenu(container, imatgeBotoNormal, 380, 350);
        botoReiniciarWave.setMouseOverImage(imatgeBotoOver);
        botoReiniciarWave.setImageText(textRepetir);

        botoReiniciarWave.setActiu(true);
        // BotoMenu 返回主菜单
        botoMenuPrincipal = new BotoMenu(container, imatgeBotoNormal, 380, 490);
        botoMenuPrincipal.setMouseOverImage(imatgeBotoOver);
        botoMenuPrincipal.setImageText(textSortir);

        botoMenuPrincipal.setActiu(true);
    }

    /**
     * 添加将触发按钮动作的监听器
     */
    private void afegirListeners() {
        botoReiniciarWave.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatSeguentWave.ID);
            }
        });
        botoMenuPrincipal.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatMenuPrincipal.ID);
            }
        });
    }
}