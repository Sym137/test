package projecte.td.estats;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;
import projecte.td.fx.ImageFxFadeInOut;
import projecte.td.managers.ManagerContext;
import projecte.td.managers.ManagerRecursos;

/**
 * 在这个状态中显示一个简短的介绍
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class EstatIntro extends BasicGameState {

    // 状态标识符
    public static final int ID = 0;
    // Logo图像
    private Image imatgeIntro;
    // 另一个Logo图像
    private Image imatgeIntro2;
    // 用于状态切换的效果
    private ImageFxFadeInOut fxFadeInOutLogo;
    // 用于状态切换的效果
    private ImageFxFadeInOut fxFadeInOutLogo2;
    // 计时器变量
    private int comptador = 0;
    // 计时器的限制值
    private int limitComptador = 12000;

    /**
     * BasicGameState强制实现此方法
     * @return 状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 初始化状态所需的基本变量
     * @param container
     * @param game
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame game)
            throws SlickException {
        ManagerContext.setGui(container);
        ManagerContext.setState(game);
        imatgeIntro = ManagerRecursos.getImage("fonsIntroImage");
        imatgeIntro2 = ManagerRecursos.getImage("fonsIntro2Image");
    }

    /**
     * Slick引擎会调用此方法，用于更新状态中的变量和对象
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer container, StateBasedGame game, int delta)
            throws SlickException {
        fxFadeInOutLogo.update(delta);
        fxFadeInOutLogo2.update(delta);
        comptador += delta;
        // 如果计时器超过限制或者按下Escape键，则加载下一个状态，即EstatLoading，用于加载必要资源
        if (comptador > limitComptador || container.getInput().isKeyDown(Input.KEY_ESCAPE)) {
            game.enterState(EstatLoading.ID, new FadeOutTransition(), new FadeInTransition());
        }
    }

    /**
     * 渲染或在屏幕上绘制元素
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer container, StateBasedGame game, Graphics g)
            throws SlickException {
        fxFadeInOutLogo.render(container, g);
        fxFadeInOutLogo2.render(container, g);
    }

    /**
     * 覆盖enter方法，每次进入状态时调用
     * @param gc 当前的游戏容器
     * @param state 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        fxFadeInOutLogo = new ImageFxFadeInOut(gc, imatgeIntro, 0, 0, 48, 51, 0, 4000);
        fxFadeInOutLogo2 = new ImageFxFadeInOut(gc, imatgeIntro2, 0, 0, 48, 51, 5000, 10000);
    }
}

