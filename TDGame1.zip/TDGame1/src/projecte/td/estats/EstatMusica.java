package projecte.td.estats;

import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.managers.ManagerPerfil;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 在这个状态下，加载资源的同时显示一个屏幕背景和一个进度条
 * @author David Alvarez Palau
 */
public class EstatMusica extends BasicGameState {

    // 状态标识符
    public static final int ID = 16;
    // 游戏容器
    private GameContainer game;
    // 状态容器，用于访问所需的状态
    private StateBasedGame state;
    // 音效音量
    private int volumEfectes;
    // 音乐音量
    private int volumMusica;
    // 屏幕背景图像
    private Image imatgeFons;
    // 状态标题
    private Image titolEstat;
    // 返回按钮文本
    private Image textTornar;
    // 上一曲按钮
    private BotoMenu botoEnrere;
    // 停止按钮
    private BotoMenu botoStop;
    // 下一曲按钮
    private BotoMenu botoEndavant;
    // 返回主菜单按钮
    private BotoMenu botoTornar;
    // 增加音效音量按钮
    private BotoMenu botoSumaEfectes;
    // 减少音效音量按钮
    private BotoMenu botoRestaEfectes;
    // 增加音乐音量按钮
    private BotoMenu botoSumaMusica;
    // 减少音乐音量按钮
    private BotoMenu botoRestaMusica;

    /**
     * BasicGameState 强制我们实现这个方法
     * @return int 游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化状态正常运行所需的变量
     * @param container
     * @param game
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame game)
            throws SlickException {
        this.game = container;
        this.state = game;
        imatgeFons = ManagerRecursos.getImage("fonsSelectorImage");
        textTornar = ManagerRecursos.getImage("textTornarImage");
        titolEstat = ManagerRecursos.getImage("textMusicaImage");

    }

    /**
     * 引擎负责调用这个方法，这里将更新在此状态下使用的变量或对象的数据
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer container, StateBasedGame game, int delta)
            throws SlickException {
        ReproductorMusica.update(container);
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer container, StateBasedGame game, Graphics g)
            throws SlickException {
        imatgeFons.draw(0, 0, container.getWidth(), container.getHeight());
        titolEstat.draw(250, 130);
        botoEndavant.render(container, g);
        botoEnrere.render(container, g);
        botoStop.render(container, g);
        botoTornar.render(container, g);
        botoRestaEfectes.render(container, g);
        botoSumaEfectes.render(container, g);
        botoRestaMusica.render(container, g);
        botoSumaMusica.render(container, g);
        g.setColor(Color.black);
        g.drawString("Music Volume", 455, 400);
        g.drawString("Effects Volume", 455, 470);
        g.setColor(Color.red);
        g.fillRect(botoRestaMusica.getX() + botoRestaMusica.getWidth() + 6, botoRestaMusica.getY() + 20, ((float) volumMusica / 100) * 170, 5);
        g.fillRect(botoRestaEfectes.getX() + botoRestaEfectes.getWidth() + 6, botoRestaEfectes.getY() + 20, ((float) volumEfectes / 100) * 170, 5);
        g.setColor(Color.black);
    }

    /**
     * 覆盖enter方法，每次进入状态时调用
     * @param gc : 当前状态的上下文
     * @param state : 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        crearBotons();
        volumEfectes = ManagerPerfil.getVolumEfectes();
        volumMusica = ManagerPerfil.getVolumMusica();
    }

    private void crearBotons() {
        botoEnrere = new BotoMenu(game, ManagerRecursos.getImage("botoLastImage"), 359, 267);
        botoEnrere.setMouseOverImage(ManagerRecursos.getImage("botoLastOverImage"));
        botoEnrere.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                ReproductorMusica.prev();
            }
        });
      
        botoEnrere.setActiu(true);

        botoStop = new BotoMenu(game, ManagerRecursos.getImage("botoStopImage"), 479, 267);
        botoStop.setMouseOverImage(ManagerRecursos.getImage("botoStopOverImage"));
        botoStop.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                ReproductorMusica.stop();
            }
        });

        botoStop.setActiu(true);

        botoEndavant = new BotoMenu(game, ManagerRecursos.getImage("botoNextImage"), 599, 267);
        botoEndavant.setMouseOverImage(ManagerRecursos.getImage("botoNextOverImage"));
        botoEndavant.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                ReproductorMusica.next();
            }
        });
   
        botoEndavant.setActiu(true);

        botoTornar = new BotoMenu(game, ManagerRecursos.getImage("botoPerfil2OverImage"), 380, 570);
        botoTornar.setMouseOverImage(ManagerRecursos.getImage("botoPerfilNormalImage"));
        botoTornar.setImageText(textTornar);
        botoTornar.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatMenuPrincipal.ID, new FadeOutTransition(), new FadeInTransition());
            }
        });
     
        botoTornar.setActiu(true);

        botoRestaEfectes = new BotoMenu(game, ManagerRecursos.getImage("botoEnrereImage"), 395, 470);
        botoRestaEfectes.setMouseOverImage(ManagerRecursos.getImage("botoEnrereOverImage"));
        botoRestaEfectes.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (volumEfectes > 10) {
                    volumEfectes -= 10;
                    ManagerPerfil.setVolumEfectes(volumEfectes);
                    ManagerPerfil.guardarValorsMusica();
                }
            }
        });
    
        botoRestaEfectes.setActiu(true);

        botoSumaEfectes = new BotoMenu(game, ManagerRecursos.getImage("botoEndavantImage"), 605, 470);
        botoSumaEfectes.setMouseOverImage(ManagerRecursos.getImage("botoEndavantOverImage"));
        botoSumaEfectes.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (volumEfectes < 100) {
                    volumEfectes += 10;
                    ManagerPerfil.setVolumEfectes(volumEfectes);
                    ManagerPerfil.guardarValorsMusica();
                }
            }
        });
    
        botoSumaEfectes.setActiu(true);

        botoRestaMusica = new BotoMenu(game, ManagerRecursos.getImage("botoEnrereImage"), 395, 400);
        botoRestaMusica.setMouseOverImage(ManagerRecursos.getImage("botoEnrereOverImage"));
        botoRestaMusica.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (volumMusica > 10) {
                    volumMusica -= 10;
                    ManagerPerfil.setVolumMusica(volumMusica);
                    ManagerPerfil.guardarValorsMusica();
                    ReproductorMusica.setVolumMusic();
                    ReproductorMusica.update(game);
                }
            }
        });
       
        botoRestaMusica.setActiu(true);

        botoSumaMusica = new BotoMenu(game, ManagerRecursos.getImage("botoEndavantImage"), 605, 400);
        botoSumaMusica.setMouseOverImage(ManagerRecursos.getImage("botoEndavantOverImage"));
        botoSumaMusica.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (volumMusica < 100) {
                    volumMusica += 10;
                    ManagerPerfil.setVolumMusica(volumMusica);
                    ManagerPerfil.guardarValorsMusica();
                    ReproductorMusica.setVolumMusic();
                    ReproductorMusica.update(game);
                }
            }
        });
  
        botoSumaMusica.setActiu(true);
    }
}
