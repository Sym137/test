package projecte.td.estats;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.componentGUI.MenuSeleccio;
import projecte.td.managers.ManagerEnemics;
import projecte.td.managers.ManagerPerfil;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 在这个状态中，用户可以选择他们将在下一个波次中使用的单位。
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class EstatSeguentWave extends BasicGameState {

    // 状态标识符
    public static final int ID = 4;
    // 游戏容器
    private GameContainer container;
    // 状态容器，用于访问游戏中的不同状态
    private StateBasedGame state;
    // 屏幕背景
    private Image imatgeFons;
    // 状态背景的位置
    private int posYFons;
    // 用于开始游戏的X按钮图像
    private Image imatgeBotoX;
    // 用于开始游戏的V按钮图像
    private Image imatgeBotoV;
    // 用于开始游戏的X按钮悬停图像
    private Image imatgeBotoXOver;
    // 用于开始游戏的V按钮悬停图像
    private Image imatgeBotoVOver;
    // 菜单对象，检查可以选择和已选择的单位
    private MenuSeleccio ms;
    // 进入下一个状态的按钮
    private BotoMenu botoContinuar;
    // 返回主菜单的按钮
    private BotoMenu botoTornar;
    // 减少一个波次的按钮
    private BotoMenu botoEnrere;
    // 增加一个波次的按钮
    private BotoMenu botoEndavant;
    // 指示是否已经按下某个按钮
    private boolean botoApretat;
    // 用于背景移动的计数器
    private int comptador;

    /**
     * BasicGameState 强制我们实现这个方法
     * @return int 游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化状态正常运行所需的变量
     * @param container
     * @param game
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame state) {
        this.container = container;
        this.state = state;
        imatgeFons = ManagerRecursos.getImage("fonsSeguentWaveImage");
        imatgeBotoX = ManagerRecursos.getImage("botoXImage");
        imatgeBotoV = ManagerRecursos.getImage("botoVImage");
        imatgeBotoXOver = ManagerRecursos.getImage("botoXOverImage");
        imatgeBotoVOver = ManagerRecursos.getImage("botoVOverImage");

    }

    /**
     * 覆盖enter方法，每次进入状态时调用
     * @param gc : 当前状态的上下文
     * @param state : 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        ms = new MenuSeleccio(container, 0, 0);
        crearBotons();
    }

    /**
     * 覆盖leave方法，每次退出状态时调用
     * @param gc
     * @param state
     */
    @Override
    public void leave(GameContainer gc, StateBasedGame state) {
        ms = null;
        botoApretat = false;
        comptador = 0;
        posYFons = 0;
        botoContinuar.setLocation(660, 630);
        botoTornar.setLocation(800, 630);
    }

    /**
     * 创建继续或返回所需的按钮
     */
    private void crearBotons() {
        botoContinuar = new BotoMenu(container, imatgeBotoV, 660, 630);
        botoContinuar.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (ms.unitatsNoNull()) {
                    botoApretat = true;
                    ManagerEnemics.iniciaWave(ManagerPerfil.getWave());
                }
            }
        });
        botoContinuar.setMouseOverImage(imatgeBotoVOver);

        botoContinuar.setActiu(true);

        botoTornar = new BotoMenu(container, imatgeBotoX, 800, 630);
        botoTornar.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatMenuPrincipal.ID, new FadeOutTransition(), new FadeInTransition());
            }
        });
        botoTornar.setMouseOverImage(imatgeBotoXOver);

        botoTornar.setActiu(true);

        botoEnrere = new BotoMenu(container, ManagerRecursos.getImage("botoEnrereImage"), 676, 228);
        botoEnrere.setMouseOverImage(ManagerRecursos.getImage("botoEnrereOverImage"));
        botoEnrere.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (ManagerPerfil.potRestarWave()) {
                    ManagerPerfil.restaWaveActual();
                    ManagerPerfil.assignarPropietats();
                    state.enterState(ID);
                }
            }
        });

        botoEnrere.setActiu(true);

        botoEndavant = new BotoMenu(container, ManagerRecursos.getImage("botoEndavantImage"), 884, 228);
        botoEndavant.setMouseOverImage(ManagerRecursos.getImage("botoEndavantOverImage"));
        botoEndavant.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (ManagerPerfil.potSumarWave()) {
                    ManagerPerfil.sumaWaveActual();
                    ManagerPerfil.assignarPropietats();
                    state.enterState(ID);
                }
            }
        });

        botoEndavant.setActiu(true);
    }

    /**
     * 引擎负责调用这个方法，这里将更新在此状态下使用的变量或对象的数据
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer game, StateBasedGame state, int delta) {
        ms.update(game, state, delta);
        // 如果按下V按钮（开始波次），按钮将被禁用
        if (botoApretat) {
            if (botoContinuar.isActiu() || botoTornar.isActiu()) {
                botoContinuar.setActiu(false);
                botoTornar.setActiu(false);
                ms.silenciarBotons();
                botoContinuar.setActiu(false);
                botoTornar.setActiu(false);
                botoEndavant.setActiu(false);
                botoEnrere.setActiu(false);
            }
            // 开始状态背景的移动以适应下一个状态
            comptador += 1;
            posYFons += 4;
            // 定位按钮
            botoContinuar.setLocation(660, botoContinuar.getY() + 4);
            botoTornar.setLocation(800, botoTornar.getY() + 4);
            botoEndavant.setLocation(botoEndavant.getX(), botoEndavant.getY() + 4);
            botoEnrere.setLocation(botoEnrere.getX(), botoEnrere.getY() + 4);
            ms.moureBotons(4);
            if (comptador > 150) {
                // 获取已选择的单位并进入下一个状态
                ManagerPerfil.setUnitatsTriades(ms.agafarUnitats());
                state.enterState(5);
            }
        }
        ReproductorMusica.update(container);
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer game, StateBasedGame state, Graphics g) {
        imatgeFons.draw(0, posYFons);
        botoContinuar.render(container, g);
        botoTornar.render(container, g);
        botoEnrere.render(container, g);
        botoEndavant.render(container, g);
        ms.render(game, state, g);
    }
}