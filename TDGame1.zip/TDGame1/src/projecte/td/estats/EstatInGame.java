package projecte.td.estats;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.componentIngame.MenuIngame;
import projecte.td.domini.Aura;
import projecte.td.domini.IAuraRapidesa;
import projecte.td.domini.IAuraVida;
import projecte.td.joc.Tauler;
import projecte.td.factories.FactoriaUnitatsEnemics;
import projecte.td.managers.ManagerRecursos;
import projecte.td.managers.ManagerDinersAures;
import projecte.td.domini.UnitatAbstract;
import projecte.td.managers.ManagerContext;
import projecte.td.managers.ManagerEnemics;
import projecte.td.managers.ManagerPerfil;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 在这个状态下，游戏的主要行动得以进行。在这里发展波次，用户必须保卫位置。它是实时发展的。
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class EstatInGame extends BasicGameState {

    // 状态标识符
    public static final int ID = 5;
    // 游戏容器
    private GameContainer gc;
    // 状态容器，用于访问游戏中的不同状态
    private StateBasedGame state;
    // 背景画面
    private Image imatgeFons;
    // 管理单位、敌人和炮弹位置的棋盘
    private Tauler p;
    // 包含在此状态下使用的按钮的菜单
    private MenuIngame mi;
    // 管理玩家在波次中拥有的金钱
    private ManagerDinersAures md;
    // 指示在待命区的单位，以便放置在棋盘上
    private String unitat = "null";

    /**
     * BasicGameState 强制我们实现这个方法
     * @return int 游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化状态正常运行所需的变量
     * @param container
     * @param game
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame game)
            throws SlickException {
        this.gc = container;
        this.state = game;
        imatgeFons = ManagerRecursos.getImage("fonsIngameImage");
    }

    /**
     * 引擎会负责调用这个方法，这里将更新在此状态下使用的变量或对象的数据
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer gc, StateBasedGame game, int delta)
            throws SlickException {
        Input input = gc.getInput();
        // 如果在顶部区域用鼠标左键点击
        if (input.isMousePressed(Input.MOUSE_LEFT_BUTTON) && input.getMouseY() <= 600) {
            if (unitat.equals("pala")) {
                // 如果激活了pala，则从棋盘上点击的位置删除单位
                // 单位
                p.borrarUnitatAmiguesClick(input.getMouseX(), input.getMouseY());
                unitat = "null";
                mi.realitzaTransaccio();
            } else if (!unitat.equals("null") && p.comprovaClickCorrecte(input.getMouseX(), input.getMouseY())) {
                // 如果有可用的单位和棋盘上可用的位置
                // 在棋盘上放置一个友军单位，并从金钱管理器中扣除费用
                int[] posFC = p.mirarCoordenadesClick(input.getMouseX(), input.getMouseY());
                if (p.comprovarClick(posFC[0], posFC[1])) {
                    UnitatAbstract u = null;
                    u = FactoriaUnitatsEnemics.getUnitatBona(unitat);
                    p.posicionaUnitatAmiga(posFC[0], posFC[1], u);
                    unitat = "null";
                    mi.realitzaTransaccio();
                }
            }
        } // 如果点击了鼠标中键
        else if (input.isMousePressed(Input.MOUSE_MIDDLE_BUTTON)) {
            // 如果有待处理的光环，检查棋盘上点击的位置是否有可以装备该光环的单位。如果有，将光环放置在单位上
            if (md.isAuraEnEspera()) {
                UnitatAbstract ua = p.getUnitatAmiga(input.getMouseX(), input.getMouseY());
                if (ua instanceof IAuraRapidesa && md.getTipusAuraEspera().equals("MagRapidesa")) {
                    Aura aura = new Aura(md.getTipusAuraEspera(),
                            ManagerRecursos.getImage("auraRapidesaImage"), 2);
                    if (ua.potEquiparAura(aura) && !ua.isAuraActiva()) {
                        ua.activarAura(aura);
                        md.clearAures();
                        ManagerPerfil.sumaAuraColocada();
                    }
                } else if (ua instanceof IAuraVida && md.getTipusAuraEspera().equals("MagVida")) {
                    Aura aura = new Aura(md.getTipusAuraEspera(),
                            ManagerRecursos.getImage("auraVidaImage"), 10);
                    if (ua.potEquiparAura(aura) && !ua.isAuraActiva()) {
                        ua.activarAura(aura);
                        md.clearAures();
                        ManagerPerfil.sumaAuraColocada();
                    }
                }
            }
        } // 如果点击了鼠标右键，取消选择单位或元素
        else if (input.isMousePressed(Input.MOUSE_RIGHT_BUTTON)) {
            mi.clear();
            mi.reiniciarBotons();
            unitat = "null";
            p.setDibuixarQuadrat(false);
        }
        // 更新棋盘
        p.update(delta);
        // 更新游戏内菜单
        mi.update();
        // 如果有一个元素在等待，这将被分配给这个类的相应属性
        if (mi.isEnEspera()) {
            unitat = mi.getElementEsperant();
            mi.clear();
        }
        // 如果选择了一个单位，并且鼠标在顶部区域，绘制显示是否可以在棋盘上放置单位的方框
        if (!unitat.equals("null") && input.getMouseY() <= 600 && p.comprovaClickCorrecte(input.getMouseX(), input.getMouseY())) {
            p.setDibuixarQuadrat(true);
            p.setPosicioDibuixQuadrat(input.getMouseX(), input.getMouseY());
        } else {
            p.setDibuixarQuadrat(false);
        }
        // 如果敌人管理器有一个敌人等待进入游戏，这个敌人将被放置在棋盘上
        if (ManagerEnemics.isEnEspera()) {
            UnitatAbstract ua = ManagerEnemics.getUnitat();
            int random = ManagerEnemics.triarCarril();
            p.posicionaUnitatEnemiga(1000, random, ua);
        }
        // 检查游戏是否结束，用户是否输了
        if (p.observarPartidaFinalitzada()) {
            p.borrarTot();
            ManagerPerfil.sumaPerdudes();
            ManagerPerfil.guardarEstadistiques();
            ManagerEnemics.pararTimer();
            state.enterState(EstatPerd.ID);
        }
        // 检查游戏是否结束，用户是否赢了
        if (ManagerEnemics.fidelaWave() && !p.enemicsEnTauler()) {
            p.borrarTot();
            ManagerPerfil.sumaGuanyada();
            ManagerPerfil.guardarEstadistiques();
            ManagerEnemics.pararTimer();
            state.enterState(EstatGuanya.ID);
        }
        // 更新音乐播放器
        ReproductorMusica.update(gc);
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer gc, StateBasedGame game, Graphics g)
            throws SlickException {
        imatgeFons.draw(0, 0);
        p.dibuixar(g, gc);
        mi.render(gc, g);
        if (ManagerEnemics.isMostraCartell()) {
            ManagerEnemics.renderCartell(gc, g);
        }
    }

    /**
     * 覆盖enter方法，每次进入状态时调用
     * @param gc : 当前状态的上下文
     * @param state : 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        p = new Tauler(6, 10, 1024, 600);
        md = new ManagerDinersAures();
        mi = new MenuIngame(gc, 0, 600, ManagerRecursos.getImage("contenidorIngameImage"), ManagerPerfil.getUnitatsTriades(), md, state);
        mi.clear();
        mi.reiniciarBotons();
        ManagerContext.setDiners(md);
        ManagerEnemics.iniciarCompteEnrere();
    }


    /**
     * 覆盖leave方法，每次退出状态时调用
     * @param gc
     * @param state
     */
    @Override
    public void leave(GameContainer gc, StateBasedGame state) {
        mi = null;
    }
}
