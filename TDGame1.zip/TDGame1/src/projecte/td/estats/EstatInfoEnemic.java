package projecte.td.estats;

import java.util.ArrayList;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.componentGUI.BotoSeleccio;
import projecte.td.managers.ManagerPerfil;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ArxiuConfiguracio;
import projecte.td.utilitats.Configuracio;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 在这个状态下，显示玩家已经见过的敌人。用户可以点击以进入另一个状态，显示有关敌人的信息。
 * @author David Alvarez Palau i Ernest Daban Macià
 */
public class EstatInfoEnemic extends BasicGameState {

    // 状态标识符
    public static final int ID = 12;
    // 游戏容器
    private GameContainer container;
    // 状态容器，将用于访问所需的状态
    private StateBasedGame state;
    // 重新开始波次的按钮
    private BotoMenu botoDades;
    // 当前波次
    private int wave;
    // 开始放置第一个选择单位按钮的X位置
    private int posXVariable;
    // 开始放置第一个选择单位按钮的Y位置
    private int posYVariable;
    // 存储单位选择按钮的ArrayList
    private ArrayList<BotoSeleccio> botonsSeleccio;
    // 屏幕背景图像
    private Image imatgeFons;
    // 状态标题
    private Image titolEstat;
    // 返回按钮的文本
    private Image textTornar;
    // 按钮正常图像（无鼠标悬停）
    private Image imatgeBotoNormal;
    // 鼠标悬停时的按钮图像
    private Image imatgeBotoOver;

    // 包含当前波次信息的配置文件
    private ArxiuConfiguracio waves;
    // 将显示为可用的单位
    private String unitatsTriades;

    /**
     * BasicGameState要求我们实现这个方法
     * @return 返回游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化状态所需的变量
     * @param container 游戏容器
     * @param game 游戏状态
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame game)
            throws SlickException {
        this.state = game;
        this.container = container;
        imatgeFons = ManagerRecursos.getImage("fonsSelectorImage");
        imatgeBotoNormal = ManagerRecursos.getImage("botoPerfil2OverImage");
        imatgeBotoOver = ManagerRecursos.getImage("botoPerfilNormalImage");
        textTornar = ManagerRecursos.getImage("textTornarImage");
        titolEstat = ManagerRecursos.getImage("textEnemicsGranImage");
    }

    /**
     * 游戏引擎负责调用这个方法，在这里更新在此状态下使用的变量或对象的数据
     * @param container 游戏容器
     * @param game 游戏状态
     * @param delta 时间差
     * @throws SlickException
     */
    public void update(GameContainer container, StateBasedGame game, int delta)
            throws SlickException {
        ReproductorMusica.update(container);
        for (BotoSeleccio bs : botonsSeleccio) {
            if (bs.isNotaCanvi()) {
                bs.setNotaCanvi(false);
                ManagerPerfil.setInformacioUnitat(bs.getUnitat());
                state.enterState(EstatMostraInfoEnemics.ID);
            }
        }
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     * @param container 游戏容器
     * @param game 游戏状态
     * @param g 图形上下文
     * @throws SlickException
     */
    public void render(GameContainer container, StateBasedGame game, Graphics g)
            throws SlickException {
        imatgeFons.draw(0, 0);
        titolEstat.draw(250, 130);
        botoDades.render(container, g);
        for (BotoSeleccio b : botonsSeleccio) {
            b.render(container, g);
        }
    }

    /**
     * 每次进入这个状态时，会调用这个方法
     * @param gc 当前状态的上下文
     * @param state 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        posXVariable = 290;
        posYVariable = 220;
        botonsSeleccio = new ArrayList<BotoSeleccio>();
        crearBotonsMenuNormal();
        afegirListeners();
        wave = ManagerPerfil.getWaveActual();
        waves = Configuracio.getWaves();
        unitatsTriades = waves.getPropietatString("enemicsDisponibles" + wave);
        crearBotons();
        posicionarBotons();
    }

    /**
     * 在这个方法中创建主菜单中显示的按钮
     * 通过资源管理器为按钮分配图像和位置
     */
    private void crearBotonsMenuNormal() {
        // 返回主菜单的按钮
        botoDades = new BotoMenu(container, imatgeBotoNormal, 380, 570);
        botoDades.setMouseOverImage(imatgeBotoOver);
        botoDades.setImageText(textTornar);

        botoDades.setActiu(true);
    }

    /**
     * 创建必要的按钮
     */
    private void crearBotons() {
        String[] s = unitatsTriades.split("-");
        BotoSeleccio.setImatgeCarta(ManagerRecursos.getImage("botoCartaImage"));
        BotoSeleccio.setImatgeCartaOver(ManagerRecursos.getImage("botoCartaOverImage"));
        for (String text : s) {
            BotoSeleccio bs = new BotoSeleccio(container, ManagerRecursos.getImage("carta" + text + "Image"),
                    0, 0, text);
            bs.addListener();

            bs.setActiu(true);
            botonsSeleccio.add(bs);
        }
    }

    /**
     * 将按钮放置在适当的位置
     */
    private void posicionarBotons() {
        int columnes = 0;
        int files = 0;
        for (BotoSeleccio b : botonsSeleccio) {
            int posicioBotoX = (columnes * 90) + posXVariable;
            int posicioBotoY = (files * 110) + posYVariable;
            b.setLocation(posicioBotoX, posicioBotoY);
            if (columnes == 4) {
                columnes = 0;
                files++;
            } else {
                columnes++;
            }
        }
    }

    /**
     * 为按钮添加监听器，以便响应按钮操作
     */
    private void afegirListeners() {
        botoDades.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatDades.ID);
            }
        });
    }
}
