package projecte.td.estats;

import org.newdawn.slick.Color;
import org.newdawn.slick.Font;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.loading.DeferredResource;
import org.newdawn.slick.loading.LoadingList;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 在这个状态下，资源被加载，同时显示一个屏幕背景和一个进度条
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class EstatLoading extends BasicGameState {

    // 状态标识符
    public static final int ID = 1;
    // 游戏容器
    private GameContainer game;
    // 屏幕背景图像
    private Image imatgeFons;
    // 显示游戏标志的图像
    private Image imatgeTitol;
    // 标题在X轴上的位置
    private int posXTitol;
    // 标题在Y轴上的位置
    private int posYTitol;
    // 允许延迟加载资源（更晚）
    private DeferredResource recurs;
    // 要加载的总资源数
    private float total;
    // 到目前为止已加载的资源
    private float carregat;
    // 用于使文本出现和消失的计数器变量
    private long parpadeig;
    // 文本最初将被显示
    private boolean mostra = true;
    // 表示是否正在执行标题（标志）的移动效果
    private boolean moviment;
    // 表示是否已完成标题的移动
    private boolean fiMoviment;
    // 用于渲染文本的字体
    private Font font;
    // 加载条的颜色
    private Color colorBarra = new Color(107 / 255f, 18 / 255f, 12 / 255f,
            255 / 255f);

    /**
     * BasicGameState 强制我们实现这个方法
     * @return int 游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化状态正常运行所需的变量
     * @param container
     * @param game
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame game)
            throws SlickException {
        this.game = container;
        imatgeFons = ManagerRecursos.getImage("fonsMenuImage");
        imatgeTitol = ManagerRecursos.getImage("fonsTitolImage");
        font = ManagerRecursos.getFont("dejavuNormalFont");
        posXTitol = 290;
        posYTitol = 200;
    }

    /**
     * 引擎负责调用这个方法，这里将更新在此状态下使用的变量或对象的数据
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer container, StateBasedGame game, int delta)
            throws SlickException {
        // 如果已加载的资源等于总数，则进入下一个状态
        // 当用户按下鼠标左键时
        if (carregat == total) {
            Input input = container.getInput();
            // 开始一个效果，移动标题的位置
            if (moviment) {
                posYTitol -= 0.5;
                if (posYTitol <= 100) {
                    moviment = false;
                    fiMoviment = true;
                }
            } else if (fiMoviment) {
                // 如果完成移动，则开始音乐播放器并进入下一个状态
                ReproductorMusica.init();
                ReproductorMusica.toggleRepeatAll();
                ReproductorMusica.toggleShuffle();
                game.enterState(EstatPerfil.ID);
            }
            // 当所有资源都已加载并且按下鼠标左键时，开始标题的移动
            if (input.isMouseButtonDown(Input.MOUSE_LEFT_BUTTON)) {
                moviment = true;
            }
            // 变量parpadeig用于执行文本的闪烁效果，当所有资源都已加载后
            // 一次写入文本
            if (parpadeig >= 700) {
                mostra = !mostra;
                parpadeig = 0;
            }
            parpadeig += delta;
        }

        // 如果还有资源要加载，则继续加载
        // 这是一个风险区域，需要用适当的try catch控制
        if (LoadingList.get().getRemainingResources() > 0) {
            recurs = LoadingList.get().getNext();
            try {
                recurs.load();
                carregat = LoadingList.get().getTotalResources() - LoadingList.get().getRemainingResources();
            } catch (Exception ioe) {
                throw new SlickException("An error occurred while loading the resources...");
            }
        } else {
            carregat = total;
        }
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer container, StateBasedGame game, Graphics g)
            throws SlickException {
        imatgeFons.draw(0, 0, container.getWidth(), container.getHeight());
        imatgeTitol.draw(posXTitol, posYTitol);
        g.setColor(colorBarra);
        g.fillRect(270, 650, (carregat / total) * 490, 30);
        g.setColor(Color.white);
        g.drawRect(270, 650, 490, 30);
        g.setColor(Color.white);
        g.setFont(font);
        // 如果所有资源都已加载，显示一个指示消息
        if (carregat == total) {
            if (mostra) {
                g.drawString("Click to play or press Esc to exit", 260, 610);
            }
        } else {
            g.drawString("Loading,please wait……", 360, 610);
        }
        g.setColor(Color.black);
    }

    /**
     * KeyPressed的覆盖，如果所有资源都已加载并且按下Esc键，则退出游戏
     * @param key
     * @param c
     */
    @Override
    public void keyPressed(int key, char c) {
        if (Input.KEY_ESCAPE == key && carregat == total) {
            game.exit();
        }
    }

    /**
     * 覆盖enter方法，每次进入状态时调用
     * @param gc : 当前状态的上下文
     * @param state : 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        total = LoadingList.get().getTotalResources();
        moviment = false;
        fiMoviment = false;
        posXTitol = 290;
        posYTitol = 200;
    }
}