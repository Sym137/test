package projecte.td.estats;

import org.newdawn.slick.Font;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.utilitats.Configuracio;
import projecte.td.utilitats.ArxiuConfiguracio;
import projecte.td.managers.ManagerPerfil;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 在这个状态中，将选择要使用的用户个人资料
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class EstatPerfil extends BasicGameState {

    // BasicGameState 的标识符
    public static final int ID = 2;
    // 游戏容器
    private GameContainer container;
    // 状态容器，可以控制访问其他状态
    private StateBasedGame state;
    // 选择相应存档的按钮
    // 存档1按钮
    private BotoMenu botoPerfil1;
    // 删除存档1按钮
    private BotoMenu botoBorrar1;
    // 存档2按钮
    private BotoMenu botoPerfil2;
    // 删除存档2按钮
    private BotoMenu botoBorrar2;
    // 存档3按钮
    private BotoMenu botoPerfil3;
    // 删除存档3按钮
    private BotoMenu botoBorrar3;
    // 布尔值，用于检查是否需要执行透明度效果
    private boolean alphaBotonsIn;
    // 布尔值，用于检查是否需要执行透明度效果
    private boolean alphaBotonsOut;
    // 指示按钮是否可以渲染
    private boolean carregat;
    // 用于alpha渐变的浮点数
    private float transparencia;
    // 按钮移动的计数器
    private int comptador;
    // 屏幕背景图像
    private Image imatgeFons;
    // 显示游戏标志的图像
    private Image imatgeTitol;
    // 正常按钮（无鼠标悬停）的图像
    private Image imatgeBotoNormal;
    // 鼠标悬停时的按钮图像
    private Image imatgeBotoOver;
    // 删除存档按钮的图像
    private Image imatgeBotoBorrar;
    // 删除存档按钮悬停时的图像
    private Image imatgeBotoBorrarOver;
    // 存档1文本图像
    private Image imatgeTextPerfil1;
    // 存档2文本图像
    private Image imatgeTextPerfil2;
    // 存档3文本图像
    private Image imatgeTextPerfil3;
    // 用于获取存档信息的配置文件
    private ArxiuConfiguracio perfils;
    // 用于渲染文本的字体
    private Font font;
    // 用于查看是否重置了存档的字符串
    private String reiniciarPerfil;
    // 用于检查是否重置了存档的计数器
    private int comptadorReiniciarPerfil;

    /**
     * BasicGameState 强制我们实现这个方法
     * @return int 游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化状态正常运行所需的变量
     * @param container
     * @param game
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame state) {
        this.container = container;
        this.state = state;
        imatgeFons = ManagerRecursos.getImage("fonsMenuImage");
        imatgeTitol = ManagerRecursos.getImage("fonsTitolImage");
        imatgeBotoOver = ManagerRecursos.getImage("botoPerfilNormalImage");
        imatgeBotoNormal = ManagerRecursos.getImage("botoPerfil2OverImage");
        imatgeBotoBorrar = ManagerRecursos.getImage("botoXImage");
        imatgeBotoBorrarOver = ManagerRecursos.getImage("botoXOverImage");
        imatgeTextPerfil1 = ManagerRecursos.getImage("textPerfil1Image");
        imatgeTextPerfil2 = ManagerRecursos.getImage("textPerfil2Image");
        imatgeTextPerfil3 = ManagerRecursos.getImage("textPerfil3Image");
        font = ManagerRecursos.getFont("dejavuNormalFont");

    }

    /**
     * 引擎负责调用这个方法，这里将更新在此状态下使用的变量或对象的数据
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer game, StateBasedGame state, int delta) {
        // 如果正在进入状态或退出状态，则执行透明度效果
        if (alphaBotonsIn) {
            comptador += 50;
            if (comptador % 100 == 0) {
                // 按钮变得不那么透明
                transparencia += 0.05;
            }
            // 当按钮不再透明时激活
            if (transparencia >= 1) {
                botoPerfil1.setActiu(true);
                botoPerfil2.setActiu(true);
                botoPerfil3.setActiu(true);
                botoBorrar1.setActiu(true);
                botoBorrar2.setActiu(true);
                botoBorrar3.setActiu(true);
                alphaBotonsIn = false;
                comptador = 0;
            }
        } else if (alphaBotonsOut) {
            // 当按钮变得透明时它们被禁用
            botoPerfil1.setActiu(false);
            botoPerfil2.setActiu(false);
            botoPerfil3.setActiu(false);
            botoBorrar1.setActiu(false);
            botoBorrar2.setActiu(false);
            botoBorrar3.setActiu(false);
            comptador += 50;
            if (comptador % 100 == 0) {
                transparencia -= 0.05;
            }
            // 当透明度达到0时，进入下一个状态
            if (transparencia <= 0) {
                state.enterState(EstatMenuPrincipal.ID);
            }
            ReproductorMusica.update(container);
        }
        // 如果删除了一个个人资料，则在屏幕上显示一条消息
        if (!reiniciarPerfil.equals("null")) {
            comptadorReiniciarPerfil++;
            if (comptadorReiniciarPerfil == 70) {
                reiniciarPerfil = "null";
                comptadorReiniciarPerfil = 0;
            }
        }
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer game, StateBasedGame state, Graphics g) {
        imatgeFons.draw(0, 0);
        imatgeTitol.draw(290,100);
        if (carregat) {
            imatgeBotoBorrar.setAlpha(transparencia);
            imatgeBotoNormal.setAlpha(transparencia);
            imatgeBotoOver.setAlpha(transparencia);
            imatgeTextPerfil1.setAlpha(transparencia);
            imatgeTextPerfil2.setAlpha(transparencia);
            imatgeTextPerfil3.setAlpha(transparencia);
            botoPerfil1.render(game, g);
            botoPerfil2.render(game, g);
            botoPerfil3.render(game, g);
            botoBorrar1.render(game, g);
            botoBorrar2.render(game, g);
            botoBorrar3.render(game, g);
            if (!reiniciarPerfil.equals("null")) {
                g.setFont(font);
                g.drawString("已重置 " + reiniciarPerfil, 370, 690);
            }
        }
    }

    /**
     * 创建存档菜单所需的按钮
     * @param container
     */
    private void crearBotons(GameContainer container) {
        // 创建按钮
        // 存档1
        botoPerfil1 = new BotoMenu(container, imatgeBotoNormal, 420, 300);
        botoPerfil1.setLocation(container.getWidth() / 2 - botoPerfil1.getWidth() / 2 - imatgeBotoBorrar.getWidth() / 2, 380);
        botoPerfil1.setMouseOverImage(imatgeBotoOver);
        botoPerfil1.setImageText(imatgeTextPerfil1);

        botoBorrar1 = new BotoMenu(container, imatgeBotoBorrar, 420, 300);
        botoBorrar1.setLocation(container.getWidth() / 2 - botoBorrar1.getWidth() / 2 + 145, 379);
        botoBorrar1.setMouseOverImage(imatgeBotoBorrarOver);

        // 存档2
        botoPerfil2 = new BotoMenu(container, imatgeBotoNormal, 420, 450);
        botoPerfil2.setLocation(container.getWidth() / 2 - botoPerfil2.getWidth() / 2 - imatgeBotoBorrar.getWidth() / 2, 500);
        botoPerfil2.setMouseOverImage(imatgeBotoOver);
        botoPerfil2.setImageText(imatgeTextPerfil2); botoBorrar2 = new BotoMenu(container, imatgeBotoBorrar, 420, 300);
        botoBorrar2.setLocation(container.getWidth() / 2 - botoBorrar2.getWidth() / 2 + 145, 499);
        botoBorrar2.setMouseOverImage(imatgeBotoBorrarOver);

        // 存档3
        botoPerfil3 = new BotoMenu(container, imatgeBotoNormal, 420, 600);
        botoPerfil3.setLocation(container.getWidth() / 2 - botoPerfil3.getWidth() / 2 - imatgeBotoBorrar.getWidth() / 2, 620);
        botoPerfil3.setMouseOverImage(imatgeBotoOver);
        botoPerfil3.setImageText(imatgeTextPerfil3);

        botoBorrar3 = new BotoMenu(container, imatgeBotoBorrar, 420, 300);
        botoBorrar3.setLocation(container.getWidth() / 2 - botoBorrar3.getWidth() / 2 + 145, 619);
        botoBorrar3.setMouseOverImage(imatgeBotoBorrarOver);}

    /**
     * 为这些按钮添加必要的监听器
     */
    private void afegirListeners() {

        // 存档1按钮监听器
        botoPerfil1.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (!alphaBotonsIn && !alphaBotonsOut) {
                    ManagerPerfil.init(1);
                    alphaBotonsOut = true;
                }
            }
        });
        // 删除存档1按钮监听器
        botoBorrar1.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (!alphaBotonsIn && !alphaBotonsOut) {
                    perfils = Configuracio.getPerfil1();
                    resetEstadistiques();
                    reiniciarPerfil = "Perfil 1";
                }
            }
        });

        // 存档2按钮监听器
        botoPerfil2.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (!alphaBotonsIn && !alphaBotonsOut) {
                    ManagerPerfil.init(2);
                    alphaBotonsOut = true;
                }
            }
        });
        // 删除存档2按钮监听器
        botoBorrar2.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (!alphaBotonsIn && !alphaBotonsOut) {
                    perfils = Configuracio.getPerfil2();
                    resetEstadistiques();
                    reiniciarPerfil = "Perfil 2";
                }
            }
        });

        // 存档3按钮监听器
        botoPerfil3.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                {
                    ManagerPerfil.init(3);
                    alphaBotonsOut = true;
                }
            }
        });
        // 删除存档3按钮监听器
        botoBorrar3.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (!alphaBotonsIn && !alphaBotonsOut) {
                    perfils = Configuracio.getPerfil3();
                    resetEstadistiques();
                    perfils.guardar();
                    reiniciarPerfil = "Perfil 3";
                }
            }
        });
    }

    /**
     *覆盖enter方法，每次进入状态时调用
     * @param gc : 当前状态的上下文
     * @param state : 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        crearBotons(gc);
        carregat = true;
        afegirListeners();
        alphaBotonsIn = true;
        reiniciarPerfil = "null";
        comptadorReiniciarPerfil = 0;
    }

    /**
     * 覆盖leave方法，每次退出状态时调用
     * @param gc
     * @param state
     */
    @Override
    public void leave(GameContainer gc, StateBasedGame state) {
        carregat = false;
        comptador = 0;
        alphaBotonsOut = false;
        imatgeBotoBorrar.setAlpha(1f);
        imatgeBotoNormal.setAlpha(1f);
        imatgeBotoOver.setAlpha(1f);
        imatgeTextPerfil1.setAlpha(1f);
        imatgeTextPerfil2.setAlpha(1f);
        imatgeTextPerfil3.setAlpha(1f);
    }

    /**
     * 重置个人资料的统计数据
     */
    private void resetEstadistiques() {
        perfils.setPropietatInt("seguentWave", 1);
        perfils.setPropietatInt("seguentWave", 1);
        perfils.setPropietatInt("totalAures", 0);
        perfils.setPropietatInt("totalUnitats", 0);
        perfils.setPropietatInt("totalMorts", 0);
        perfils.setPropietatInt("totalGuanyades", 0);
        perfils.setPropietatInt("totalPerdudes", 0);
        perfils.setPropietatInt("totalBales", 0);
        perfils.setPropietatInt("totalDiners", 0);
        perfils.guardar();
    }
}
