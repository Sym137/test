package projecte.td.estats;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 在这个状态下，显示了通过哪些按钮可以访问游戏信息库
 * @author David Alvarez Palau i Ernest Daban Macià
 */
public class EstatDades extends BasicGameState {

    // 状态标识符
    public static final int ID = 8;
    // 游戏容器
    private GameContainer container;
    // 状态容器，用于访问所需的状态
    private StateBasedGame state;
    // 查看统计数据的按钮
    private BotoMenu botoEstadistiques;
    // 访问单位信息的按钮
    private BotoMenu botoUnitats;
    // 访问敌人信息的按钮
    private BotoMenu botoEnemics;
    // 返回主菜单的按钮
    private BotoMenu botoTornar;
    // 屏幕背景图像
    private Image imatgeFons;
    // 按钮正常图像（无鼠标悬停）
    private Image imatgeBotoNormal;
    // 鼠标悬停时的按钮图像
    private Image imatgeBotoOver;
    // 状态标题
    private Image textTitol;
    // 统计数据按钮文本
    private Image textEstadistiques;
    // 单位按钮文本
    private Image textUnitats;
    // 敌人按钮文本
    private Image textEnemics;
    // 返回按钮文本
    private Image textTornar;

    /**
     * BasicGameState要求我们实现这个方法
     * @return 返回游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化状态所需的变量
     * @param container 游戏容器
     * @param game 游戏状态
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame game)
            throws SlickException {
        this.state = game;
        this.container = container;
        imatgeFons = ManagerRecursos.getImage("fonsSelectorImage");
        imatgeBotoNormal = ManagerRecursos.getImage("botoPerfil2OverImage");
        imatgeBotoOver = ManagerRecursos.getImage("botoPerfilNormalImage");
        textTitol = ManagerRecursos.getImage("textDadesGranImage");
        textEnemics = ManagerRecursos.getImage("textEstadistiquesImage");
        textUnitats = ManagerRecursos.getImage("textUnitatsImage");
        textEnemics = ManagerRecursos.getImage("textEnemicsImage");
        textEstadistiques = ManagerRecursos.getImage("textEstadistiquesImage");
        textTornar = ManagerRecursos.getImage("textTornarImage");
    }

    /**
     * 游戏引擎负责调用这个方法，在这里更新在此状态下使用的变量或对象的数据
     * @param container 游戏容器
     * @param game 游戏状态
     * @param delta 时间差
     * @throws SlickException
     */
    public void update(GameContainer container, StateBasedGame game, int delta)
            throws SlickException {
        ReproductorMusica.update(container);
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     * @param container 游戏容器
     * @param game 游戏状态
     * @param g 图形上下文
     * @throws SlickException
     */
    public void render(GameContainer container, StateBasedGame game, Graphics g)
            throws SlickException {
        imatgeFons.draw(0, 0);
        textTitol.draw(248, 145);
        botoUnitats.render(container, g);
        botoEstadistiques.render(container, g);
        botoEnemics.render(container, g);
        botoTornar.render(container, g);
    }

    /**
     * 每次进入这个状态时，会调用这个方法
     * @param gc 当前状态的上下文
     * @param state 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        crearBotonsMenuNormal();
        afegirListeners();
    }

    /**
     * 在这个方法中创建主菜单中显示的按钮
     * 通过资源管理器为按钮分配图像和位置
     */
    private void crearBotonsMenuNormal() {
        // 返回主菜单的按钮
        botoEstadistiques = new BotoMenu(container, imatgeBotoNormal, 380, 270);
        botoEstadistiques.setMouseOverImage(imatgeBotoOver);
        botoEstadistiques.setImageText(textEstadistiques);

        botoEstadistiques.setActiu(true);
        // 单位信息按钮
        botoUnitats = new BotoMenu(container, imatgeBotoNormal, 380, 370);
        botoUnitats.setMouseOverImage(imatgeBotoOver);
        botoUnitats.setImageText(textUnitats);

        botoUnitats.setActiu(true);
        // 敌人信息按钮
        botoEnemics = new BotoMenu(container, imatgeBotoNormal, 380, 470);
        botoEnemics.setMouseOverImage(imatgeBotoOver);
        botoEnemics.setImageText(textEnemics);

        botoEnemics.setActiu(true);
        // 返回按钮
        botoTornar = new BotoMenu(container, imatgeBotoNormal, 380, 570);
        botoTornar.setMouseOverImage(imatgeBotoOver);
        botoTornar.setImageText(textTornar);

        botoTornar.setActiu(true);
    }

    /**
     * 为按钮添加监听器，以便响应按钮操作
     */
    private void afegirListeners() {
        botoUnitats.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatInfoUnitats.ID);
            }
        });
        botoEstadistiques.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatEstadistiques.ID);
            }
        });
        botoEnemics.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatInfoEnemic.ID);
            }
        });
        botoTornar.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatMenuPrincipal.ID);
            }
        });
    }
}