package projecte.td.estats;

import org.newdawn.slick.Animation;
import org.newdawn.slick.Color;
import org.newdawn.slick.Font;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.managers.ManagerPerfil;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ArxiuConfiguracio;
import projecte.td.utilitats.Configuracio;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 显示在状态 EstatInfoUnitats 中选择的单位的相关信息
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class EstatMostraInfoUnitats extends BasicGameState {

    // 状态标识符
    public static final int ID = 11;
    // 游戏容器
    private GameContainer container;
    // 状态容器，用于访问所需的状态
    private StateBasedGame state;
    // 返回按钮
    private BotoMenu botoTornar;
    // 屏幕背景图像
    private Image imatgeFons;
    // 正常按钮图像（无鼠标悬停）
    private Image imatgeBotoNormal;
    // 鼠标悬停时的按钮图像
    private Image imatgeBotoOver;
    // 单位动画显示图像
    private Image labelFonsNegre;
    // 选择单位的动画
    private Animation animation;
    // 包含单位信息的配置文件
    private ArxiuConfiguracio unitats;
    // 显示信息的单位
    private String unitatTriada;
    // 选择单位的生命值
    private String vida;
    // 选择单位的能力
    private String capacitat;
    // 选择单位的频率
    private String cadencia;
    // 用于渲染文本的字体
    private Font font;

    /**
     * BasicGameState 强制我们实现这个方法
     * @return int 游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化状态正常运行所需的变量
     * @param container
     * @param game
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame game)
            throws SlickException {
        this.state = game;
        this.container = container;
        imatgeFons = ManagerRecursos.getImage("fonsSelectorImage");
        imatgeBotoNormal = ManagerRecursos.getImage("botoXImage");
        imatgeBotoOver = ManagerRecursos.getImage("botoXOverImage");
        labelFonsNegre = ManagerRecursos.getImage("fonsNegrePetitImage");
        font = ManagerRecursos.getFont("dejavuNormalFont");

    }

    /**
     * 引擎负责调用这个方法，这里将更新在此状态下使用的变量或对象的数据
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer container, StateBasedGame game, int delta)
            throws SlickException {
        ReproductorMusica.update(container);
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer container, StateBasedGame game, Graphics g)
            throws SlickException {
        imatgeFons.draw(0, 0);
        labelFonsNegre.draw(435, 123);
        botoTornar.render(container, g);
        g.setFont(font);
        g.setColor(Color.black);
        g.drawString(unitatTriada, 425, 330);
        g.drawString("Health: " + vida, 425, 380);
        g.drawString("Rate: " + cadencia, 425, 430);
        g.drawString("Capacity:  " + capacitat, 425, 480);
        int posX = 435 + labelFonsNegre.getWidth() / 2 - animation.getImage(0).getWidth() / 2;
        int posY = 123 + labelFonsNegre.getHeight() / 2 - animation.getImage(0).getHeight() / 2;
        g.drawAnimation(animation, posX, posY);
    }

    /**
     * 覆盖enter方法，每次进入状态时调用
     * @param gc : 当前状态的上下文
     * @param state : 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        crearBotonsMenuNormal();
        afegirListeners();
        unitats = Configuracio.getUnitats();
        assignarPropietats();
    }

    /**
     * 将相关属性分配给类的属性
     */
    private void assignarPropietats() {
        unitatTriada = ManagerPerfil.getInformacioUnitat();
        vida = unitats.getPropietatString("infoVida" + unitatTriada);
        cadencia = unitats.getPropietatString("infoCadencia" + unitatTriada);
        capacitat = unitats.getPropietatString("infoCapacitat" + unitatTriada);
        animation = new Animation(ManagerRecursos.getImageArray(unitats.getPropietatString("animation" + unitatTriada)), 80);
    }

    /**
     * 在这个方法中创建主菜单中显示的按钮
     * 通过资源管理器为按钮分配图像和位置
     */
    private void crearBotonsMenuNormal() {
        // BotoMenu tornar al menu principal
        botoTornar = new BotoMenu(container, imatgeBotoNormal, 746, 104);
        botoTornar.setMouseOverImage(imatgeBotoOver);
        botoTornar.setActiu(true);
    }

    /**
     * 添加使按钮动作的监听器
     */
    private void afegirListeners() {
        botoTornar.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatInfoUnitats.ID);
            }
        });
    }
}