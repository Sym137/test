package projecte.td.estats;

import java.util.ArrayList;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 显示主菜单，用户可以选择进入菜单的哪个选项
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class EstatMenuPrincipal extends BasicGameState {

    // 状态标识符
    public static final int ID = 3;
    // 游戏容器
    private GameContainer container;
    // 状态容器，用于访问所需的状态
    private StateBasedGame state;
    // 继续游戏的按钮，从上次游戏停止的地方开始
    private BotoMenu botoNovaPartida;
    // 访问选项菜单的按钮
    private BotoMenu botoOpcions;
    // 访问更改用户个人资料状态的按钮
    private BotoMenu botoCanviarPerfil;
    // 退出游戏的按钮
    private BotoMenu botoSortir;
    // 访问音乐选项的按钮
    private BotoMenu botoMusica;
    // 用于检查是否需要进行透明度效果的布尔值
    private boolean alphaBotonsIn;
    // 用于检查是否需要进行透明度效果的布尔值
    private boolean alphaBotonsOut;
    // 当需要时移动所有按钮的ArrayList
    private ArrayList<BotoMenu> botons;
    // 用于实现按钮移动的计数器
    private int comptador;
    // 指示需要切换到哪个状态
    private int canviAEstat;
    // 用于alpha渐变的浮点数
    private float transparencia;
    // 屏幕背景图像
    private Image imatgeFons;
    // 游戏标志的图像
    private Image imatgeTitol;
    // 正常按钮（鼠标未悬停）的图像
    private Image imatgeBotoNormal;
    // 鼠标悬停时的按钮图像
    private Image imatgeBotoOver;
    // 播放按钮的图像
    private Image imatgeBotoPlay;
    // 鼠标悬停时播放按钮的图像
    private Image imatgeBotoOverPlay;
    // 按钮上的“玩”文本图像
    private Image imatgeTextJugar;
    // 按钮上的“个人资料”文本图像
    private Image imatgeTextPerfil;
    // 按钮上的“数据”文本图像
    private Image imatgeTextDades;
    // 按钮上的“退出”文本图像
    private Image imatgeTextSortir;

    /**
     * BasicGameState 强制我们实现这个方法
     *
     * @return int 游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化状态正常运行所需的变量
     *
     * @param container
     * @param game
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame state) {
        this.container = container;
        this.state = state;
        imatgeFons = ManagerRecursos.getImage("fonsMenuImage");
        imatgeTitol = ManagerRecursos.getImage("fonsTitolImage");
        imatgeBotoOver = ManagerRecursos.getImage("botoPerfilNormalImage");
        imatgeBotoNormal = ManagerRecursos.getImage("botoPerfil2OverImage");
        imatgeBotoPlay = ManagerRecursos.getImage("botoPlayImage");
        imatgeBotoOverPlay = ManagerRecursos.getImage("botoPlayOverImage");
        imatgeTextJugar = ManagerRecursos.getImage("textJugarImage");
        imatgeTextPerfil = ManagerRecursos.getImage("textPerfilImage");
        imatgeTextDades = ManagerRecursos.getImage("textDadesImage");
        imatgeTextSortir = ManagerRecursos.getImage("textSortirImage");
    }

    /**
     * 重置此状态中使用的变量的值
     */
    private void reiniciarVariables() {
        botons = new ArrayList<BotoMenu>();
        canviAEstat = 0;
    }

    /**
     * 在这个方法中创建主菜单中显示的按钮
     * 通过资源管理器为按钮分配图像和位置
     */
    private void crearBotonsMenuNormal() {
        // 新游戏按钮
        botoNovaPartida = new BotoMenu(container, imatgeBotoNormal, 150, 440);
        botoNovaPartida.setMouseOverImage(imatgeBotoOver);
        botoNovaPartida.setImageText(imatgeTextJugar);

        botons.add(botoNovaPartida);
        // 选项菜单按钮
        botoOpcions = new BotoMenu(container, imatgeBotoNormal, 600, 440);
        botoOpcions.setMouseOverImage(imatgeBotoOver);
        botoOpcions.setImageText(imatgeTextDades);

        botons.add(botoOpcions);
        // 更改个人资料按钮
        botoCanviarPerfil = new BotoMenu(container, imatgeBotoNormal, 150, 585);
        botoCanviarPerfil.setMouseOverImage(imatgeBotoOver);
        botoCanviarPerfil.setImageText(imatgeTextPerfil);

        botons.add(botoCanviarPerfil);
        // 退出游戏按钮
        botoSortir = new BotoMenu(container, imatgeBotoNormal, 600, 585);
        botoSortir.setMouseOverImage(imatgeBotoOver);
        botoSortir.setImageText(imatgeTextSortir);

        botons.add(botoSortir);
        // 音乐按钮
        botoMusica = new BotoMenu(container, imatgeBotoPlay, 480, 510);
        botoMusica.setMouseOverImage(imatgeBotoOverPlay);

        botons.add(botoMusica);
    }

    /**
     * 添加使按钮动作的监听器
     */
    private void afegirListeners() {
        botoNovaPartida.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (!alphaBotonsIn && !alphaBotonsOut) {
                    alphaBotonsOut = true;
                    canviAEstat = EstatSeguentWave.ID;
                }
            }
        });
        botoOpcions.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (!alphaBotonsIn && !alphaBotonsOut) {
                    alphaBotonsOut = true;
                    canviAEstat = EstatDades.ID;
                }
            }
        });
        botoCanviarPerfil.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (!alphaBotonsIn && !alphaBotonsOut) {
                    alphaBotonsOut = true;
                    canviAEstat = EstatPerfil.ID;
                }
            }
        });
        botoSortir.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (!alphaBotonsIn && !alphaBotonsOut) {
                    state.enterState(EstatSortir.ID);
                }
            }
        });
        botoMusica.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                if (!alphaBotonsIn && !alphaBotonsOut) {
                    state.enterState(EstatMusica.ID);
                }
            }
        });
    }

    /**
     * 引擎负责调用这个方法，这里将更新在此状态下使用的变量或对象的数据
     *
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer game, StateBasedGame state, int delta) {
        // 如果正在进入或退出状态，则执行透明度效果
        if (alphaBotonsIn) {
            comptador += 50;
            if (comptador % 100 == 0) {
                // 按钮变得不那么透明
                transparencia += 0.05;
            }
            if (transparencia >= 1) {
                // 当按钮不再透明时激活
                ReproductorMusica.setVolumMusic();
                ReproductorMusica.last();
                botoNovaPartida.setActiu(true);
                botoOpcions.setActiu(true);
                botoCanviarPerfil.setActiu(true);
                botoSortir.setActiu(true);
                botoMusica.setActiu(true);
                botoMusica.setAcceptingInput(true);
                alphaBotonsIn = false;
                comptador = 0;
            }
        } else if (alphaBotonsOut) {
            // 当按钮变得透明时它们被禁用
            botoNovaPartida.setActiu(false);
            botoOpcions.setActiu(false);
            botoCanviarPerfil.setActiu(false);
            botoSortir.setActiu(false);
            botoMusica.setActiu(false);
            botoMusica.setAcceptingInput(false);
            comptador += 50;
            if (comptador % 100 == 0) {
                transparencia -= 0.05;
            }
// 当透明度达到0时，进入下一个状态
            if (transparencia <= 0) {
                state.enterState(canviAEstat);
            }
        }
        ReproductorMusica.update(container);
    }

    /**
     * 这个方法用于渲染或在屏幕上绘制想要的元素
     *
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer game, StateBasedGame state, Graphics g) {
        imatgeFons.draw(0, 0);
        imatgeTitol.draw(290, 100);
        imatgeBotoNormal.setAlpha(transparencia);
        imatgeBotoOver.setAlpha(transparencia);
        imatgeBotoPlay.setAlpha(transparencia);
        imatgeBotoOverPlay.setAlpha(transparencia);
        imatgeTextJugar.setAlpha(transparencia);
        imatgeTextDades.setAlpha(transparencia);
        imatgeTextPerfil.setAlpha(transparencia);
        imatgeTextSortir.setAlpha(transparencia);
        botoNovaPartida.render(container, g);
        botoOpcions.render(container, g);
        botoCanviarPerfil.render(container, g);
        botoSortir.render(container, g);
        botoMusica.render(container, g);
    }

    /**
     * 覆盖enter方法，每次进入状态时调用
     *
     * @param gc    : 当前状态的上下文
     * @param state : 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        reiniciarVariables();
        crearBotonsMenuNormal();
        afegirListeners();
        alphaBotonsIn = true;

    }

    /**
     * 覆盖leave方法，每次退出状态时调用
     *
     * @param gc
     * @param state
     */
    @Override
    public void leave(GameContainer gc, StateBasedGame state) {
        alphaBotonsOut = false;
        imatgeBotoNormal.setAlpha(1f);
        imatgeBotoOver.setAlpha(1f);
        imatgeTextJugar.setAlpha(1f);
        imatgeTextDades.setAlpha(1f);
        imatgeTextPerfil.setAlpha(1f);
        imatgeTextSortir.setAlpha(1f);
        imatgeBotoPlay.setAlpha(1f);
        imatgeBotoOverPlay.setAlpha(1f);
        comptador = 0;
    }
}