package projecte.td.estats;

import org.newdawn.slick.Font;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Sound;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.managers.ManagerPerfil;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 显示与当前活动用户配置文件相关的累积分数信息
 * @author David Alvarez Palau 和 Ernest Daban Macià
 */
public class EstatEstadistiques extends BasicGameState {

    // 状态的标识符
    public static final int ID = 9;
    // 游戏容器
    private GameContainer container;
    // 状态容器，用于访问所需的状态
    private StateBasedGame state;
    // 用于重新开始波次的按钮
    private BotoMenu botoTornar;
    // 背景图像
    private Image imatgeFons;
    // 普通按钮图像（无鼠标悬停）
    private Image imatgeBotoNormal;
    // 鼠标悬停时的按钮图像
    private Image imatgeBotoOver;

    // 用于渲染文本的字体
    private Font font;
    // 玩家累积的总死亡数
    private static int totalMorts;
    // 玩家放置的总单位数
    private static int totalUnitatsColocades;
    // 单位发射的总子弹数
    private static int totalBales;
    // 获胜的总游戏次数
    private static int totalGuanyades;
    // 失败的总游戏次数
    private static int totalPerdudes;
    // 累积的总金钱
    private static int totalDinersGuanyats;
    // 放置的总光环数
    private static int totalAuresColocades;

    /**
     * BasicGameState 强制我们实现此方法
     * @return 游戏状态的ID
     */
    public int getID() {
        return ID;
    }

    /**
     * 在此处初始化状态正常运行所需的变量
     * @param container
     * @param game
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame game)
            throws SlickException {
        this.state = game;
        this.container = container;
        imatgeFons = ManagerRecursos.getImage("fonsSelectorImage");
        imatgeBotoNormal = ManagerRecursos.getImage("botoXImage");
        imatgeBotoOver = ManagerRecursos.getImage("botoXOverImage");

        font = ManagerRecursos.getFont("dejavuNormalFont");

    }

    /**
     * 引擎负责调用此方法，在此处更新正在使用的变量或对象的数据
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer container, StateBasedGame game, int delta)
            throws SlickException {
        ReproductorMusica.update(container);
    }

    /**
     * 此方法用于渲染或绘制屏幕上所需的元素
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer container, StateBasedGame game, Graphics g)
            throws SlickException {
        imatgeFons.draw(0, 0);
        botoTornar.render(container, g);
        g.setFont(font);
        g.drawString("Total Deaths:" + totalMorts, 410, 240);
        g.drawString("Total Rounds:" + totalBales, 410, 280);
        g.drawString("Total Wins:" + totalGuanyades, 410, 320);
        g.drawString("Total Losses:" + totalPerdudes, 410, 360);
        g.drawString("Total Money:" + totalDinersGuanyats, 410, 400);
        g.drawString("Total Orbs:" + totalAuresColocades, 410, 440);
        g.drawString("Total Units:" + totalUnitatsColocades, 410, 480);
    }

    /**
     * 重写 enter 方法，每次进入状态时都会调用此方法
     * @param gc : 当前状态所在的环境
     * @param state : 当前状态
     */
    @Override
    public void enter(GameContainer gc, StateBasedGame state) {
        crearBotonsMenuNormal();
        afegirListeners();
        // 当访问状态时，初始化相应的值
        totalMorts = ManagerPerfil.getTotalMorts();
        totalBales = ManagerPerfil.getBales();
        totalGuanyades = ManagerPerfil.getGuanyades();
        totalPerdudes = ManagerPerfil.getPerdudes();
        totalDinersGuanyats = ManagerPerfil.getDiners();
        totalAuresColocades = ManagerPerfil.getAures();
        totalUnitatsColocades = ManagerPerfil.getUnitats();
    }

    /**
     * 在此方法中创建将在主菜单中显示的按钮
     * 通过资源管理器为按钮分配图像和位置
     */
    private void crearBotonsMenuNormal() {
        // 返回主菜单的按钮
        botoTornar = new BotoMenu(container, imatgeBotoNormal, 750, 100);
        botoTornar.setMouseOverImage(imatgeBotoOver);

        botoTornar.setActiu(true);
    }

    /**
     * 添加将触发按钮的监听器
     */
    private void afegirListeners() {
        botoTornar.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatDades.ID);
            }
        });
    }
}

