package projecte.td.estats;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Sound;
import org.newdawn.slick.gui.AbstractComponent;
import org.newdawn.slick.gui.ComponentListener;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import projecte.td.componentGUI.BotoMenu;
import projecte.td.managers.ManagerRecursos;
import projecte.td.utilitats.ReproductorMusica;

/**
 * 向用户询问是否真的要退出应用程序
 * @author David Alvarez Palau i Ernest Daban Macià
 */
public class EstatSortir extends BasicGameState {

    // 状态标识符
    public static final int ID = 15;
    // 游戏容器
    private GameContainer container;
    // 状态容器，用于访问必要的状态
    private StateBasedGame state;
    // 退出应用程序的按钮
    private BotoMenu botoSi;
    // 返回主菜单的按钮
    private BotoMenu botoNo;
    // 背景图像
    private Image imatgeFons;
    // 按钮正常状态图像（鼠标未悬停）
    private Image imatgeBotoXNormal;
    // 按钮悬停状态图像
    private Image imatgeBotoXOver;
    // 按钮正常状态图像（鼠标未悬停）
    private Image imatgeBotoVNormal;
    // 按钮悬停状态图像
    private Image imatgeBotoVOver;
    // “您要退出应用程序吗？”的文本图像
    private Image textSortida;

    /**
     * BasicGameState 强制我们实现此方法
     * @return 一个包含游戏状态 ID 的整数
     */
    public int getID() {
        return ID;
    }

    /**
     * 在这里初始化此状态正常运行所需的所有变量
     * @param container
     * @param game
     * @throws SlickException
     */
    public void init(GameContainer container, StateBasedGame state) {
        this.container = container;
        this.state = state;
        imatgeFons = ManagerRecursos.getImage("fonsSelectorImage");
        imatgeBotoXNormal = ManagerRecursos.getImage("botoXImage");
        imatgeBotoXOver = ManagerRecursos.getImage("botoXOverImage");
        imatgeBotoVNormal = ManagerRecursos.getImage("botoVImage");
        imatgeBotoVOver = ManagerRecursos.getImage("botoVOverImage");
        textSortida = ManagerRecursos.getImage("textSortidaImage");
        crearBotons();
        afegirListeners();
    }

    /**
     * 创建此状态的按钮
     */
    private void crearBotons() {
        // 创建按钮
        // BotoMenu 是，当要退出游戏时使用
        botoSi = new BotoMenu(container, imatgeBotoVNormal, 425, 400);
        botoSi.setMouseOverImage(imatgeBotoVOver);
        botoSi.setActiu(true);
        // BotoMenu 否，继续游戏
        botoNo = new BotoMenu(container, imatgeBotoXNormal, 525, 400);
        botoNo.setMouseOverImage(imatgeBotoXOver);
        botoNo.setActiu(true);
    }

    /**
     * 向按钮添加监听器
     */
    private void afegirListeners() {
        // BotoMenu 是 的监听器
        botoSi.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                container.exit();
            }
        });
        // BotoMenu 否 的监听器
        botoNo.addListener(new ComponentListener() {

            public void componentActivated(AbstractComponent comp) {
                state.enterState(EstatMenuPrincipal.ID);
            }
        });
    }

    /**
     * 引擎负责调用此方法，在此可以更新使用中的变量或对象的数据
     * @param container
     * @param game
     * @param delta
     * @throws SlickException
     */
    public void update(GameContainer game, StateBasedGame state, int delta) {
        ReproductorMusica.update(container);
    }

    /**
     * 此方法用于在屏幕上渲染或绘制所需元素
     * @param container
     * @param game
     * @param g
     * @throws SlickException
     */
    public void render(GameContainer game, StateBasedGame state, Graphics g) {
        imatgeFons.draw(0, 0);
        textSortida.draw(250, 280);
        botoSi.render(container, g);
        botoNo.render(container, g);
    }
}


