package com.sym;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TeacherWatchGUI extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public TeacherWatchGUI(User user) {
        setTitle("我的请假信息");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // 居中显示

        String[] columnNames = {"studentId", "name", "className", "phone", "leaveType", "startDate", "endDate", "reason", "status"};
        model = new DefaultTableModel(columnNames, 0); // 0 rows initially
        table = new JTable(model);

        // 设置JTable的其他属性，如选择模式、行高、列宽等（可选）

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        loadData(user);

        JButton returnButton=new JButton("返回");
        add(returnButton,BorderLayout.SOUTH);
        returnButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    private void loadData(User user) {
        String query = "SELECT * FROM Leaves";
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Object[] row = {
                        rs.getString("studentId"),
                        rs.getString("name"),
                        rs.getString("className"),
                        rs.getString("phone"),
                        rs.getString("leaveType"),
                        rs.getString("startDate"), // 考虑使用适当的日期格式
                        rs.getString("endDate"),   // 考虑使用适当的日期格式
                        rs.getString("reason"),
                        rs.getString("status")
                };
                model.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "数据库连接失败！", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }
}
