package com.sym;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 输出所有请假申请
 * 选中某一请假申请后点击同意或者拒绝就会更新数据库中status,并同步到界面
 * 在底部添加一个返回按钮返回Choice
 */
public class TeacherExamineGUI extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private int selectedRowIndex = -1; // 用于存储当前选中的行索引

    public TeacherExamineGUI(User user) {
        setTitle("学生请假信息审批");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // 居中显示

        String[] columnNames = {"studentId", "name", "className", "phone", "leaveType", "startDate", "endDate", "reason", "status"};
        model = new DefaultTableModel(columnNames, 0);
        table = new JTable(model);
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    ListSelectionModel lsm = table.getSelectionModel();
                    selectedRowIndex = lsm.getMinSelectionIndex();
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton approveButton = new JButton("同意");
        JButton rejectButton = new JButton("拒绝");

        approveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                approveOrReject(true);
            }
        });

        rejectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                approveOrReject(false);
            }
        });

        buttonPanel.add(approveButton);
        buttonPanel.add(rejectButton);
        add(buttonPanel, BorderLayout.NORTH);

        JButton returnButton=new JButton("返回");
        add(returnButton, BorderLayout.SOUTH);
        returnButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        loadData();

        setVisible(true);
    }

    private void loadData() {
        String query = "SELECT * FROM Leaves";
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Object[] row = {
                        rs.getString("studentId"),
                        rs.getString("name"),
                        rs.getString("className"),
                        rs.getString("phone"),
                        rs.getString("leaveType"),
                        rs.getString("startDate"),
                        rs.getString("endDate"),
                        rs.getString("reason"),
                        rs.getString("status")
                };
                model.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "数据库连接失败！", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void approveOrReject(boolean approve) {
        if (selectedRowIndex == -1) {
            JOptionPane.showMessageDialog(this, "请先选择一行！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String studentId = (String) model.getValueAt(selectedRowIndex, 0);
        String status = approve ? "批准" : "拒绝";

        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE Leaves SET status = ? WHERE studentId = ?")) {
            pstmt.setString(1, status);
            pstmt.setString(2, studentId);
            pstmt.executeUpdate();

            // 更新表格中的状态
            model.setValueAt(status, selectedRowIndex, 8);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "数据库更新失败！", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    // 假设User类已经定义，这里不需要进一步修改
    // public static class User {
    //     // User类的定义
    // }

    // 假设JDBCUtil类已经定义，用于获取数据库连接
    // public static class JDBCUtil {
    //     public static Connection getConnection() throws SQLException {
    //         // 获取数据库连接的代码
    //     }
    // }


}