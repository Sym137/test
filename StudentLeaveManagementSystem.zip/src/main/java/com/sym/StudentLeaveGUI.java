package com.sym;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * 相应的文本框输入信息
 * 一个提交登录按钮
 * 一个返回Choice界面按钮
 */
public class StudentLeaveGUI extends JFrame {
    private JTextField studentIdField;
    private JTextField nameField;
    private JTextField classField;
    private JTextField phoneField;
    private JTextField leaveTypeField;
    private JTextField startDateField;
    private JTextField endDateField;
    private JTextArea reasonArea;

    public StudentLeaveGUI(User user) {
        setTitle("学生请假系统");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(9, 2));

        panel.add(new JLabel("学号:"));
        studentIdField = new JTextField();
        panel.add(studentIdField);

        panel.add(new JLabel("姓名:"));
        nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("班级:"));
        classField = new JTextField();
        panel.add(classField);

        panel.add(new JLabel("电话:"));
        phoneField = new JTextField();
        panel.add(phoneField);

        panel.add(new JLabel("请假类型:"));
        leaveTypeField = new JTextField();
        panel.add(leaveTypeField);

        panel.add(new JLabel("开始日期:"));
        startDateField = new JTextField();
        panel.add(startDateField);

        panel.add(new JLabel("结束日期:"));
        endDateField = new JTextField();
        panel.add(endDateField);

        panel.add(new JLabel("请假理由:"));
        reasonArea = new JTextArea(5, 20);
        panel.add(new JScrollPane(reasonArea));
/**
 * 点击按钮后将数据同步到数据库
 */
        JButton submitButton = new JButton("提交请假申请");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submitLeaveRequest();
            }
        });
        panel.add(submitButton);

        JButton returnButton = new JButton("返回");
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        panel.add(returnButton);

        add(panel);
    }

    private void submitLeaveRequest() {
        String studentId = studentIdField.getText();
        String name = nameField.getText();
        String className = classField.getText();
        String phone = phoneField.getText();
        String leaveType = leaveTypeField.getText();
        String startDate = startDateField.getText();
        String endDate = endDateField.getText();
        String reason = reasonArea.getText();

        // 插入到数据库
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Leaves (studentId, name, className, phone, leaveType, startDate,endDate,reason,status) VALUES (?, ?, ?, ?, ?,?,?,?, '未批准')")) {

            pstmt.setString(1, studentId);
            pstmt.setString(2, name);
            pstmt.setString(3, className);
            pstmt.setString(4, phone);
            pstmt.setString(5, leaveType);
            pstmt.setString(6, startDate);
            pstmt.setString(7, endDate);
            pstmt.setString(8, reason);

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "请假申请提交成功！");
            } else {
                JOptionPane.showMessageDialog(this, "请假申请提交失败！");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "数据库连接失败！");
        }
    }

}