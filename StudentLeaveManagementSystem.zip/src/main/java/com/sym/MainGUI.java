package com.sym;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * 主UI界面
 * 两个文本框分别输入id与密码
 * 一个按钮用来确认登录
 */
public class MainGUI extends JFrame {
    private JTextField idField;
    private JPasswordField passwordField;

    public MainGUI(){
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3,2));

        add(new JLabel("id:"));
        idField =new JTextField(20);
        add(idField);

        add(new JLabel("Password:"));
        passwordField=new JPasswordField(20);
        add(passwordField);

        JButton loginButton=new JButton("Login");
        add(loginButton);
/**
 * 按下按钮后进行身份比对
 * id与password不匹配的提示错误
 * 身份为学生调用StudentChoiceGUI
 * 身份为老师调用TeacherChoiceGUI
 */
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id= idField.getText();
                String password=new String(passwordField.getPassword());

                User user=User.authenticate(id,password);
                if(user!=null){
                    if(user.getRole().equals("student")){
                        new StudentChoiceGUI(user).setVisible(true);
                    } else if (user.getRole().equals("teacher")) {
                        new TeacherChoiceGUI(user).setVisible(true);
                    }
                }else {
                    JOptionPane.showMessageDialog(null, "Invalid Username or Password");
                }

            }
        });
    }
}
