package com.sym;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * 三个按钮
 * 1.进行请假申请
 * 2.查看自身所有申请
 * 3.返回登录界面
 */
public class StudentChoiceGUI extends JFrame {
    public StudentChoiceGUI(User user) {
        setTitle("Choice");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300,200);
        setLayout(new GridLayout(3,1));

        JButton leaveApplyButton=new JButton("请假申请");
        add(leaveApplyButton);
        leaveApplyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new StudentLeaveGUI(user).setVisible(true);
            }

        });

        JButton watchApplyButton=new JButton("查看所有申请");
        add(watchApplyButton);
        watchApplyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new StudentWatchGUI(user).setVisible(true);
            }
        });

        JButton returnButton=new JButton("返回");
        add(returnButton);
        returnButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

    }
}
