package com.sym;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 将数据库中的数据进行读取
 * 与该用户id进行匹配
 * 将匹配的信息全部用文本输出
 * 添加一个返回按钮返回Choice界面
 */

public class StudentWatchGUI extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public StudentWatchGUI(User user) {
        setTitle("我的请假信息");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        String[] columnNames = {"studentId", "name", "className", "phone", "leaveType", "startDate", "endDate", "reason", "status"};
        model = new DefaultTableModel(columnNames, 0); // 0 rows initially
        table = new JTable(model);

        // 设置JTable的其他属性，如选择模式、行高、列宽等（可选）

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        loadData(user);

        JButton returnButton = new JButton("返回");
        returnButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(returnButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void loadData(User user) {
        String query = "SELECT * FROM Leaves WHERE studentId = ?";
        try (Connection conn = JDBCUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, user.getId());
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Object[] row = {
                        rs.getString("studentId"),
                        rs.getString("name"),
                        rs.getString("className"),
                        rs.getString("phone"),
                        rs.getString("leaveType"),
                        rs.getString("startDate"), // 考虑使用适当的日期格式
                        rs.getString("endDate"),   // 考虑使用适当的日期格式
                        rs.getString("reason"),
                        rs.getString("status")
                };
                model.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "数据库连接失败！", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }
}
