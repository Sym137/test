package com.sym;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * 三个按钮
 * 1.进行请假申请审查
 * 2.查看所有申请
 * 3.返回登录界面
 */
public class TeacherChoiceGUI extends JFrame {
    public TeacherChoiceGUI(User user) {
        setTitle("Choice");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300,200);
        setLayout(new GridLayout(3,1));
        JButton leaveApplyButton=new JButton("审批请假申请");
        add(leaveApplyButton);
        leaveApplyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TeacherExamineGUI(user).setVisible(true);
            }
        });


        JButton watchApplyButton=new JButton("查看所有申请");
        add(watchApplyButton);
        watchApplyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TeacherWatchGUI(user).setVisible(true);
            }
        });

        JButton returnButton=new JButton("返回");
        add(returnButton);
        returnButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
}
