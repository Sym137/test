package com.sym;

public class Leave {
}
