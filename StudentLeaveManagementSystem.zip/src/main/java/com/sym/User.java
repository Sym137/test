package com.sym;

import java.util.ArrayList;
import java.util.List;

public class User {
    private String id;
    private String password;
    private String role; // "student" or "teacher"

    public User(String id, String password, String role) {
        this.id = id;
        this.password = password;
        this.role = role;
    }

    public String getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }

    /**
     * 储存内置的id与密码、身份等信息
     * 也可以使用数据库进行存储
     * 待实现
     * @return 用户列表
     */
    public static List<User> getUsers() {
        List<User> users = new ArrayList<>();
        users.add(new User("s001", "password1", "student"));
        users.add(new User("t001", "password2", "teacher"));
        return users;
    }

    /**
     * 根据id与password来匹配相应的用户
     * @param id
     * @param password
     * @return 相匹配的用户
     */
    public static User authenticate(String id, String password) {
        for (User user : getUsers()) {
            if (user.getId().equals(id) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }
}
